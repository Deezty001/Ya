<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * @package Savvy_Ops
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

// 1. Drop Custom Tables
$tables = [
    $wpdb->prefix . 'savvy_catalogue',
    $wpdb->prefix . 'savvy_units',
    $wpdb->prefix . 'savvy_orders',
    $wpdb->prefix . 'savvy_order_components',
    $wpdb->prefix . 'savvy_configurations'
];

foreach ( $tables as $table ) {
    $wpdb->query( "DROP TABLE IF EXISTS $table" );
}

// 2. Delete Options (if any)
// delete_option( 'savvy_ops_option_name' ); 
