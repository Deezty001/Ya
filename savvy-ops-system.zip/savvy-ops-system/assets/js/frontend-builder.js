jQuery(document).ready(function ($) {
    var params = window.savvy_frontend_params || {};
    var ajaxurl = params.ajaxurl;
    var productId = params.product_id;
    var isSubmitting = false;

    if ($('.savvy-builder-wrap').length === 0) return;

    // Shared Helper for Additive Checks
    function isAdditiveCategory(cat) {
        var additiveCats = ['storage', 'ssd', 'hdd', 'cooler', 'fan'];
        if (!cat) return false;
        return additiveCats.some(function (ac) {
            return cat.toLowerCase().indexOf(ac) !== -1;
        });
    }

    function updateSavvySelection() {
        var $wrap = $('.savvy-builder-wrap');
        var basePrice = parseFloat($wrap.data('base-price'));
        var total = basePrice;

        var hiddenInputs = '';
        var upgradeMap = {};
        var upgradeNames = [];

        $('.savvy-builder-wrap input:checked').each(function () {
            var $el = $(this);
            var price = parseFloat($el.data('price')) || 0;
            var replaceCat = $el.data('replace-cat');
            var partId = $el.data('part-id');
            var label = $el.next('label').text().trim().replace(/\(\+\$[\d\.]+\)$/, '').replace(/\(Included\)$/, '').trim();

            if (replaceCat && partId) {
                if (isAdditiveCategory(replaceCat)) {
                    upgradeMap[replaceCat + '::' + partId] = partId;
                } else {
                    upgradeMap[replaceCat] = partId;
                }
            }

            total += price;
            if (label) upgradeNames.push(label);
        });

        // Store raw config
        $('#savvy_upgrade_map-frontend').val(JSON.stringify(upgradeMap));

        // Store meta for submission
        var extraCost = total - basePrice;
        $('#savvy-hidden-inputs-frontend').data('names', upgradeNames.join(', '));
        $('#savvy-hidden-inputs-frontend').data('cost', extraCost);

        var formattedPrice = '$' + total.toLocaleString(undefined, { minimumFractionDigits: 2 });
        $('.price .woocommerce-Price-amount bdi, .price .amount').first().html(formattedPrice);
    }

    // Bind events
    $('.savvy-radio, .savvy-check').on('change', updateSavvySelection);
    setTimeout(updateSavvySelection, 500);

    // Intercept Add to Cart
    $('form.cart').on('submit', function (e) {
        if (isSubmitting) return true;

        var upgradeMapVal = $('#savvy_upgrade_map-frontend').val();
        if (!upgradeMapVal || upgradeMapVal === '{}') return true;

        e.preventDefault();
        var $form = $(this);
        var $btn = $form.find('.single_add_to_cart_button');
        $btn.addClass('loading');

        var payload = {
            action: 'savvy_save_config',
            product_id: productId,
            upgrade_map: JSON.parse(upgradeMapVal),
            upgrade_names: $('#savvy-hidden-inputs-frontend').data('names'),
            extra_cost: $('#savvy-hidden-inputs-frontend').data('cost'),
            manual_config: {}
        };

        $.post(ajaxurl, payload, function (res) {
            $btn.removeClass('loading');
            if (res.success) {
                // Inject Config ID
                if ($form.find('input[name="savvy_config_id"]').length === 0) {
                    $form.append('<input type="hidden" name="savvy_config_id" value="' + res.data.config_id + '">');
                } else {
                    $('input[name="savvy_config_id"]').val(res.data.config_id);
                }

                isSubmitting = true;
                $form.submit();
            } else {
                alert('Error saving configuration: ' + (res.data || 'Unknown error'));
            }
        }).fail(function () {
            $btn.removeClass('loading');
            alert('Server error saving configuration.');
        });
    });
});
