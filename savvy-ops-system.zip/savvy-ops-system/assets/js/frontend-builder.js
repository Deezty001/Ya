jQuery(document).ready(function ($) {
    var params = window.savvy_frontend_params || {};
    var ajaxurl = params.ajaxurl;
    var productId = params.product_id;
    var nonce = params.nonce; // New Nonce

    if ($('.savvy-builder-wrap').length === 0) return;

    // Debounce Helper
    function debounce(func, wait) {
        var timeout;
        return function () {
            var context = this, args = arguments;
            clearTimeout(timeout);
            timeout = setTimeout(function () { func.apply(context, args); }, wait);
        };
    }

    // Shared Helper for Additive Checks
    function isAdditiveCategory(cat) {
        var additiveCats = ['storage', 'ssd', 'hdd', 'cooler', 'fan'];
        if (!cat) return false;
        return additiveCats.some(function (ac) {
            return cat.toLowerCase().indexOf(ac) !== -1;
        });
    }

    // CORE: Calculate and SAVE to server immediately
    var updateAndSave = debounce(function () {
        var $wrap = $('.savvy-builder-wrap');
        var basePrice = parseFloat($wrap.data('base-price'));
        var total = basePrice;
        var upgradeMap = {};
        var upgradeNames = [];

        $('.savvy-builder-wrap input:checked').each(function () {
            var $el = $(this);
            var price = parseFloat($el.data('price')) || 0;
            var replaceCat = $el.data('replace-cat');
            var partId = $el.data('part-id');
            var label = $el.next('label').text().trim().replace(/\(\+\$[\d\.]+\)$/, '').replace(/\(Included\)$/, '').trim();

            if (replaceCat && partId) {
                if (isAdditiveCategory(replaceCat)) {
                    upgradeMap[replaceCat + '::' + partId] = partId;
                } else {
                    upgradeMap[replaceCat] = partId;
                }
            }
            total += price;
            if (label) upgradeNames.push(label);
        });

        // 1. UI Updates
        var extraCost = total - basePrice;
        var formattedPrice = '$' + total.toLocaleString(undefined, { minimumFractionDigits: 2 });
        $('.price .woocommerce-Price-amount bdi, .price .amount').first().html(formattedPrice);

        // 2. SERVER SAVE (Reactive)
        var payload = {
            action: 'savvy_save_config',
            nonce: nonce, // Security
            product_id: productId,
            upgrade_map: upgradeMap,
            upgrade_names: upgradeNames.join(', '),
            extra_cost: extraCost,
            manual_config: {}
        };

        // UI Feedback (Optional spinner near price)
        $('.price').css('opacity', '0.5');

        $.post(ajaxurl, payload, function (res) {
            $('.price').css('opacity', '1');
            if (res.success) {
                // INJECT ID: This is the critical fix. The ID is now always ready.
                // We use a specific ID to avoid conflicts with other plugins
                var $input = $('input[name="savvy_config_id"]');
                if ($input.length === 0) {
                    $('form.cart').append('<input type="hidden" name="savvy_config_id" value="' + res.data.config_id + '">');
                } else {
                    $input.val(res.data.config_id);
                }
                console.log('Savvy Config Saved: ' + res.data.config_id);
            } else {
                console.error('Savvy Save Error', res);
            }
        });

    }, 500); // 500ms debounce

    // Bind events
    $('.savvy-radio, .savvy-check').on('change', updateAndSave);

    // Trigger once on load to ensure ID is generated for default selections
    setTimeout(updateAndSave, 500);

    // REMOVED: $('form.cart').on('submit') interception is gone.
    // The form submits natively now, carrying the savvy_config_id hidden input.
});
