jQuery(document).ready(function ($) {
    var data = window.savvy_admin_data || {};
    var ajaxurl = window.ajaxurl;

    // ============================================
    // 1. PRODUCT DATA TAB (PC Upgrades)
    // ============================================
    if ($('#savvy_upgrades_panel').length > 0) {

        initAjaxSelects();

        function initAjaxSelects() {
            $('.savvy-part-picker-ajax:not(.select2-hidden-accessible)').each(function () {
                var $el = $(this);
                var cat = $el.data('cat') || 'ALL';

                $el.select2({
                    width: 'resolve',
                    placeholder: 'Search ' + cat + '...',
                    minimumInputLength: 0,
                    ajax: {
                        url: ajaxurl,
                        dataType: 'json',
                        delay: 250,
                        data: function (params) {
                            return {
                                action: 'savvy_search_parts',
                                term: params.term,
                                category: $el.data('cat')
                            };
                        },
                        processResults: function (data) {
                            return { results: data.results };
                        },
                        cache: true
                    }
                });

                $el.off('select2:select').on('select2:select', function (e) {
                    var d = e.params.data;
                    var text = d.text;
                    var $row = $(this).closest('div');

                    var $nameInput = $row.find('input[type="text"]').first();
                    if ($nameInput.val() === '' || $nameInput.val().indexOf('Upgrade Name') !== -1) {
                        $nameInput.val(text);
                    }
                    $row.find('.savvy-part-id-input').val(d.id);
                });
            });
        }

        // Add Category Group
        $('#add_cat_btn').on('click', function () {
            var idx = $('#savvy_rows > div').length + Math.floor(Math.random() * 1000);
            var catOpts = '<option value="">-- Select --</option>';
            if (data.categories) {
                data.categories.forEach(function (c) {
                    catOpts += '<option value="' + c + '">' + c + '</option>';
                });
            }

            var html = '<div class="savvy-cat-group" style="border: 2px solid #c4a577; padding: 15px; margin-bottom: 20px; background: #fff;">' +
                '<input type="hidden" name="item_type[]" value="category">' +
                '<div style="display:flex; gap:10px; margin-bottom:5px; align-items:center; background:#eee; padding:5px;">' +
                '<strong style="padding-left:5px;">Category:</strong>' +
                '<select name="cat_name[]" class="savvy-cat-selector" style="font-weight:bold; flex:1;">' + catOpts + '</select>' +
                '<strong style="padding-left:10px;">Link Base Spec:</strong>' +
                '<select name="cat_linked_base[]" class="savvy-base-link-selector" style="flex:1;"><option value="">-- None --</option>';

            if (data.categories) {
                data.categories.forEach(function (c) {
                    html += '<option value="' + c + '">Sync with ' + c + '</option>';
                });
            }

            html += '</select>' +
                '<button type="button" class="remove-savvy-parent button" style="color:red;">Delete Group</button></div>' +
                '<div style="display:flex; gap:10px; margin-bottom:10px; padding:5px;"><label>Manual Standard Label:</label><input type="text" name="cat_standard[]" placeholder="Standard Label" style="flex:1;"></div>' +
                '<div class="savvy-sub-options" style="padding-left:30px; border-left: 2px dashed #ccc;"></div>' +
                '<button type="button" class="add-sub-opt button" data-idx="' + idx + '" style="margin-top:10px;">+ Add Upgrade Option</button></div>';

            $('#savvy_rows').append(html);
        });

        // Add Standalone
        $('#add_opt_btn').on('click', function () {
            var html = '<div class="savvy-standalone" style="border: 1px solid #ddd; padding: 10px; margin-bottom: 10px; background: #f9f9f9; display:flex; gap:10px; align-items:center;">' +
                '<input type="hidden" name="item_type[]" value="standalone"><input type="hidden" name="cat_name[]" value=""><input type="hidden" name="cat_linked_base[]" value=""><input type="hidden" name="cat_standard[]" value="">' +
                '<select class="savvy-part-picker-ajax" style="min-width:250px;" data-cat="ALL"></select>' +
                '<input type="text" name="standalone_label[]" placeholder="Standalone Name" style="flex:2;">' +
                '<input type="number" step="0.01" name="standalone_price[]" placeholder="Price" style="flex:1; max-width:100px;">' +
                '<button type="button" class="remove-savvy-parent button" style="color:red;">&times;</button></div>';

            var $node = $(html);
            $('#savvy_rows').append($node);
            initAjaxSelects();
        });

        // Add Sub-Option
        $(document).on('click', '.add-sub-opt', function () {
            var idx = $(this).data('idx');
            var parentCat = $(this).closest('.savvy-cat-group').find('.savvy-cat-selector').val();

            var html = '<div class="savvy-sub-row" style="display:flex; gap:10px; margin-bottom:5px; align-items:center;">' +
                '<select class="savvy-part-picker-ajax" style="min-width:250px;" data-cat="' + (parentCat || '') + '"></select>' +
                '<input type="text" name="sub_opt_label[' + idx + '][]" placeholder="Upgrade Name" style="flex:2;">' +
                '<input type="number" step="0.01" name="sub_opt_price[' + idx + '][]" placeholder="Price" style="flex:1; max-width:100px;">' +
                '<input type="hidden" name="sub_opt_part_id[' + idx + '][]" class="savvy-part-id-input">' +
                '<button type="button" class="remove-child button">&times;</button></div>';

            var $node = $(html);
            $(this).siblings('.savvy-sub-options').append($node);
            initAjaxSelects();
        });

        $(document).on('change', '.savvy-cat-selector', function () {
            var newCat = $(this).val();
            var $group = $(this).closest('.savvy-cat-group');
            $group.find('.savvy-base-link-selector').val(newCat);
            $group.find('.savvy-part-picker-ajax').each(function () {
                $(this).data('cat', newCat);
                $(this).attr('data-cat', newCat);
            });
        });

        $(document).on('click', '.remove-savvy-parent', function () { $(this).closest('div').parent().remove(); });
        $(document).on('click', '.remove-child', function () { $(this).closest('.savvy-sub-row').remove(); });
    }

    // ============================================
    // 2. MODAL ORDER CONFIGURATOR
    // ============================================
    if ($('#savvy-admin-modal').length > 0) {
        var currentItemId = 0;
        var currentProductId = 0;

        function isAdditiveCategory(cat) {
            var additiveCats = ['storage', 'ssd', 'hdd', 'cooler', 'fan'];
            if (!cat) return false;
            return additiveCats.some(function (ac) { return cat.toLowerCase().indexOf(ac) !== -1; });
        }

        $('body').on('click', '.savvy-config-trigger', function (e) {
            e.preventDefault();
            currentItemId = $(this).data('item-id');
            currentProductId = $(this).data('product-id');

            $('#savvy-admin-modal-overlay').css('display', 'flex');
            $('#savvy-admin-builder-content').html('<p>Loading options...</p>');

            $.ajax({
                url: ajaxurl,
                method: 'GET',
                data: {
                    action: 'savvy_get_admin_builder',
                    product_id: currentProductId,
                    item_id: currentItemId,
                    nonce: data.nonce
                },
                success: function (res) {
                    $('#savvy-admin-builder-content').html(res);
                    $(document.body).trigger('wc-enhanced-select-init');
                },
                error: function (err) {
                    $('#savvy-admin-builder-content').html('<p style="color:red">Error loading options.</p>');
                }
            });
        });

        $('body').on('click', '#savvy-close-modal', function (e) {
            e.preventDefault();
            $('#savvy-admin-modal-overlay').hide();
        });

        // Manual Override
        $('body').on('click', '#savvy_add_manual_override', function () {
            var $sel = $('#savvy_manual_part_selector option:selected');
            var partId = $sel.val();
            var pureLabel = $sel.text().replace(/^\[.*?\]\s*/, '');

            var autoCat = $sel.data('cat');
            var forcedCat = $('#savvy_manual_cat_force').val();
            var price = parseFloat($('#savvy_manual_price').val()) || 0;
            var finalCat = forcedCat ? forcedCat : autoCat;

            if (!partId) { alert('Please select a part first.'); return; }
            if (!finalCat) { alert('Could not detect category.'); return; }

            if (!isAdditiveCategory(finalCat)) {
                var existingManual = false;
                $('.manual-entry input').each(function () { if ($(this).data('replace-cat') === finalCat) existingManual = true; });
                if (existingManual) { alert('Error: Manual Upgrade for [' + finalCat + '] already exists.'); return; }

                var existingStandard = false;
                $('.savvy-radio:checked').each(function () {
                    if ($(this).data('replace-cat') === finalCat && parseFloat($(this).val()) > 0) existingStandard = true;
                });
                if (existingStandard) { alert('Error: Standard Upgrade for [' + finalCat + '] is selected. Unselect it first.'); return; }
            }

            var html = '<div class="savvy-group manual-entry" style="margin-bottom:10px; padding:10px; border:1px solid #ddd; background:#fff;">' +
                '<div class="savvy-flex" style="display:flex; align-items:center; gap:10px;">' +
                '<input type="checkbox" class="savvy-check" checked name="savvy_manual[]" value="' + price + '" data-price="' + price + '" data-replace-cat="' + finalCat + '" data-part-id="' + partId + '">' +
                '<label class="savvy-btn" style="flex:1;">' +
                '<strong>' + finalCat + ':</strong> ' + pureLabel +
                ' <span class="savvy-price" style="color:#2271b1; font-weight:bold;">(+$' + price.toFixed(2) + ')</span>' +
                '</label></div></div>';

            $('#savvy_manual_added_list').append(html);
            $('#savvy_manual_price').val('');
        });

        $('body').on('click', '#savvy-save-config', function (e) {
            e.preventDefault();
            var upgradeMap = {};
            var names = [];
            var extraPrice = 0;
            var manualConfig = [];

            $('#savvy-admin-builder-content .savvy-radio:checked, #savvy-admin-builder-content .savvy-check:checked').each(function () {
                var price = parseFloat($(this).data('price')) || 0;
                var label = $(this).next('label').text().trim().replace(/\(\+\$[\d\.]+\)$/, '').replace(/\(Included\)$/, '').trim();
                var replaceCat = $(this).data('replace-cat');
                var partId = $(this).data('part-id');

                if (replaceCat && partId) {
                    if (isAdditiveCategory(replaceCat)) {
                        upgradeMap[replaceCat + '::' + partId] = partId;
                    } else {
                        upgradeMap[replaceCat] = partId;
                    }
                }
                extraPrice += price;
                if (price > 0 || $(this).hasClass('savvy-check')) {
                    if (label) names.push(label);
                }
                if ($(this).closest('.manual-entry').length > 0) {
                    var niceLabel = label.replace(new RegExp('^' + replaceCat + ':\\s*'), '');
                    manualConfig.push({ id: partId, cat: replaceCat, price: price, label: niceLabel });
                }
            });

            var $btn = $(this);
            $btn.text('Saving...').prop('disabled', true);

            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: {
                    action: 'savvy_save_admin_builder',
                    nonce: data.nonce,
                    item_id: currentItemId,
                    upgrade_map: upgradeMap,
                    upgrade_names: names.join(' | '),
                    extra_cost: extraPrice,
                    manual_config: manualConfig
                },
                success: function (res) {
                    alert('Configuration Saved! Page will reload.');
                    location.reload();
                },
                error: function (err) {
                    alert('Save Failed');
                    $btn.text('Save').prop('disabled', false);
                }
            });
        });
    }

});
