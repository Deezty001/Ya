jQuery(document).ready(function ($) {
    console.log("Savvy Production UI Loaded");

    // 0. Create Order Logic
    $('#btn-create-order').on('click', function (e) {
        e.preventDefault();
        $('#modal-create-order').css('display', 'flex').hide().fadeIn(150);
        $('#form-create-order')[0].reset();
    });

    $('.modal-close-create').on('click', function () {
        $('#modal-create-order').fadeOut(150);
    });

    $('#form-create-order').on('submit', function (e) {
        e.preventDefault();
        var $btn = $(this).find('button[type="submit"]');
        var originalText = $btn.text();

        $btn.text('Creating...').prop('disabled', true);

        var data = $(this).serialize();

        $.post(savvy_vars.ajax_url, {
            action: 'savvy_create_order',
            nonce: savvy_vars.nonce,
            data: data
        }, function (res) {
            if (res.success) {
                location.reload(); // Reload to show new order
            } else {
                alert('Error creating order: ' + (res.data || 'Unknown error'));
                $btn.text(originalText).prop('disabled', false);
            }
        });
    });

    // 1. Open Order Modal
    $(document).on('click', '.order-row', function (e) {
        e.preventDefault();

        var id = $(this).data('id');
        var title = $(this).find('td:nth-child(2) strong').text();
        $('#modal-order-title').text('Order #' + id);
        $('#modal-order-subtitle').text(title);

        // RESET Content
        $('#modal-component-list').html('<div class="loading-spinner">Loading...</div>');
        $('#modal-client-info').html('');

        // FADE IN with Flex
        $('#modal-order-details').css({
            'display': 'flex',
            'opacity': 0
        }).animate({ opacity: 1 }, 100);

        loadOrderDetails(id);
    });

    // 2. Close Logic
    function closeModal() {
        $('#modal-order-details').animate({ opacity: 0 }, 100, function () {
            $(this).css('display', 'none');
        });
        $('.alloc-dropdown').hide();
    }
    $('.modal-close').on('click', closeModal);

    $(document).on('click', '#modal-order-details', function (e) {
        if (e.target.id === 'modal-order-details') closeModal();
    });

    $(document).on('keyup', function (e) {
        if (e.key === "Escape") {
            if ($('#modal-unit-details').is(':visible')) {
                $('#modal-unit-details').fadeOut(100);
            } else if ($('#modal-order-details').is(':visible')) {
                closeModal();
            }
        }
    });

    // 3. Unit Details Modal Logic
    $('.unit-modal-close').on('click', function () {
        $('#modal-unit-details').fadeOut(100);
    });

    $(document).on('click', '#modal-unit-details', function (e) {
        if (e.target.id === 'modal-unit-details') $('#modal-unit-details').fadeOut(100);
    });

    // Open Unit Details
    $(document).on('click', '.view-unit-details', function (e) {
        e.stopPropagation();
        var uid = $(this).data('uid');

        $('#modal-unit-details').css('display', 'flex').hide().fadeIn(100);

        // Reset/Loading
        $('#view-title').text('Loading...');
        $('#view-cost').text('...');
        $('#view-serial').text('SN: ...');

        $.post(savvy_vars.ajax_url, {
            action: 'savvy_get_unit_details',
            nonce: savvy_vars.nonce,
            unit_id: uid
        }, function (res) {
            if (res.success) {
                var d = res.data;
                $('#view-title').text(d.title);
                $('#view-serial').text('SN: ' + d.serial);
                $('#view-cost').text('$' + d.cost);
                $('#view-date').text(d.date);
                $('#view-upc').text(d.upc);
                $('#view-condition').text(d.condition);
            }
        });
    });

    // 4. Load Order Helper & Tab Logic
    var currentOrderData = null;

    function renderManifest(buildID) {
        if (!currentOrderData || !currentOrderData.builds) return;

        var build = currentOrderData.builds.find(function (b) { return b.id == buildID; });
        if (!build) return;

        // Update Context for Allocation
        $('#modal-order-details').data('order-id', buildID);

        // Update Tabs UI
        $('.build-tab').css({ 'color': '#888', 'border-bottom': '2px solid transparent', 'font-weight': 'normal' });
        $('.build-tab[data-bid="' + buildID + '"]').css({ 'color': '#fff', 'border-bottom': '2px solid #00b9eb', 'font-weight': 'bold' });

        var html = '';
        if (build.components && build.components.length > 0) {
            build.components.forEach(function (c) {
                var status_html = '';
                if (c.allocated) {
                    status_html = '<span class="badge-alloc view-unit-details" data-uid="' + c.unit_id + '" style="cursor:pointer;">Allocated</span> ' +
                        '<span class="view-unit-details" data-uid="' + c.unit_id + '" style="font-size:11px; color:#aaa; cursor:pointer; margin-right:5px;">' + c.unit_serial + '</span> ' +
                        '<span class="dashicons dashicons-edit action-icon btn-allocate" title="Change Unit"></span>';
                } else {
                    status_html = '<span class="badge-unalloc">Unallocated</span> ' +
                        '<span class="dashicons dashicons-edit action-icon btn-allocate" title="Allocate Stock"></span>';
                }

                html += '<div class="component-row" data-cat="' + c.category + '" data-part="' + c.part_id + '">' +
                    '<div class="comp-label">' + c.category + '</div>' +
                    '<div class="comp-name">' + c.part_name + '</div>' +
                    '<div class="comp-status">' +
                    status_html +
                    '<div class="alloc-dropdown">' +
                    '<input type="text" placeholder="Search Serial..." class="alloc-search">' +
                    '<div class="alloc-list">Loading units...</div>' +
                    '</div>' +
                    '</div>' +
                    '</div>';
            });
            $('#modal-component-list').html(html);
        } else {
            $('#modal-component-list').html('<p style="padding:20px; color:#999;">No components configured for this build.</p>');
        }
    }

    $(document).on('click', '.build-tab', function () {
        var bid = $(this).data('bid');
        renderManifest(bid);
    });

    function loadOrderDetails(id) {
        $('#modal-order-details').data('order-id', id);

        $.post(savvy_vars.ajax_url, {
            action: 'savvy_get_order_details',
            nonce: savvy_vars.nonce,
            order_id: id
        }, function (res) {
            if (res.success) {
                var d = res.data;
                currentOrderData = d;

                // Header (Main Order ID)
                $('#modal-order-title').text('Order #' + d.main_display_id);
                $('#modal-order-subtitle').text(d.title);

                // Render Tabs
                var tabs = '';
                if (d.builds && d.builds.length > 0) {
                    d.builds.forEach(function (b) {
                        tabs += `<div class="build-tab" data-bid="${b.id}" style="cursor:pointer; padding:8px 15px; font-size:13px; color:#888;">${b.display_id}</div>`;
                    });
                }
                $('#modal-build-tabs').html(tabs);

                // Initial Render (Current Selection)
                renderManifest(id);

                // Customer Info
                if (d.customer) {
                    var c = d.customer;
                    var c_html = `
                        <div style="font-size:14px; font-weight:bold; color:#fff; margin-bottom:5px;">${c.name}</div>
                        <div style="font-size:12px; color:#aaa; margin-bottom:5px;">${c.email}</div>
                        <div style="font-size:12px; color:#aaa; margin-bottom:10px;">${c.phone}</div>
                        <div style="font-size:12px; color:#888; margin-bottom:15px; border-left:2px solid #333; padding-left:10px; line-height:1.4;">
                            ${c.address}
                        </div>
                        <a href="${c.profile_url}" target="_blank" class="button" style="width:100%; text-align:center; display:block;">View Profile</a>
                    `;
                    $('#modal-client-info').html(c_html);
                }

            } else {
                $('#modal-component-list').html('<p style="color:red;">Error loading details: ' + res.data + '</p>');
            }
        });
    }

    // 5. Allocation Logic
    $(document).on('click', '.btn-allocate', function (e) {
        e.stopPropagation();
        var $row = $(this).closest('.component-row');
        var $dropdown = $row.find('.alloc-dropdown');
        var partID = $row.data('part');

        $('.alloc-dropdown').not($dropdown).hide();
        $dropdown.slideDown(150);
        $dropdown.find('.alloc-search').focus();

        if ($dropdown.find('.alloc-item').length === 0) {
            $.post(savvy_vars.ajax_url, {
                action: 'savvy_get_available_units',
                nonce: savvy_vars.nonce,
                part_id: partID
            }, function (res) {
                if (res.success) {
                    var html = '';
                    if (res.data.length > 0) {
                        res.data.forEach(function (u) {
                            html += `<div class="alloc-item" data-uid="${u.id}">${u.serial}</div>`;
                        });
                    } else {
                        html = '<div style="padding:10px; color:#999; font-style:italic;">No stock available.</div>';
                    }
                    $dropdown.find('.alloc-list').html(html);
                }
            });
        }
    });

    $(document).on('click', '.alloc-dropdown', function (e) { e.stopPropagation(); });
    $(document).on('click', function () { $('.alloc-dropdown').hide(); });

    $(document).on('click', '.alloc-item', function () {
        var $item = $(this);
        var unitID = $item.data('uid');
        var $row = $item.closest('.component-row');
        var $dropdown = $item.closest('.alloc-dropdown');
        var orderID = $('#modal-order-details').data('order-id');
        var category = $row.data('cat');

        if (!unitID) return;
        $item.text('Allocating...').css('opacity', '0.5');

        $.post(savvy_vars.ajax_url, {
            action: 'savvy_allocate_unit',
            nonce: savvy_vars.nonce,
            order_id: orderID,
            unit_id: unitID,
            category: category
        }, function (res) {
            if (res.success) {
                loadOrderDetails(orderID);
            } else {
                alert('Error allocating: ' + res.data);
                $item.text($item.text().replace('Allocating...', '')).css('opacity', '1');
            }
        });
    });

    $(document).on('keyup', '.alloc-search', function () {
        var val = $(this).val().toLowerCase();
        $(this).closest('.alloc-dropdown').find('.alloc-item').each(function () {
            var text = $(this).text().toLowerCase();
            $(this).toggle(text.indexOf(val) > -1);
        });
    });
});
