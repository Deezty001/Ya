jQuery(document).ready(function ($) {
    console.log("Savvy Production UI Loaded");

    // 0. Create Order Logic
    $('#btn-create-order').on('click', function (e) {
        e.preventDefault();
        $('#modal-create-order').css('display', 'flex').hide().fadeIn(150);
        $('#form-create-order')[0].reset();
    });

    $('.modal-close-create').on('click', function () {
        $('#modal-create-order').fadeOut(150);
    });

    $('#form-create-order').on('submit', function (e) {
        e.preventDefault();
        var $btn = $(this).find('button[type="submit"]');
        var originalText = $btn.text();

        $btn.text('Creating...').prop('disabled', true);

        var data = $(this).serialize();

        $.post(savvy_vars.ajax_url, {
            action: 'savvy_create_order',
            nonce: savvy_vars.nonce,
            data: data
        }, function (res) {
            if (res.success) {
                location.reload(); // Reload to show new order
            } else {
                alert('Error creating order: ' + (res.data || 'Unknown error'));
                $btn.text(originalText).prop('disabled', false);
            }
        });
    });

    // 1. Open Order Modal
    $(document).on('click', '.order-row', function (e) {
        e.preventDefault();

        var id = $(this).data('id');
        var title = $(this).find('td:nth-child(2) strong').text();
        $('#modal-order-title').text('Order #' + id);
        $('#modal-order-subtitle').text(title);

        // RESET Content
        $('#modal-component-list').html('<div class="loading-spinner">Loading...</div>');
        $('#modal-client-info').html('');

        // FADE IN with Flex
        $('#modal-order-details').css({
            'display': 'flex',
            'opacity': 0
        }).animate({ opacity: 1 }, 100);

        loadOrderDetails(id);
    });

    // 2. Close Logic
    function closeModal() {
        $('#modal-order-details').animate({ opacity: 0 }, 100, function () {
            $(this).css('display', 'none');
        });
        $('.alloc-dropdown').hide();
    }
    $('.modal-close').on('click', closeModal);

    $(document).on('click', '#modal-order-details', function (e) {
        if (e.target.id === 'modal-order-details') closeModal();
    });

    $(document).on('keyup', function (e) {
        if (e.key === "Escape") {
            if ($('#modal-unit-details').is(':visible')) {
                $('#modal-unit-details').fadeOut(100);
            } else if ($('#modal-order-details').is(':visible')) {
                closeModal();
            }
        }
    });

    // 3. Unit Details Modal Logic
    $('.unit-modal-close').on('click', function () {
        $('#modal-unit-details').fadeOut(100);
    });

    $(document).on('click', '#modal-unit-details', function (e) {
        if (e.target.id === 'modal-unit-details') $('#modal-unit-details').fadeOut(100);
    });

    // Open Unit Details
    $(document).on('click', '.view-unit-details', function (e) {
        e.stopPropagation();
        var uid = $(this).data('uid');

        $('#modal-unit-details').css('display', 'flex').hide().fadeIn(100);

        // Reset/Loading
        $('#view-title').text('Loading...');
        $('#view-cost').text('...');
        $('#view-serial').text('SN: ...');

        $.post(savvy_vars.ajax_url, {
            action: 'savvy_get_unit_details',
            nonce: savvy_vars.nonce,
            unit_id: uid
        }, function (res) {
            if (res.success) {
                var d = res.data;
                $('#view-title').text(d.title);
                $('#view-serial').text('SN: ' + d.serial);
                $('#view-cost').text('$' + d.cost);
                $('#view-date').text(d.date);
                $('#view-upc').text(d.upc);
                $('#view-condition').text(d.condition);
            }
        });
    });

    // 4. Load Order Helper & Tab Logic
    var currentOrderData = null;

    function renderManifest(buildID) {
        if (!currentOrderData || !currentOrderData.builds) return;

        var build = currentOrderData.builds.find(function (b) { return b.id == buildID; });
        if (!build) return;

        // Update Context for Allocation
        $('#modal-order-details').data('order-id', buildID);

        // Update Tabs UI (Use new .build-tab class logic)
        $('.build-tab').removeClass('active');
        $('.build-tab[data-bid="' + buildID + '"]').addClass('active');

        var html = '';
        if (build.components && build.components.length > 0) {
            build.components.forEach(function (c) {
                // Determine Status Styling
                var status_cell = '';
                var action_cell = '';
                var icon_cell = '';

                if (c.allocated) {
                    // Allocated: Green Check + Serial Success Pill
                    icon_cell = '<td><span class="dashicons dashicons-yes" style="color:var(--modal-accent-success);"></span></td>';
                    status_cell = '<td><span class="scan-pill success view-unit-details" data-uid="' + c.unit_id + '" style="cursor:pointer;">SN: ' + c.unit_serial + '</span></td>';
                    action_cell = '<td style="text-align:right;"><button class="btn btn-secondary btn-small btn-allocate" title="Change Unit" data-part="' + c.part_id + '">Reset</button></td>';
                } else {
                    // Unallocated: Grey Marker + Search/Scan
                    icon_cell = '<td><span class="dashicons dashicons-marker" style="color:var(--modal-text-tertiary);"></span></td>';
                    status_cell = '<td><span class="scan-pill">Unallocated</span></td>';

                    // We need the dropdown container, but styled differently or hidden until clicked?
                    // For "Sleek Tech", the user wants a "Scan Unit" button or similar.
                    // Let's wrap the old dropdown logic in a way that respects the table layout.
                    // We'll put the dropdown inside the Action cell for now so it pops up near the button.
                    action_cell = '<td style="text-align:right; position:relative;">' +
                        '<button class="btn btn-primary btn-small btn-allocate" data-part="' + c.part_id + '">Scan Unit</button>' +
                        '<div class="alloc-dropdown" style="display:none; position:absolute; right:0; top:35px; z-index:100; background:#fff; border:1px solid #ddd; padding:10px; width:250px; text-align:left; box-shadow:0 10px 20px rgba(0,0,0,0.1); border-radius:8px;">' +
                        '<input type="text" placeholder="Search Serial..." class="alloc-search input-glass" style="width:100%; margin-bottom:5px;">' +
                        '<div class="alloc-list" style="max-height:150px; overflow-y:auto;">Loading units...</div>' +
                        '</div>' +
                        '</td>';
                }

                // Row Construction
                html += '<div class="component-row-wrapper" data-cat="' + c.category + '" data-part="' + c.part_id + '" style="display:contents;">' + // display:contents to let td sit in table if we output tr. 
                    // Wait, #modal-component-list is a DIV, not a TBODY in my previous HTML edit.
                    // I need to output the whole TABLE STRUCTURE or just rows if the container is specific.
                    // In step 4, I left #modal-component-list as a DIV below a THEAD table.
                    // So I should output properly styled DIVs that look like rows, OR update HTML to be a single table.
                    // The user's HTML example used a proper <table> everywhere.
                    // Let's use the .comp-row style (divs) to avoid table-layout issues if container is div.
                    // Update: User's HTML used `tr`. My previous PHP edit made `#modal-component-list` a `div`.
                    // To match "looks like this styling", I will render DIVS that LOOK like the table rows using the CSS I added?
                    // No, the user provided CSS `.tech-table td`.
                    // I should output a `<table class="tech-table"><tbody> ... </tbody></table>` INSIDE the #modal-component-list div.

                    // Let's wrap the whole loop output in one table.
                    '</div>';
            });

            // Actually, rebuilding the loop to generate TRs is better.
            var rows = '';
            build.components.forEach(function (c) {
                var status_html = c.allocated ?
                    '<span class="scan-pill success view-unit-details" data-uid="' + c.unit_id + '">SN: ' + c.unit_serial + '</span>' :
                    '<span class="scan-pill">Unallocated</span>';

                var icon_html = c.allocated ?
                    '<span class="dashicons dashicons-yes" style="color:var(--modal-accent-success);"></span>' :
                    '<span class="dashicons dashicons-marker" style="color:var(--modal-text-tertiary);"></span>';

                var action_btn = c.allocated ?
                    '<button class="btn btn-secondary btn-small btn-allocate" data-part="' + c.part_id + '">Reset</button>' :
                    '<button class="btn btn-primary btn-small btn-allocate" data-part="' + c.part_id + '">Scan Unit</button>';

                var dropdown = c.allocated ? '' :
                    '<div class="alloc-dropdown" style="display:none; position:absolute; right:0; top:40px; z-index:100; background:#fff; border:1px solid #e2e8f0; padding:10px; width:260px; text-align:left; box-shadow:0 10px 20px rgba(0,0,0,0.1); border-radius:12px;">' +
                    '<input type="text" placeholder="Search Serial..." class="alloc-search input-glass" style="width:100%; margin-bottom:10px;">' +
                    '<div class="alloc-list" style="max-height:200px; overflow-y:auto;">Loading...</div>' +
                    '</div>';

                rows += '<tr class="component-row" data-cat="' + c.category + '" data-part="' + c.part_id + '">' +
                    '<td style="width:40px; text-align:center;">' + icon_html + '</td>' +
                    '<td>' +
                    '<div style="font-weight:600; color:var(--modal-text-primary);">' + c.part_name + '</div>' +
                    '<div style="font-size:11px; color:var(--modal-text-tertiary);">' + c.category + '</div>' +
                    '</td>' +
                    '<td>' + status_html + '</td>' +
                    '<td style="text-align:right; position:relative;">' + action_btn + dropdown + '</td>' +
                    '</tr>';
            });

            // Replace the previous "Table Header" in PHP which was separate. 
            // Ideally we render the whole table here to overwrite the "Loading" state clearly.
            html = '<table class="tech-table">' +
                '<thead><tr><th style="width:40px;"></th><th>Component</th><th>Status</th><th style="text-align:right;">Action</th></tr></thead>' +
                '<tbody>' + rows + '</tbody>' +
                '</table>';

            $('#modal-component-list').html(html);
        } else {
            $('#modal-component-list').html('<p style="padding:20px; color:#999;">No components configured for this build.</p>');
        }
    }

    $(document).on('click', '.build-tab', function () {
        var bid = $(this).data('bid');
        renderManifest(bid);
    });

    function loadOrderDetails(id) {
        $('#modal-order-details').data('order-id', id);

        $.post(savvy_vars.ajax_url, {
            action: 'savvy_get_order_details',
            nonce: savvy_vars.nonce,
            order_id: id
        }, function (res) {
            if (res.success) {
                var d = res.data;
                currentOrderData = d;

                // Header (Main Order ID)
                $('#modal-order-title').text('Order #' + d.main_display_id);
                $('#modal-order-subtitle').text(d.title);

                // Render Tabs
                var tabs = '';
                if (d.builds && d.builds.length > 0) {
                    d.builds.forEach(function (b) {
                        // Use the nav-item style from user snippet
                        // <div class="nav-item css..." ...> <span class="dashicons..."></span> Name </div>
                        tabs += `<button class="build-tab" data-bid="${b.id}"><span class="dashicons dashicons-desktop"></span> ${b.title || 'Build ' + b.display_id}</button>`;
                    });
                }
                $('#modal-build-tabs').html(tabs);

                // Initial Render (Current Selection)
                renderManifest(id);

                // Customer Info
                if (d.customer) {
                    var c = d.customer;
                    var c_html = `
                        <div style="font-size:14px; font-weight:bold; color:#fff; margin-bottom:5px;">${c.name}</div>
                        <div style="font-size:12px; color:#aaa; margin-bottom:5px;">${c.email}</div>
                        <div style="font-size:12px; color:#aaa; margin-bottom:10px;">${c.phone}</div>
                        <div style="font-size:12px; color:#888; margin-bottom:15px; border-left:2px solid #333; padding-left:10px; line-height:1.4;">
                            ${c.address}
                        </div>
                        <a href="${c.profile_url}" target="_blank" class="button" style="width:100%; text-align:center; display:block;">View Profile</a>
                    `;
                    $('#modal-client-info').html(c_html);
                }

            } else {
                $('#modal-component-list').html('<p style="color:red;">Error loading details: ' + res.data + '</p>');
            }
        });
    }

    // 5. Allocation Logic
    $(document).on('click', '.btn-allocate', function (e) {
        e.stopPropagation();
        var $row = $(this).closest('.component-row');
        var $dropdown = $row.find('.alloc-dropdown');
        var partID = $row.data('part');

        $('.alloc-dropdown').not($dropdown).hide();
        $dropdown.slideDown(150);
        $dropdown.find('.alloc-search').focus();

        if ($dropdown.find('.alloc-item').length === 0) {
            $.post(savvy_vars.ajax_url, {
                action: 'savvy_get_available_units',
                nonce: savvy_vars.nonce,
                part_id: partID
            }, function (res) {
                if (res.success) {
                    var html = '';
                    if (res.data.length > 0) {
                        res.data.forEach(function (u) {
                            html += `<div class="alloc-item" data-uid="${u.id}">${u.serial}</div>`;
                        });
                    } else {
                        html = '<div style="padding:10px; color:#999; font-style:italic;">No stock available.</div>';
                    }
                    $dropdown.find('.alloc-list').html(html);
                }
            });
        }
    });

    $(document).on('click', '.alloc-dropdown', function (e) { e.stopPropagation(); });
    $(document).on('click', function () { $('.alloc-dropdown').hide(); });

    $(document).on('click', '.alloc-item', function () {
        var $item = $(this);
        var unitID = $item.data('uid');
        var $row = $item.closest('.component-row');
        var $dropdown = $item.closest('.alloc-dropdown');
        var orderID = $('#modal-order-details').data('order-id');
        var category = $row.data('cat');

        if (!unitID) return;
        $item.text('Allocating...').css('opacity', '0.5');

        $.post(savvy_vars.ajax_url, {
            action: 'savvy_allocate_unit',
            nonce: savvy_vars.nonce,
            order_id: orderID,
            unit_id: unitID,
            category: category
        }, function (res) {
            if (res.success) {
                loadOrderDetails(orderID);
            } else {
                alert('Error allocating: ' + res.data);
                $item.text($item.text().replace('Allocating...', '')).css('opacity', '1');
            }
        });
    });

    $(document).on('keyup', '.alloc-search', function () {
        var val = $(this).val().toLowerCase();
        $(this).closest('.alloc-dropdown').find('.alloc-item').each(function () {
            var text = $(this).text().toLowerCase();
            $(this).toggle(text.indexOf(val) > -1);
        });
    });
    // 6. View Switcher & Filters
    // ----------------------------------------------------

    // View Toogle
    $('.view-btn').on('click', function () {
        var view = $(this).data('view');

        // Active Button
        $('.view-btn').removeClass('active');
        $(this).addClass('active');

        // Active Container
        $('.savvy-view-container').hide();
        $('#savvy-' + view + '-view').fadeIn(200);

        // Save Pref (Optional)
        localStorage.setItem('savvy_prod_view', view);
    });

    // Restore Pref
    var savedView = localStorage.getItem('savvy_prod_view');
    if (savedView) {
        $('.view-btn[data-view="' + savedView + '"]').click();
    }

    // Filter Logic
    function runFilters() {
        var search = $('#savvy-filter-search').val().toLowerCase();
        var urgent = $('#savvy-filter-urgent').is(':checked');
        var myBuilds = $('#savvy-filter-mybuilds').is(':checked'); // Not implemented yet without User ID
        var stage = $('#savvy-filter-stage').val();

        $('.filter-target').each(function () {
            var $el = $(this);
            var txt = $el.data('search') || '';
            var isUrg = $el.data('urgent') == '1';

            // For Kanban, we also need to check column Stage (handled by DOM placement, but stage filter can hide/show rows)
            // But wait, in Kanban, the stage is the COLUMN. So filtering by Stage in Kanban implies showing/hiding columns or just items?
            // Usually, Stage filter in Board view is redundant unless we want to "Focus" on one column.
            // Let's make the Stage filter only apply to List view ROWs or Board ITEMS. 
            // In Board view, items are already in stage columns. Hiding items in other stages works visually.

            var rowStage = '';
            if ($el.hasClass('kanban-card')) {
                // Determine stage from parent col? Or just trust logic
                // Actually, the card doesn't have stage data attribute explicitly in my previous PHP, 
                // but it lives in a column. Let's assume the user uses this mainly for search/urgent.
                // For List View, I added status badge. 
            }
            // Simple string search on the card text/data is robust enough.

            var show = true;

            if (search && txt.indexOf(search) === -1) show = false;
            if (urgent && !isUrg) show = false;

            // Stage Filter (Basic implementation: Check if text contains stage)
            if (stage !== 'all') {
                // This is fuzzy. Ideally we have data-stage attribute.
                // But for now, let's rely on the PHP placement.
                // If it's List view:
                if ($el.find('.status-' + stage.toLowerCase()).length === 0 &&
                    $el.closest('.kanban-col[data-stage="' + stage + '"]').length === 0) {
                    show = false;
                }
            }

            if (show) $el.show(); else $el.hide();
        });
    }

    $('#savvy-filter-search').on('keyup', debounce(function () { runFilters(); }, 200));
    $('#savvy-filter-urgent, #savvy-filter-mybuilds, #savvy-filter-stage').on('change', runFilters);

    // 7. Complete Stage Logic (New)
    $('#btn-complete-stage').on('click', function (e) {
        e.preventDefault();
        var orderID = $('#modal-order-details').data('order-id');
        var $btn = $(this);
        var originalText = $btn.text();

        if (!orderID) return;

        if (!confirm('Are you sure you want to complete this stage? The order will move to the next column.')) return;

        $btn.text('Processing...').prop('disabled', true);

        $.post(savvy_vars.ajax_url, {
            action: 'savvy_complete_stage',
            nonce: savvy_vars.nonce,
            order_id: orderID
        }, function (res) {
            if (res.success) {
                // Success!
                $btn.text('Success!');
                setTimeout(function () {
                    location.reload(); // Simple reload to refresh board
                }, 500);
            } else {
                alert('Error: ' + (res.data || 'Unknown error'));
                $btn.text(originalText).prop('disabled', false);
            }
        }).fail(function () {
            alert('Server Error');
            $btn.text(originalText).prop('disabled', false);
        });
    });

    // Debounce Helper
    function debounce(func, wait) {
        var timeout;
        return function () {
            var context = this, args = arguments;
            clearTimeout(timeout);
            timeout = setTimeout(function () { func.apply(context, args); }, wait);
        };
    }

});
