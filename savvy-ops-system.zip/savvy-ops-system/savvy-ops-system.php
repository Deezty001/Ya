<?php
/**
 * Plugin Name: Savvy Operations System
 * Plugin URI:  https://savvycomputers.com.au
 * Description: Complete Operations System for Savvy Computers (Dashboard, Production, Inventory, Support, Client).
 * Version:     1.0.0
 * Author:      Savvy Dev
 * Text Domain: savvy-ops
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SAVVY_OPS_VERSION', '1.0.0' );
define( 'SAVVY_OPS_PATH', plugin_dir_path( __FILE__ ) );
define( 'SAVVY_OPS_URL', plugin_dir_url( __FILE__ ) );

// Include Core Components
require_once plugin_dir_path( __FILE__ ) . 'includes/class-savvy-db.php';
// CPT Loader Removed (Legacy)
require_once plugin_dir_path( __FILE__ ) . 'includes/dashboard.php';
// Field Manager Removed (Legacy CPT Metaboxes)

    // Modules
    require_once plugin_dir_path( __FILE__ ) . 'includes/modules/custom-tabs.php';
    require_once plugin_dir_path( __FILE__ ) . 'includes/modules/pc-builder.php';
    require_once plugin_dir_path( __FILE__ ) . 'includes/modules/pc-builder.php';
    
    // Moved to plugins_loaded to ensuring WC is active
    
require_once SAVVY_OPS_PATH . 'includes/hubs/production.php';
require_once SAVVY_OPS_PATH . 'includes/hubs/inventory.php';
require_once SAVVY_OPS_PATH . 'includes/db-init.php';

// Activation/Deactivation hooks
register_activation_hook( __FILE__, 'savvy_ops_activate' );

function savvy_ops_activate() {
    // Create Custom Tables
    savvy_ops_create_tables();
    flush_rewrite_rules();
}

function savvy_ops_system_init() {
    
    // Late Require for WooCommerce Sync
    if ( class_exists( 'WooCommerce' ) ) {
        require_once plugin_dir_path( __FILE__ ) . 'includes/woocommerce-sync.php';
    }

    // Enqueue Admin Styles & Scripts
    add_action( 'admin_enqueue_scripts', function( $hook ) {
        // Only load on Savvy Pages (check for 'savvy' in the hook name)
        if ( strpos( $hook, 'savvy' ) === false ) {
             return;
        }

        wp_enqueue_style( 'savvy-ops-admin-css', plugin_dir_url( __FILE__ ) . 'assets/admin-style.css' ); 
        wp_enqueue_style( 'savvy-inventory-v2-css', plugin_dir_url( __FILE__ ) . 'assets/savvy-inventory.css', array(), time() ); 
        
        // QR Code Scanner Library
        wp_enqueue_script( 'html5-qrcode', 'https://unpkg.com/html5-qrcode', array(), '2.3.8', true );
        
        wp_enqueue_script( 'savvy-inventory-js', plugin_dir_url( __FILE__ ) . 'assets/savvy-inventory.js', array('jquery', 'html5-qrcode'), time(), true );
        
        wp_localize_script( 'savvy-inventory-js', 'savvy_vars', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'savvy_inventory_nonce' )
        ));

        // Production Hub Assets
        // LOAD ON: 'savvy-production' page OR if we are forcing it for modal support
        $is_prod_page = (isset($_GET['page']) && $_GET['page'] === 'savvy-production');
        
        if ( $is_prod_page ) {
             // Load Assets specifically for the Production Hub
             wp_enqueue_style( 'savvy-production-css', plugin_dir_url( __FILE__ ) . 'assets/css/production-styles.css', array(), time() );
             wp_enqueue_script( 'savvy-production-js', plugin_dir_url( __FILE__ ) . 'assets/js/production-scripts.js', array('jquery'), time(), true );
             wp_localize_script( 'savvy-production-js', 'savvy_vars', array(
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'nonce'    => wp_create_nonce( 'savvy_inventory_nonce' )
            ));
        }
    });

    // Handle AJAX: Add Inventory (Stock)
    add_action( 'wp_ajax_savvy_add_inventory', 'savvy_ajax_add_inventory' );
    
    // Handle AJAX: Create Part (Catalogue)
    add_action( 'wp_ajax_savvy_create_part', 'savvy_ajax_create_part' );
}
add_action( 'plugins_loaded', 'savvy_ops_system_init' );

// DEBUG NOTICE (Remove after verification)
add_action('admin_notices', function() {
    echo '<div class="notice notice-info is-dismissible"><p><strong>Savvy Ops System Linked:</strong> Core is Active. Manual Sync should be visible in Orders.</p></div>';
});

// 1. Add Stock Unit (SQL)
// 1. Add Stock Unit (SQL)
function savvy_ajax_add_inventory() {
    check_ajax_referer( 'savvy_inventory_nonce', 'nonce' );
    if(!current_user_can('edit_products')) wp_send_json_error('Forbidden');

    // FIX: Parse manually and sanitize
    $raw_data = [];
    parse_str($_POST['data'], $raw_data);
    
    $cat_id = absint($raw_data['existing_part_id'] ?? 0);
    $serial = sanitize_text_field($raw_data['savvy_serial'] ?? '');
    $cost = floatval($raw_data['savvy_cost'] ?? 0);
    $received = sanitize_text_field($raw_data['savvy_date_received'] ?? date('Y-m-d'));
    
    global $wpdb;
    
    if( $cat_id && !empty($serial) ) {
        $wpdb->insert($wpdb->prefix . 'savvy_units', [
            'catalogue_id' => $cat_id,
            'serial' => $serial,
            'cost' => $cost,
            'date_received' => $received,
            'status' => 'In_Stock'
        ]);
        
        // Update Stock Count
        $count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}savvy_units WHERE catalogue_id = %d AND status = 'In_Stock'", $cat_id));
        $wpdb->update($wpdb->prefix . 'savvy_catalogue', ['stock_count' => $count], ['id' => $cat_id]);
        
        wp_send_json_success();
    } else {
        wp_send_json_error('Missing Part ID or Serial Number');
    }
}

// 2. Create Catalogue Part (SQL)
// 2. Create Catalogue Part (SQL)
function savvy_ajax_create_part() {
    check_ajax_referer( 'savvy_inventory_nonce', 'nonce' );
    if(!current_user_can('edit_products')) wp_send_json_error('Forbidden');

    $raw_data = [];
    parse_str($_POST['data'], $raw_data);
    global $wpdb;

    // Sanitization
    $brand = sanitize_text_field($raw_data['savvy_brand'] ?? '');
    $model = sanitize_text_field($raw_data['savvy_model'] ?? '');
    $sku = sanitize_text_field($raw_data['savvy_part_id'] ?? '');
    $cat = sanitize_text_field($raw_data['savvy_category'] ?? '');
    $upc = sanitize_text_field($raw_data['savvy_upc'] ?? '');
    $ean = sanitize_text_field($raw_data['savvy_ean'] ?? '');

    $specs = [
        'cpu_socket' => sanitize_text_field($raw_data['cpu_socket'] ?? ''),
        'ram_type' => sanitize_text_field($raw_data['ram_ddr_type'] ?? ''),
        // Can add more fields here as needed
    ];
    
    $res = $wpdb->insert($wpdb->prefix . 'savvy_catalogue', [
        'title' => $brand . ' ' . $model,
        'brand' => $brand,
        'model' => $model,
        'sku' => $sku,
        'category' => $cat,
        'upc' => $upc,
        'ean' => $ean,
        'specs' => json_encode($specs),
        'stock_count' => 0
    ]);
    
    if( $res ) {
        wp_send_json_success();
    } else {
        wp_send_json_error( $wpdb->last_error );
    }
}

// 6. Global Footer (Modals)
add_action('admin_footer', 'savvy_ops_global_modals');
function savvy_ops_global_modals() {
    // Only load on Savvy Pages
    if ( isset( $_GET['page'] ) && strpos( $_GET['page'], 'savvy' ) !== false ) {
        include_once plugin_dir_path( __FILE__ ) . 'includes/partials/modal-unit-details.php';
    }
}
