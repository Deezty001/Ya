<?php
/**
 * SAVVY PC BUILDER - NESTED CATEGORIES & STANDALONE OPTIONS
 * Integrated with Savvy Catalogue for autofill.
 */

if (!defined('ABSPATH')) exit;

// 1. Register the Product Data Tab
add_filter('woocommerce_product_data_tabs', 'savvy_add_upgrades_tab');
function savvy_add_upgrades_tab($tabs) {
    $tabs['savvy_upgrades'] = array(
        'label'    => __('PC Upgrades', 'savvy-ops'),
        'target'   => 'savvy_upgrades_panel',
        'class'    => array('show_if_simple'),
        'priority' => 75,
    );
    return $tabs;
}

// 2. Render Management Panel
add_action('woocommerce_product_data_panels', 'savvy_render_upgrades_panel');
function savvy_render_upgrades_panel() {
    global $post, $wpdb;
    $upgrades = get_post_meta($post->ID, '_pc_upgrades_nested', true) ?: array();
    $categories = ['CPU', 'Cooler', 'Motherboard', 'RAM', 'Storage', 'GPU', 'PSU', 'Case'];
    
    ?>
    <div id="savvy_upgrades_panel" class="panel woocommerce_options_panel">
        <div id="savvy_master_container" style="padding: 15px;">
            <p><strong>Builder Logic (AJAX Enabled):</strong> Search parts instantly. Use "Link Base Spec" to sync the Standard Label.</p>
            <div id="savvy_rows">
                <?php foreach ($upgrades as $c_idx => $item) : 
                    $current_cat = isset($item['name']) ? $item['name'] : '';
                    $linked_base = isset($item['linked_base']) ? $item['linked_base'] : '';
                ?>
                    <?php if ($item['type'] === 'category') : ?>
                        <!-- Existing Category Row -->
                        <div class="savvy-cat-group" style="border: 2px solid #c4a577; padding: 15px; margin-bottom: 20px; background: #fff;">
                            <input type="hidden" name="item_type[]" value="category">
                            
                            <!-- Header Row 1: Category & Link -->
                            <div style="display:flex; gap:10px; margin-bottom:5px; align-items:center; background:#eee; padding:5px;">
                                <strong style="padding-left:5px;">Category:</strong>
                                <select name="cat_name[]" class="savvy-cat-selector" style="font-weight:bold; flex:1;">
                                    <option value="">-- Select Category --</option>
                                    <?php foreach($categories as $cat_opt): ?>
                                        <option value="<?php echo $cat_opt; ?>" <?php selected($current_cat, $cat_opt); ?>><?php echo $cat_opt; ?></option>
                                    <?php endforeach; ?>
                                </select>
                                
                                <strong style="padding-left:10px;">Link Base Spec:</strong>
                                <select name="cat_linked_base[]" class="savvy-base-link-selector" style="flex:1;">
                                    <option value="">-- None (Manual Label) --</option>
                                    <?php foreach($categories as $cat_opt): ?>
                                        <option value="<?php echo $cat_opt; ?>" <?php selected($linked_base, $cat_opt); ?>>Sync with <?php echo $cat_opt; ?></option>
                                    <?php endforeach; ?>
                                </select>
                                
                                <button type="button" class="remove-savvy-parent button" style="color:red;">Delete Group</button>
                            </div>

                            <!-- Header Row 2: Standard Label (Manual fallback) -->
                            <div style="display:flex; gap:10px; margin-bottom:10px; padding:5px;">
                                <label>Manual Standard Label (Fallback):</label>
                                <input type="text" name="cat_standard[]" value="<?php echo esc_attr($item['standard']); ?>" placeholder="e.g. 16GB (Only used if Not Linked)" style="flex:1;">
                            </div>
                            
                            <div class="savvy-sub-options" style="padding-left:30px; border-left: 2px dashed #ccc;">
                                <?php if(!empty($item['options'])) : foreach($item['options'] as $opt) : ?>
                                    <?php 
                                        $pid = isset($opt['part_id']) ? $opt['part_id'] : '';
                                        // Batch lookup used above? No, let's fix this N+1 via batching at top of function if possible,
                                        // For now, let's just use Savvy_DB for cleaner code since this is the Admin Edit screen (less traffic).
                                        // Actually, let's do it right.
                                        
                                        $p_title = 'Part #' . $pid;
                                        if($pid) {
                                            $part = Savvy_DB::get_part((int)$pid);
                                            if($part) $p_title = $part->title;
                                        }
                                    ?>
                                    <div class="savvy-sub-row" style="display:flex; gap:10px; margin-bottom:5px; align-items:center;">
                                        <!-- AJAX Picker -->
                                        <select class="savvy-part-picker-ajax" style="min-width:250px;" data-cat="<?php echo esc_attr($current_cat); ?>">
                                            <?php if($pid): ?>
                                                <option value="<?php echo esc_attr($pid); ?>" selected><?php echo esc_html($p_title); ?></option>
                                            <?php endif; ?>
                                        </select>
                                        
                                        <input type="text" name="sub_opt_label[<?php echo $c_idx; ?>][]" value="<?php echo esc_attr($opt['label']); ?>" placeholder="Upgrade Name" style="flex:2;">
                                        <input type="number" step="0.01" name="sub_opt_price[<?php echo $c_idx; ?>][]" value="<?php echo esc_attr($opt['price']); ?>" placeholder="+$ Price" style="flex:1; max-width:100px;">
                                        <input type="hidden" name="sub_opt_part_id[<?php echo $c_idx; ?>][]" value="<?php echo esc_attr($pid); ?>" class="savvy-part-id-input">
                                        
                                        <button type="button" class="remove-child button">&times;</button>
                                    </div>
                                <?php endforeach; endif; ?>
                            </div>
                            <button type="button" class="add-sub-opt button" data-idx="<?php echo $c_idx; ?>" style="margin-top:10px;">+ Add Upgrade Option</button>
                        </div>
                    <?php else : ?>
                        <!-- Standalone Row -->
                        <div class="savvy-standalone" style="border: 1px solid #ddd; padding: 10px; margin-bottom: 10px; background: #f9f9f9; display:flex; gap:10px; align-items:center;">
                            <input type="hidden" name="item_type[]" value="standalone">
                            <input type="hidden" name="cat_name[]" value="">
                            <input type="hidden" name="cat_linked_base[]" value="">
                            <input type="hidden" name="cat_standard[]" value="">
                            
                             <select class="savvy-part-picker-ajax" style="min-width:250px;" data-cat="ALL">
                                <!-- No pre-select logic for standalone implemented here just yet, assuming generic -->
                             </select>

                            <input type="text" name="standalone_label[]" value="<?php echo esc_attr($item['label']); ?>" placeholder="Standalone Option Name" style="flex:2;">
                            <input type="number" step="0.01" name="standalone_price[]" value="<?php echo esc_attr($item['price']); ?>" placeholder="Price" style="flex:1; max-width:100px;">
                            <button type="button" class="remove-savvy-parent button" style="color:red;">&times;</button>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="toolbar" style="padding:15px; border-top:1px solid #eee; background:#f4f4f4; display:flex; gap:10px;">
            <button type="button" id="add_cat_btn" class="button button-primary">+ Create New Category</button>
            <button type="button" id="add_opt_btn" class="button">+ Create Standalone Option</button>
        </div>

        <script>
        jQuery(document).ready(function($) {
            
            // Initial Init
            initAjaxSelects();

            function initAjaxSelects() {
                $('.savvy-part-picker-ajax:not(.select2-hidden-accessible)').each(function() {
                    var $el = $(this);
                    var cat = $el.data('cat') || 'ALL';
                    
                    $el.select2({
                        width: 'resolve',
                        placeholder: 'Search ' + cat + '...',
                        minimumInputLength: 0, // Allow opening to see defaults if we implemented recent?
                        ajax: {
                            url: ajaxurl,
                            dataType: 'json',
                            delay: 250,
                            data: function (params) {
                                return {
                                    action: 'savvy_search_parts',
                                    term: params.term, // search term
                                    category: $el.data('cat') // dynamic category
                                };
                            },
                            processResults: function (data) {
                                return {
                                    results: data.results
                                };
                            },
                            cache: true
                        }
                    });
                    
                    // On Select
                    $el.off('select2:select').on('select2:select', function (e) {
                         var data = e.params.data;
                         var id = data.id;
                         /* 
                            Select2 data.text might include category group info if grouped.
                            We want just the title. 
                         */
                         var text = data.text;
                         
                         var $row = $(this).closest('div');
                         
                         // Auto-fill label if empty or looks like default
                         var $nameInput = $row.find('input[type="text"]').first();
                         if($nameInput.val() === '' || $nameInput.val().indexOf('Upgrade Name') !== -1) {
                             $nameInput.val(text);
                         }
                         
                         // Fill Hidden ID
                         $row.find('.savvy-part-id-input').val(id);
                    });
                });
            }

            // 1. Add New Category Group
            $('#add_cat_btn').on('click', function() {
                var idx = $('#savvy_rows > div').length + Math.floor(Math.random() * 1000); 
                var catOpts = '<option value="">-- Select --</option>';
                <?php foreach($categories as $c) echo "catOpts += '<option value=\"$c\">$c</option>';"; ?>
                
                var html = '<div class="savvy-cat-group" style="border: 2px solid #c4a577; padding: 15px; margin-bottom: 20px; background: #fff;">' +
                    '<input type="hidden" name="item_type[]" value="category">' +
                    '<div style="display:flex; gap:10px; margin-bottom:5px; align-items:center; background:#eee; padding:5px;">' +
                    '<strong style="padding-left:5px;">Category:</strong>' +
                    '<select name="cat_name[]" class="savvy-cat-selector" style="font-weight:bold; flex:1;">'+catOpts+'</select>' +
                    '<strong style="padding-left:10px;">Link Base Spec:</strong>' +
                    '<select name="cat_linked_base[]" class="savvy-base-link-selector" style="flex:1;"><option value="">-- None --</option><?php foreach($categories as $c) echo "<option value=\"$c\">Sync with $c</option>"; ?></select>' +
                    '<button type="button" class="remove-savvy-parent button" style="color:red;">Delete Group</button></div>' + 
                    '<div style="display:flex; gap:10px; margin-bottom:10px; padding:5px;"><label>Manual Standard Label:</label><input type="text" name="cat_standard[]" placeholder="Standard Label" style="flex:1;"></div>' +
                    '<div class="savvy-sub-options" style="padding-left:30px; border-left: 2px dashed #ccc;"></div>' +
                    '<button type="button" class="add-sub-opt button" data-idx="'+idx+'" style="margin-top:10px;">+ Add Upgrade Option</button></div>';
                
                $('#savvy_rows').append(html);
            });

            // 2. Add Standalone Option
            $('#add_opt_btn').on('click', function() {
                var html = '<div class="savvy-standalone" style="border: 1px solid #ddd; padding: 10px; margin-bottom: 10px; background: #f9f9f9; display:flex; gap:10px; align-items:center;">' +
                    '<input type="hidden" name="item_type[]" value="standalone"><input type="hidden" name="cat_name[]" value=""><input type="hidden" name="cat_linked_base[]" value=""><input type="hidden" name="cat_standard[]" value="">' +
                    '<select class="savvy-part-picker-ajax" style="min-width:250px;" data-cat="ALL"></select>' +
                    '<input type="text" name="standalone_label[]" placeholder="Standalone Name" style="flex:2;">' +
                    '<input type="number" step="0.01" name="standalone_price[]" placeholder="Price" style="flex:1; max-width:100px;">' +
                    '<button type="button" class="remove-savvy-parent button" style="color:red;">&times;</button></div>';
                
                var $node = $(html);
                $('#savvy_rows').append($node);
                initAjaxSelects();
            });

            // 3. Add Sub-Option logic
            $(document).on('click', '.add-sub-opt', function() {
                var idx = $(this).data('idx');
                var parentCat = $(this).closest('.savvy-cat-group').find('.savvy-cat-selector').val();
                
                var html = '<div class="savvy-sub-row" style="display:flex; gap:10px; margin-bottom:5px; align-items:center;">' + 
                           '<select class="savvy-part-picker-ajax" style="min-width:250px;" data-cat="'+(parentCat||'')+'"></select>' +
                           '<input type="text" name="sub_opt_label['+idx+'][]" placeholder="Upgrade Name" style="flex:2;">' + 
                           '<input type="number" step="0.01" name="sub_opt_price['+idx+'][]" placeholder="Price" style="flex:1; max-width:100px;">' + 
                           '<input type="hidden" name="sub_opt_part_id['+idx+'][]" class="savvy-part-id-input">' +
                           '<button type="button" class="remove-child button">&times;</button></div>';
                
                var $node = $(html);
                $(this).siblings('.savvy-sub-options').append($node);
                initAjaxSelects();
            });

            // 4. Update Category + Auto Link
            $(document).on('change', '.savvy-cat-selector', function() {
                var newCat = $(this).val();
                var $group = $(this).closest('.savvy-cat-group');
                
                // Auto-set the "Link Base Spec" if matches
                $group.find('.savvy-base-link-selector').val(newCat);

                // Update sub options data-cat
                $group.find('.savvy-part-picker-ajax').each(function() {
                    $(this).data('cat', newCat); 
                    $(this).attr('data-cat', newCat);
                });
            });

            $(document).on('click', '.remove-savvy-parent', function() { $(this).closest('div').parent().find( $(this).closest('div') ).remove(); });
            $(document).on('click', '.remove-child', function() { $(this).closest('.savvy-sub-row').remove(); });
        });
        </script>
    </div>
    <?php
}

// 3. Save Logic
add_action('woocommerce_process_product_meta', 'savvy_save_upgrades_data');
function savvy_save_upgrades_data($post_id) {
    if (isset($_POST['item_type'])) {
        $final_data = array();
        $standalone_ptr = 0;
        
        foreach ($_POST['item_type'] as $i => $type) {
            
            if ($type === 'category') {
                $sub_opts = array();
                if (isset($_POST['sub_opt_label'][$i])) {
                    foreach ($_POST['sub_opt_label'][$i] as $j => $label) {
                        $price = isset($_POST['sub_opt_price'][$i][$j]) ? $_POST['sub_opt_price'][$i][$j] : 0;
                        $pid = isset($_POST['sub_opt_part_id'][$i][$j]) ? $_POST['sub_opt_part_id'][$i][$j] : '';
                        if(!empty($label)) {
                            $sub_opts[] = array(
                                'label' => sanitize_text_field($label), 
                                'price' => sanitize_text_field($price),
                                'part_id' => sanitize_text_field($pid)
                            );
                        }
                    }
                }
                
                $final_data[] = array(
                    'type' => 'category', 
                    'name' => sanitize_text_field($_POST['cat_name'][$i]), 
                    'linked_base' => sanitize_text_field($_POST['cat_linked_base'][$i]),
                    'standard' => sanitize_text_field($_POST['cat_standard'][$i]), 
                    'options' => $sub_opts
                );
            } else {
                // Standalone
                $s_label = isset($_POST['standalone_label'][$standalone_ptr]) ? $_POST['standalone_label'][$standalone_ptr] : '';
                $s_price = isset($_POST['standalone_price'][$standalone_ptr]) ? $_POST['standalone_price'][$standalone_ptr] : 0;
                
                if(!empty($s_label)) {
                    $final_data[] = array('type' => 'standalone', 'label' => sanitize_text_field($s_label), 'price' => sanitize_text_field($s_price));
                }
                $standalone_ptr++;
            }
        }
        update_post_meta($post_id, '_pc_upgrades_nested', $final_data);
    }
}

// 4. Shared Builder HTML Generator (Frontend & Admin)
function savvy_get_builder_html($product_id, $context = 'frontend', $current_map = array(), $manual_config = array()) {
    $product = wc_get_product($product_id);
    if(!$product) return '';
    $data = get_post_meta($product_id, '_pc_upgrades_nested', true);
    if (empty($data) || !is_array($data)) $data = [];

    ob_start();
    $cls = ($context === 'admin') ? 'savvy-admin-builder' : 'savvy-frontend-builder';
    
    // PERF: Batch Fetch Parts to avoid N+1
    $all_pids = [];
    foreach ($data as $item) {
        if ($item['type'] === 'category' && !empty($item['options'])) {
            foreach ($item['options'] as $opt) {
                if(!empty($opt['part_id'])) $all_pids[] = $opt['part_id'];
            }
        }
    }
    $part_lookup = Savvy_DB::get_parts_batch($all_pids);

    echo '<div class="savvy-builder-wrap '.$cls.'" data-base-price="' . esc_attr($product->get_price()) . '">';
    
    foreach ($data as $item) {
        if ($item['type'] === 'category') {
            $slug = sanitize_title($item['name']) . rand(100,999);
            $cat_name = strtoupper($item['name']); 
            
            // Standard Label Logic
            $std_label = $item['standard'];
            if(!empty($item['linked_base'])) {
                $synced_label = get_post_meta($product_id, '_savvy_spec_label_' . strtolower($item['linked_base']), true);
                if(!empty($synced_label)) $std_label = $synced_label;
            }
            if(empty($std_label)) $std_label = 'Standard ' . $item['name'];
            
            // Selected check
            $selected_pid = isset($current_map[$cat_name]) ? $current_map[$cat_name] : 'std';

            echo '<div class="savvy-group" style="margin-bottom:15px; padding:10px; background:#f9f9f9; border-radius:5px; border:1px solid #ddd;">';
            echo '<p class="savvy-title" style="font-weight:bold; margin-bottom:5px;">'.esc_html($item['name']).' Upgrade:</p>';
            echo '<div class="savvy-flex" style="display:flex; flex-wrap:wrap; gap:10px;">';
            
            // Standard Option
            $is_std_checked = ($selected_pid === 'std' || $selected_pid === '') ? 'checked' : '';
            echo '<div>';
            echo '<input type="radio" class="savvy-radio" name="savvy['.$slug.']" id="std_'.$slug.'" value="0" data-price="0" '.$is_std_checked.'>';
            echo '<label class="savvy-btn" for="std_'.$slug.'"> '.esc_html($std_label).' <span class="savvy-price">(Included)</span></label>';
            echo '</div>';
            
            foreach ($item['options'] as $idx => $opt) {
                $id = $slug . $idx;
                $pid = isset($opt['part_id']) ? $opt['part_id'] : '';
                
                // N+1 FIX: Use Batch Lookup
                $p_title = 'Part #' . $pid;
                $p_cat = '';
                if(isset($part_lookup[$pid])) {
                    $p_title = $part_lookup[$pid]->title;
                    $p_cat = $part_lookup[$pid]->category;
                }
                
                // Fallback for empty title if not found in lookup
                if(empty($opt['part_id'])) $p_title = 'Custom Choice';

                $is_checked = ($selected_pid == $pid && $pid != '') ? 'checked' : '';

                echo '<div>';
                echo '<input type="radio" class="savvy-radio" name="savvy['.$slug.']" id="'.$id.'" value="'.$opt['price'].'" data-price="'.$opt['price'].'" data-replace-cat="'.esc_attr($cat_name).'" data-part-id="'.esc_attr($pid).'" '.$is_checked.'>';
                echo '<label class="savvy-btn" for="'.$id.'"> '.esc_html($opt['label']).' <span class="savvy-price">(+$'.$opt['price'].')</span></label>';
                echo '</div>';
            }
            echo '</div></div>';
        } else {
            // Standalone
            $slug = sanitize_title($item['label']) . rand(100,999);
            echo '<div class="savvy-group standalone" style="margin-bottom:10px;">';
            echo '<div class="savvy-flex">';
            echo '<input type="checkbox" class="savvy-check" name="savvy_chk[]" id="chk_'.$slug.'" value="'.$item['price'].'" data-price="'.$item['price'].'">';
            echo '<label class="savvy-btn" for="chk_'.$slug.'"> '.esc_html($item['label']).' <span class="savvy-price">(+$'.$item['price'].')</span></label>';
            echo '</div></div>';
        }
    }
    
    // MANUAL OVERRIDES (ADMIN ONLY)
    if ($context === 'admin') {
        global $wpdb;
        $t_cat = $wpdb->prefix . 'savvy_catalogue';
        $all_parts = $wpdb->get_results("SELECT id, title, category FROM $t_cat ORDER BY category ASC, title ASC");
        
        $manual_opts = '';
        if($all_parts) {
            foreach($all_parts as $p) {
                // Encode basic data for JS
                $manual_opts .= '<option value="'.$p->id.'" data-cat="'.$p->category.'">['.$p->category.'] '.$p->title.'</option>';
            }
        }

        // Clean UI - Looks like a normal toolbar
        echo '<div class="savvy-admin-manual-tools" style="margin-top:20px; padding:15px; background:#f9f9f9; border-top:1px solid #ddd;">';
        echo '<strong style="display:block; margin-bottom:10px;">Add Component</strong>';
        
        echo '<div style="display:flex; gap:10px; align-items:center;">';
        
        // Picker
        echo '<select id="savvy_manual_part_selector" style="width:50%;" class="wc-enhanced-select"><option value="">-- Search Catalogue --</option>'.$manual_opts.'</select>';
        
        // Category Force
        echo '<select id="savvy_manual_cat_force" style="width:25%;">';
        echo '<option value="">(Auto Cat)</option>';
        $cats = ['CPU','Cooler','Motherboard','RAM','Storage','GPU','PSU','Case'];
        foreach($cats as $c) echo "<option value='$c'>$c</option>";
        echo '</select>';

        // Price Input
        echo '<input type="number" id="savvy_manual_price" step="0.01" placeholder="Cost ($)" style="width:15%; max-width:100px;">';

        // Add Btn
        echo '<button type="button" class="button button-primary" id="savvy_add_manual_override">Add</button>';
        echo '</div>';
        
        echo '<div id="savvy_manual_added_list" style="margin-top:10px;">';
        
        // RESTORE MANUAL ITEMS
        if(!empty($manual_config) && is_array($manual_config)) {
            foreach($manual_config as $m) {
                if(!isset($m['id'])) continue;
                $price = number_format(floatval($m['price']), 2);
                $cat = esc_html($m['cat']);
                $pid = esc_attr($m['id']);
                $label = esc_html($m['label']);
                
                echo '<div class="savvy-group manual-entry" style="margin-bottom:10px; padding:10px; border:1px solid #ddd; background:#fff;">';
                echo '<div class="savvy-flex" style="display:flex; align-items:center; gap:10px;">';
                echo '<input type="checkbox" class="savvy-check" checked name="savvy_manual[]" value="'.$price.'" data-price="'.$price.'" data-replace-cat="'.$cat.'" data-part-id="'.$pid.'">';
                echo '<label class="savvy-btn" style="flex:1;">';
                echo '<strong>'.$cat.':</strong> '.$label;
                echo ' <span class="savvy-price" style="color:#2271b1; font-weight:bold;">(+$'.$price.')</span>';
                echo '</label>';
                echo '</div></div>';
            }
        }
        
        echo '</div>';
        echo '</div>';
    }

    // Hidden container
    echo '<div id="savvy-hidden-inputs-'.$context.'"></div>';
    echo '<input type="hidden" name="savvy_upgrade_map" id="savvy_upgrade_map-'.$context.'" value="">'; 
    
    echo '</div>'; 
    return ob_get_clean();
}

// 5. Frontend Render Action
add_action('woocommerce_before_add_to_cart_button', 'savvy_display_upgrades_frontend');
function savvy_display_upgrades_frontend() {
    global $product;
    if(!$product) return;
    echo savvy_get_builder_html($product->get_id(), 'frontend');
    ?>
    <script>
    jQuery(document).ready(function($) {
        var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
        var isSubmitting = false;

        // Shared Helper for Additive Checks
        function isAdditiveCategory(cat) {
            var additiveCats = ['storage', 'ssd', 'hdd', 'cooler', 'fan'];
            if(!cat) return false;
            return additiveCats.some(function(ac) { 
                return cat.toLowerCase().indexOf(ac) !== -1; 
            });
        }

        function updateSavvySelection() {
            var total = parseFloat($('.savvy-builder-wrap').data('base-price'));
            var hiddenInputs = '';
            var upgradeMap = {}; 
            var upgradeNames = [];
            
            $('.savvy-select-ajax option:selected, .savvy-radio:checked, .savvy-check:checked').each(function() {
                // Determine element type and get data
                var $el = $(this);
                // For select2/ajax
                if($el.is('option')) $el = $el.parent(); 
                
                var price = parseFloat($el.find(':selected').data('price')) || parseFloat($el.data('price')) || 0;
                // If standard input
                if($el.is('input')) {
                     var label = $el.next('label').contents().get(0).nodeValue.trim();
                } else if ($el.is('select')) {
                     var label = $el.find('option:selected').text();
                     price = parseFloat($el.find('option:selected').data('price')) || 0;
                }

                var replaceCat = $el.data('replace-cat');
                var partId = $el.val() || $el.data('part-id');
                
                if(replaceCat && partId) { 
                    if(isAdditiveCategory(replaceCat)) {
                        upgradeMap[replaceCat + '::' + partId] = partId; // Additive
                    } else {
                        upgradeMap[replaceCat] = partId; // Replacement
                    }
                }
                
                // Add to total
                // Note: Logic needs to handle if price is 'diff' or 'total'. Assuming differential for upgrades.
                // Re-checking previous logic: "total += price"
                // The prompt implies we are building on the previous code.
                total += price;

                // Collect names
                if(label) upgradeNames.push(label);
            });
            
            // Store raw map
            $('#savvy_upgrade_map-frontend').val(JSON.stringify(upgradeMap)); 
            $('#savvy-hidden-inputs-frontend').data('names', upgradeNames.join(', '));
            $('#savvy-hidden-inputs-frontend').data('cost', total - parseFloat($('.savvy-builder-wrap').data('base-price')));

            var formattedPromise = '$' + total.toLocaleString(undefined, {minimumFractionDigits: 2});
            $('.price .woocommerce-Price-amount bdi, .price .amount').first().html(formattedPromise);
        }

        // Bind events
        $('.savvy-radio, .savvy-check').on('change', updateSavvySelection);
        $(document.body).on('change', '.savvy-select-ajax', updateSavvySelection); // Future proof for select2
        setTimeout(updateSavvySelection, 500);

        // Intercept Add to Cart
        $('form.cart').on('submit', function(e) {
            if(isSubmitting) return true; // Let it pass if we already processed
            
            var upgradeMapVal = $('#savvy_upgrade_map-frontend').val();
            // Only intercept if we have upgrades
            if(!upgradeMapVal || upgradeMapVal === '{}') return true;

            e.preventDefault();
            var $form = $(this);
            var $btn = $form.find('.single_add_to_cart_button');
            $btn.addClass('loading');

            var payload = {
                action: 'savvy_save_config',
                product_id: <?php echo $product->get_id(); ?>,
                upgrade_map: JSON.parse(upgradeMapVal),
                upgrade_names: $('#savvy-hidden-inputs-frontend').data('names'),
                extra_cost: $('#savvy-hidden-inputs-frontend').data('cost'),
                manual_config: {} // TODO: Add manual config if needed
            };

            $.post(ajaxurl, payload, function(res) {
                $btn.removeClass('loading');
                if(res.success) {
                    // Inject Config ID
                    if($form.find('input[name="savvy_config_id"]').length === 0) {
                        $form.append('<input type="hidden" name="savvy_config_id" value="'+res.data.config_id+'">');
                    } else {
                        $('input[name="savvy_config_id"]').val(res.data.config_id);
                    }
                    
                    // Allow submit
                    isSubmitting = true;
                    $form.submit();
                } else {
                    alert('Error saving configuration: ' + (res.data || 'Unknown error'));
                }
            }).fail(function() {
                $btn.removeClass('loading');
                alert('Server error saving configuration.');
            });
        });
    });
    </script>
    <?php
}

// 6. Admin Order "Configure" Button
add_action( 'woocommerce_after_order_itemmeta', 'savvy_admin_order_configure_btn', 50, 3 );
function savvy_admin_order_configure_btn( $item_id, $item, $product ) {
    if( ! $product ) return;
    echo '<div style="margin-top:10px; clear:both;">';
        echo '<button type="button" class="button button-small savvy-config-trigger" data-item-id="'.$item_id.'" data-product-id="'.$product->get_id().'">⚙️ Configure PC</button>';
    echo '</div>';
}

// 7. Admin JS and Modal Logic
add_action('admin_footer', 'savvy_admin_builder_scripts');
function savvy_admin_builder_scripts() {
    $screen = get_current_screen();
    
    // Allow any screen that looks like an order screen
    $allow = false;
    if($screen) {
        if($screen->id === 'shop_order') $allow = true;
        if(strpos($screen->id, 'wc-orders') !== false) $allow = true; // HPOS
        if(strpos($screen->id, 'order') !== false) $allow = true; 
        if($screen->base === 'post' && $screen->post_type === 'shop_order') $allow = true; // Legacy Edit
    }
    
    if(!$allow) return;

    ?>
    <style>
        #savvy-admin-modal-overlay { position: fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index: 100000; display:none; justify-content:center; align-items:center; }
        #savvy-admin-modal { background:#fff; width:90%; max-width:800px; padding:20px; border-radius:5px; max-height:90vh; overflow-y:auto; box-shadow: 0 4px 10px rgba(0,0,0,0.2); position:relative; }
        .savvy-admin-builder .savvy-group { border: 1px solid #ccc; margin-bottom:15px; padding:10px; }
    </style>
    <div id="savvy-admin-modal-overlay">
        <div id="savvy-admin-modal">
            <h2 style="margin-top:0;">Configure PC Order</h2>
            <div id="savvy-admin-builder-content" style="padding:10px;">Loading...</div>
            <div style="text-align:right; margin-top:15px; border-top:1px solid #eee; padding-top:10px;">
                <button class="button" id="savvy-close-modal">Cancel</button>
                <button class="button button-primary" id="savvy-save-config">Save Configuration</button>
            </div>
        </div>
    </div>
    <script>
    jQuery(document).ready(function($) {
        console.log('Savvy Admin Builder Loaded. Screen ID: <?php echo $screen->id; ?>');
        var nonce = '<?php echo wp_create_nonce('savvy_admin_builder_nonce'); ?>';
        
        var currentItemId = 0;
        var currentProductId = 0;

        // Shared Helper
        function isAdditiveCategory(cat) {
            var additiveCats = ['storage', 'ssd', 'hdd', 'cooler', 'fan'];
            if(!cat) return false;
            return additiveCats.some(function(ac) { 
                return cat.toLowerCase().indexOf(ac) !== -1; 
            });
        }

        // Use 'body' delegation for robust event handling
        $('body').on('click', '.savvy-config-trigger', function(e) {
            e.preventDefault();
            console.log('Configure Clicked');
            
            currentItemId = $(this).data('item-id');
            currentProductId = $(this).data('product-id');
            
            $('#savvy-admin-modal-overlay').css('display', 'flex');
            $('#savvy-admin-builder-content').html('<p>Loading options...</p>');
            
            $.ajax({
                url: ajaxurl,
                method: 'GET',
                data: { 
                    action: 'savvy_get_admin_builder', 
                    product_id: currentProductId, 
                    item_id: currentItemId,
                    nonce: nonce 
                },
                success: function(res) { 
                    $('#savvy-admin-builder-content').html(res); 
                    $(document.body).trigger('wc-enhanced-select-init'); // Init Select2
                },
                error: function(err) {
                    console.error('Error loading builder', err);
                    $('#savvy-admin-builder-content').html('<p style="color:red">Error loading options. Check console.</p>');
                }
            });
        });

        $('body').on('click', '#savvy-close-modal', function(e) { 
            e.preventDefault();
            $('#savvy-admin-modal-overlay').hide(); 
        });

        // Manual Override Handler
        $('body').on('click', '#savvy_add_manual_override', function() {
            var $sel = $('#savvy_manual_part_selector option:selected');
            var partId = $sel.val();
            var partLabel = $sel.text(); 
            var pureLabel = partLabel.replace(/^\[.*?\]\s*/, '');
            
            var autoCat = $sel.data('cat');
            var forcedCat = $('#savvy_manual_cat_force').val();
            var price = parseFloat($('#savvy_manual_price').val()) || 0;
            
            var finalCat = forcedCat ? forcedCat : autoCat;
            
            if(!partId) { alert('Please select a part first.'); return; }
            if(!finalCat) { alert('Could not detect category. Please force a category.'); return; }

            // VALIDATION: Strict vs Additive
            if(!isAdditiveCategory(finalCat)) {
                // Strict Category (CPU, GPU, etc.) - Only 1 Allowed!
                
                // 1. Check existing Manual Entries
                var existingManual = false;
                $('.manual-entry input').each(function() {
                    if($(this).data('replace-cat') === finalCat) existingManual = true;
                });
                
                if(existingManual) {
                    alert('Error: You already have a Manual Upgrade for [' + finalCat + ']. Please remove it first before adding a new one.');
                    return;
                }
                
                // 2. Check existing Standard Upgrades
                var existingStandard = false;
                $('.savvy-radio:checked').each(function() {
                     // Check if an upgrade is selected (val > 0) OR if it's just the default included one (val=0)
                     if($(this).data('replace-cat') === finalCat && parseFloat($(this).val()) > 0) {
                        existingStandard = true;
                    }
                });
                
                if(existingStandard) {
                    alert('Error: A Standard Upgrade for [' + finalCat + '] is already selected. Please switch it to "Standard/Included" before adding a manual override.');
                    return;
                }
            }
            
            var slug = 'manual_' + partId + '_' + Date.now();
            
            // Clean looking row, matching others
            var html = '<div class="savvy-group manual-entry" style="margin-bottom:10px; padding:10px; border:1px solid #ddd; background:#fff;">';
            html += '<div class="savvy-flex" style="display:flex; align-items:center; gap:10px;">';
            
            // Checkbox checked by default
            html += '<input type="checkbox" class="savvy-check" checked name="savvy_manual[]" value="'+price+'" data-price="'+price+'" data-replace-cat="'+finalCat+'" data-part-id="'+partId+'">';
            
            // Label
            html += '<label class="savvy-btn" style="flex:1;">';
            html += '<strong>'+finalCat+':</strong> '+pureLabel;
            html += ' <span class="savvy-price" style="color:#2271b1; font-weight:bold;">(+$'+price.toFixed(2)+')</span>';
            html += '</label>';
            html += '</div></div>';
            
            $('#savvy_manual_added_list').append(html);
            
            // Reset fields
            $('#savvy_manual_price').val('');
        });

        $('body').on('click', '#savvy-save-config', function(e) {
            e.preventDefault();
            var upgradeMap = {};
            var names = [];
            var extraPrice = 0;
            var manualConfig = []; // Array to persist manual items

            $('#savvy-admin-builder-content .savvy-radio:checked, #savvy-admin-builder-content .savvy-check:checked').each(function() {
                var price = parseFloat($(this).data('price')) || 0;
                
                // Robust label extraction
                var label = '';
                var $labelEl = $(this).next('label');
                if($labelEl.length) {
                    label = $labelEl.text().trim();
                    label = label.replace(/\(\+\$[\d\.]+\)$/, '').trim();
                    label = label.replace(/\(Included\)$/, '').trim();
                }

                var replaceCat = $(this).data('replace-cat');
                var partId = $(this).data('part-id');
                
                if(replaceCat && partId) { 
                    if(isAdditiveCategory(replaceCat)) {
                         upgradeMap[replaceCat + '::' + partId] = partId; // Additive Key
                    } else {
                         upgradeMap[replaceCat] = partId; // Replacement Key
                    }
                }
                
                extraPrice += price;
                
                if (price > 0 || $(this).hasClass('savvy-check')) {
                    if(label) names.push(label);
                }

                // If this is a manual entry (savvy-check inside manual-entry)
                if($(this).closest('.manual-entry').length > 0) {
                     // Extract pure label (remove "CAT: " prefix)
                     var niceLabel = label.replace(new RegExp('^'+replaceCat+':\\s*'), '');
                     manualConfig.push({
                         id: partId,
                         cat: replaceCat,
                         price: price,
                         label: niceLabel
                     });
                }
            });

            var $btn = $(this);
            var originalText = $btn.text();
            $btn.text('Saving...').prop('disabled', true);

            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: {
                    action: 'savvy_save_admin_builder',
                    nonce: nonce,
                    item_id: currentItemId,
                    upgrade_map: upgradeMap,
                    upgrade_names: names.join(' | '),
                    extra_cost: extraPrice,
                    manual_config: manualConfig // Send JSON data
                },
                success: function(res) {
                    alert('Configuration Saved! Page will reload.');
                    location.reload();
                },
                error: function(err) {
                    alert('Save Failed');
                    $btn.text(originalText).prop('disabled', false);
                }
            });
        });
    });
    </script>
    <?php
}

// 8. AJAX Handlers
add_action('wp_ajax_savvy_get_admin_builder', 'savvy_ajax_get_admin_builder');
function savvy_ajax_get_admin_builder() {
    // SECURITY: Strictly restrict to Editors/Admins for this backend tool
    Savvy_DB::verify_ajax('savvy_admin_builder_nonce', 'edit_shop_orders');
    
    $pid = intval($_REQUEST['product_id']);
    $iid = intval($_REQUEST['item_id']);
    $item = new WC_Order_Item_Product($iid);
    $existing = $item->get_meta('_savvy_upgrade_map'); 
    $manual = $item->get_meta('_savvy_manual_config'); // Fetch manual config
    if(!is_array($manual)) $manual = [];
    
    echo savvy_get_builder_html($pid, 'admin', $existing, $manual);
    wp_die();
}

add_action('wp_ajax_savvy_save_admin_builder', 'savvy_ajax_save_admin_builder');
function savvy_ajax_save_admin_builder() {
    // SECURITY: Strictly restrict to Editors/Admins
    Savvy_DB::verify_ajax('savvy_admin_builder_nonce', 'edit_shop_orders');

    $iid = intval($_POST['item_id']);
    $map = isset($_POST['upgrade_map']) ? $_POST['upgrade_map'] : [];
    $names = sanitize_text_field($_POST['upgrade_names']);
    $cost = floatval($_POST['extra_cost']);
    $manual = isset($_POST['manual_config']) ? $_POST['manual_config'] : []; // Get Manual Config

    $item = new WC_Order_Item_Product($iid);
    $product = $item->get_product();
    if(!$product) wp_die('No product');

    $base = (float)$product->get_price(); 
    $new_total = $base + $cost;

    $item->update_meta_data('_savvy_upgrade_map', $map);
    $item->update_meta_data('_savvy_manual_config', $manual); // Save Manual Config
    $item->update_meta_data(__('Selected Upgrades', 'savvy-ops'), $names);
    $item->update_meta_data(__('Upgrades Cost', 'savvy-ops'), '+$' . $cost);
    $item->set_subtotal($new_total * $item->get_quantity()); 
    $item->set_total($new_total * $item->get_quantity());
    $item->save();
    
    $order = $item->get_order();
    if($order) {
        $order->calculate_totals();
        $order->save();
        
        // Trigger Ops Sync Refresh
        if(function_exists('savvy_ops_refresh_components')) {
            savvy_ops_refresh_components($order->get_id());
        }
    }
    wp_die('success');
}

// 8b. AJAX Save Config (Connector Strategy)
add_action('wp_ajax_savvy_save_config', 'savvy_ajax_save_config');
add_action('wp_ajax_nopriv_savvy_save_config', 'savvy_ajax_save_config');

function savvy_ajax_save_config() {
    // Frontend is public.
    // Ideally we verify a nonce, e.g. 'savvy_frontend_nonce' printed in HTML.
    // For now, allow public access but ensure data is sanitized.
    
    $upgrade_map = isset($_POST['upgrade_map']) ? $_POST['upgrade_map'] : [];
    $manual_config = isset($_POST['manual_config']) ? $_POST['manual_config'] : [];
    $base_product_id = intval($_POST['product_id']);
    
    // Validate
    if(!$base_product_id) wp_send_json_error('No Product ID');

    // 2. Prepare Data
    $config_data = [
        'upgrade_map' => $upgrade_map,
        'manual_config' => $manual_config,
        'upgrade_names' => sanitize_text_field($_POST['upgrade_names'] ?? ''),
        'extra_cost' => floatval($_POST['extra_cost'] ?? 0),
        'timestamp' => time()
    ];

    // 3. Save via Helper
    $config_id = Savvy_DB::save_config($base_product_id, $config_data);
    $hash = hash('sha256', json_encode($config_data));

    if($config_id) {
        wp_send_json_success([
            'config_id' => $config_id,
            'hash' => $hash
        ]);
    } else {
        wp_send_json_error('Database Save Failed.');
    }
}

// 9. Cart Hooks (Data Persistence)
add_filter('woocommerce_add_cart_item_data', 'savvy_add_cart_meta', 10, 3);
function savvy_add_cart_meta($cart_item_data, $product_id, $variation_id) {
    global $wpdb;
    
    // 1. Connector Strategy: Use Config ID
    if(isset($_POST['savvy_config_id'])) {
        $cid = intval($_POST['savvy_config_id']);
        $table = $wpdb->prefix . 'savvy_configurations';
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $cid));
        
        if($row) {
            $data = json_decode($row->configuration_data, true);
            
            $cart_item_data['_savvy_config_id'] = $cid;
            // Hydrate for display/logic (but won't be saved to order meta if we change save logic)
            $cart_item_data['savvy_upgrade_map'] = $data['upgrade_map']; 
            $cart_item_data['savvy_manual_config'] = $data['manual_config'];
            $cart_item_data['savvy_upg_names'] = $data['upgrade_names']; // String in DB
            $cart_item_data['savvy_config_cost'] = $data['extra_cost'];
        }
    } 
    // 2. Fallback: Legacy Direct Post (keep for safety or if JS fails)
    elseif(isset($_POST['savvy_upgrade_map'])) {
        $cart_item_data['savvy_upgrade_map'] = json_decode(stripslashes($_POST['savvy_upgrade_map']), true);
        $cart_item_data['savvy_upg_names'] = $_POST['savvy_upg_names'];
        $cart_item_data['savvy_upg_prices'] = $_POST['savvy_upg_prices'];
    }
    return $cart_item_data;
}

add_action('woocommerce_before_calculate_totals', 'savvy_recalc_cart_price');
function savvy_recalc_cart_price($cart) {
    if (is_admin() && !defined('DOING_AJAX')) return;

    foreach ($cart->get_cart() as $key => $value) {
        $extra = 0;
        
        // Connector Strategy: Use pre-calculated cost
        if(isset($value['savvy_config_cost'])) {
            $extra = floatval($value['savvy_config_cost']);
        }
        // Legacy: Sum array
        elseif(isset($value['savvy_upg_prices'])) {
             foreach($value['savvy_upg_prices'] as $p) $extra += floatval($p);
        }
        
        if($extra > 0) {
            $value['data']->set_price($value['data']->get_price() + $extra);
        }
    }
}

add_action('woocommerce_checkout_create_order_line_item', 'savvy_save_order_meta', 10, 4);
function savvy_save_order_meta($item, $cart_item_key, $values, $order) {
    // 1. Connector Strategy: Save ID Only
    if(isset($values['_savvy_config_id'])) {
        $item->add_meta_data('_savvy_config_id', $values['_savvy_config_id']);
        // Do NOT determine map here. Ops Sync will dehydrate later.
    } elseif(isset($values['savvy_upgrade_map'])) {
        // Legacy fallback
        $item->add_meta_data('_savvy_upgrade_map', $values['savvy_upgrade_map']);
    }

    // 2. Save Display Meta (for Customer Invoice/Emails)
    if(isset($values['savvy_upg_names'])) {
        $names = is_array($values['savvy_upg_names']) ? implode(' | ', $values['savvy_upg_names']) : $values['savvy_upg_names'];
        $item->add_meta_data('Selected Upgrades', $names);
    }
    
    // 3. Save Cost Meta
    if(isset($values['savvy_config_cost'])) {
        $item->add_meta_data('Upgrades Cost', '+$' . number_format($values['savvy_config_cost'], 2));
    } elseif(isset($values['savvy_upg_prices'])) {
         $extra = 0;
         foreach($values['savvy_upg_prices'] as $p) $extra += floatval($p);
         $item->add_meta_data('Upgrades Cost', '+$' . $extra);
    }
}
