<?php
// includes/modules/custom-tabs.php
// Add Custom Product Tabs to Woocommerce Single Product Pages
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 1. Register 'Custom Tabs' Custom Post Type (For GLOBAL Tabs like FAQ)
 */
function savvy_register_custom_tabs_cpt() {
    $labels = array(
        'name'               => __('Custom Tabs', 'savvy-ops'),
        'singular_name'      => __('Custom Tab', 'savvy-ops'),
        'menu_name'          => __('Custom Tabs', 'savvy-ops'),
        'add_new'            => __('Add New', 'savvy-ops'),
        'add_new_item'       => __('Add New Custom Tab', 'savvy-ops'),
        'edit_item'          => __('Edit Custom Tab', 'savvy-ops'),
        'new_item'           => __('New Custom Tab', 'savvy-ops'),
    );
    $args = array(
        'labels'        => $labels,
        'public'        => false,
        'show_ui'       => true,
        'show_in_menu'  => 'edit.php?post_type=product',
        'capability_type' => 'post',
        'hierarchical'  => false,
        'supports'      => array('title', 'editor'),
        'menu_icon'     => 'dashicons-welcome-widgets-menus',
        'show_in_rest'  => true,
    );
    register_post_type('custom_product_tab', $args);
}
add_action('init', 'savvy_register_custom_tabs_cpt');

/**
 * 2. Handle Category Mapping for Global Tabs
 */
function savvy_add_custom_tab_meta_box() {
    add_meta_box('custom_tab_product_categories', __('Assign to Product Categories', 'savvy-ops'), 'savvy_render_custom_tab_meta_box', 'custom_product_tab', 'side', 'default');
}
add_action('add_meta_boxes', 'savvy_add_custom_tab_meta_box');

function savvy_render_custom_tab_meta_box($post) {
    $selected_categories = get_post_meta($post->ID, '_custom_tab_product_categories', true);
    $selected_categories = is_array($selected_categories) ? $selected_categories : array();
    $product_categories = get_terms(array('taxonomy' => 'product_cat', 'hide_empty' => false));

    echo '<p>' . __('Select product categories for this tab:', 'savvy-ops') . '</p><ul style="max-height:200px; overflow-y:auto; border:1px solid #ddd; padding:10px;">';
    foreach ($product_categories as $category) {
        $checked = in_array($category->term_id, $selected_categories) ? 'checked' : '';
        echo '<li><label><input type="checkbox" name="custom_tab_product_categories[]" value="' . esc_attr($category->term_id) . '" ' . $checked . '> ' . esc_html($category->name) . '</label></li>';
    }
    echo '</ul>';
}

function savvy_save_custom_tab_meta($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (isset($_POST['custom_tab_product_categories'])) {
        update_post_meta($post_id, '_custom_tab_product_categories', array_map('sanitize_text_field', $_POST['custom_tab_product_categories']));
    } else {
        delete_post_meta($post_id, '_custom_tab_product_categories');
    }
}
add_action('save_post', 'savvy_save_custom_tab_meta');

/**
 * 3. UNIQUE TABS: Register the "Unlimited" Tab Panel in Product Edit
 */
function savvy_add_unlimited_custom_product_tabs($tabs) {
    $tabs['dynamic_unique_tabs'] = array(
        'label'    => __('Unique Product Tabs', 'savvy-ops'),
        'target'   => 'dynamic_unique_tabs_panel',
        'class'    => array('show_if_simple', 'show_if_variable'),
        'priority' => 60,
    );
    return $tabs;
}
add_filter('woocommerce_product_data_tabs', 'savvy_add_unlimited_custom_product_tabs');

function savvy_render_unlimited_tabs_backend() {
    global $post;
    $stored_tabs = get_post_meta($post->ID, '_unique_product_tabs_data', true);
    if (!is_array($stored_tabs)) $stored_tabs = array();
    ?>
    <div id="dynamic_unique_tabs_panel" class="panel woocommerce_options_panel">
        <div id="unique_tabs_container" style="padding: 0 10px;">
            <?php foreach ($stored_tabs as $index => $tab) : ?>
                <div class="unique-tab-row" style="border: 1px solid #ddd; padding: 15px; margin-bottom: 15px; background: #fff; border-radius: 4px;">
                    <p class="form-field">
                        <label>Tab Title:</label>
                        <input type="text" name="unique_tab_titles[]" value="<?php echo esc_attr($tab['title']); ?>" style="width: 50%;">
                        <button type="button" class="remove-unique-tab button" style="color: #a00; border-color: #a00;">Remove Tab</button>
                    </p>
                    <p class="form-field">
                        <label>Content (HTML/Shortcodes):</label>
                        <textarea name="unique_tab_contents[]" rows="6" style="width: 100%; font-family: monospace;"><?php echo esc_textarea($tab['content']); ?></textarea>
                    </p>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="toolbar" style="padding: 15px; background: #f8f8f8; border-top: 1px solid #ddd;">
            <button type="button" id="add_new_unique_tab" class="button button-primary">+ Add New Unique Tab</button>
        </div>
        <script>
            jQuery(document).ready(function($) {
                $('#add_new_unique_tab').on('click', function() {
                    var html = '<div class="unique-tab-row" style="border: 1px solid #ddd; padding: 15px; margin-bottom: 15px; background: #fff; border-radius: 4px;">' +
                               '<p class="form-field"><label>Tab Title:</label> <input type="text" name="unique_tab_titles[]" style="width: 50%;"> ' +
                               '<button type="button" class="remove-unique-tab button" style="color: #a00; border-color: #a00;">Remove Tab</button></p>' +
                               '<p class="form-field"><label>Content:</label> <textarea name="unique_tab_contents[]" rows="6" style="width: 100%; font-family: monospace;"></textarea></p></div>';
                    $('#unique_tabs_container').append(html);
                });
                $(document).on('click', '.remove-unique-tab', function() { $(this).closest('.unique-tab-row').remove(); });
            });
        </script>
    </div>
    <?php
}
add_action('woocommerce_product_data_panels', 'savvy_render_unlimited_tabs_backend');

/**
 * 4. Save and Display Everything (Global + Unlimited Unique)
 */
function savvy_save_all_product_tabs_data($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    $titles = isset($_POST['unique_tab_titles']) ? $_POST['unique_tab_titles'] : array();
    $contents = isset($_POST['unique_tab_contents']) ? $_POST['unique_tab_contents'] : array();
    $data = array();
    for ($i = 0; $i < count($titles); $i++) {
        if (!empty($titles[$i])) {
            $data[] = array('title' => sanitize_text_field($titles[$i]), 'content' => wp_kses_post($contents[$i]));
        }
    }
    update_post_meta($post_id, '_unique_product_tabs_data', $data);
}
add_action('woocommerce_process_product_meta', 'savvy_save_all_product_tabs_data');

function savvy_display_combined_tabs($tabs) {
    global $post;
    if (!$post) return $tabs;

    // A. Add Global Tabs
    $product_categories = wp_get_post_terms($post->ID, 'product_cat', array('fields' => 'ids'));
    $global_posts = get_posts(array('post_type' => 'custom_product_tab', 'posts_per_page' => -1, 'post_status' => 'publish'));
    foreach ($global_posts as $g_tab) {
        $assigned = get_post_meta($g_tab->ID, '_custom_tab_product_categories', true);
        if (is_array($assigned) && array_intersect($assigned, $product_categories)) {
            // Priority 70 to put after description
            $tabs['global_tab_' . $g_tab->ID] = array(
                'title' => esc_html(get_the_title($g_tab->ID)),
                'priority' => 70,
                'callback' => 'savvy_render_tab_content_with_filter',
                'content' => get_post_field('post_content', $g_tab->ID),
            );
        }
    }

    // B. Add Unlimited Unique Tabs
    $unique_data = get_post_meta($post->ID, '_unique_product_tabs_data', true);
    if (is_array($unique_data)) {
        foreach ($unique_data as $index => $u_tab) {
            $tabs['unique_tab_' . $index] = array(
                'title' => esc_html($u_tab['title']),
                'priority' => 45 + $index, 
                'callback' => 'savvy_render_tab_content_with_filter',
                'content' => $u_tab['content'],
            );
        }
    }
    return $tabs;
}
add_filter('woocommerce_product_tabs', 'savvy_display_combined_tabs');

function savvy_render_tab_content_with_filter($key, $tab) {
    echo '<div class="custom-tab-wrapper">' . apply_filters('the_content', $tab['content']) . '</div>';
}

/**
 * 5. Clean up Default Tabs (Optional, based on requirement)
 */
// Uncomment if user wants to remove default tabs
// add_filter('woocommerce_product_tabs', 'savvy_remove_default_tabs', 98);
function savvy_remove_default_tabs($tabs) {
    unset($tabs['additional_information'], $tabs['reviews']);
    return $tabs;
}
