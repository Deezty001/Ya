<div class="savvy-wrapper">
    <div class="savvy-header">
        <h1>Production Hub (SQL V2)</h1>
        <div class="savvy-actions">
            <!-- SQL Modal Trigger -->
            <button id="btn-create-order" class="button button-primary">Create Order (SQL)</button>
            <a href="<?php echo admin_url('admin.php?page=savvy-settings'); ?>" class="button">Settings</a>
        </div>
    </div>

    <!-- ORDERS LIST -->
    <script>
    if (typeof savvy_vars === 'undefined') {
        var savvy_vars = {
            ajax_url: <?php echo json_encode( admin_url( 'admin-ajax.php' ) ); ?>,
            nonce: <?php echo json_encode( wp_create_nonce( 'savvy_inventory_nonce' ) ); ?>
        };
    }
    </script>
    <div class="savvy-section" style="background: transparent; box-shadow: none;">
        
        <!-- VIEW CONTROLS & FILTERS -->
        <div class="savvy-controls-bar">
            <!-- Left: Filter Inputs -->
            <div class="savvy-filters">
                <div class="savvy-input-group">
                    <span class="dashicons dashicons-search"></span>
                    <input type="text" id="savvy-filter-search" placeholder="Search orders, clients...">
                </div>
                
                <div class="savvy-filter-radios">
                    <label class="savvy-radio-pill">
                        <input type="checkbox" id="savvy-filter-urgent"> 
                        <span>Urgent Only</span>
                    </label>
                </div>

                <select id="savvy-filter-stage" class="savvy-select-pill">
                    <option value="all">All Stages</option>
                    <option value="Allocation">Awaiting Allocation</option>
                    <option value="Picking">Picking</option>
                    <option value="Assembly">Assembly</option>
                    <option value="Testing">Testing</option>
                </select>
            </div>

            <!-- Right: View Toggle -->
            <div class="savvy-view-toggle">
                <button type="button" class="view-btn active" data-view="board">
                    <span class="dashicons dashicons-grid-view"></span> Board
                </button>
                <button type="button" class="view-btn" data-view="list">
                    <span class="dashicons dashicons-list-view"></span> List
                </button>
            </div>
        </div>

        <?php
        global $wpdb;
        $table = $wpdb->prefix . 'savvy_orders';
        
        // PHP LOGIC: Fetch Active Orders (Limit 200 to ensure board isn't empty)
        $per_page = 200; 
        $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $offset = ($paged - 1) * $per_page;
        $total_items = $wpdb->get_var("SELECT COUNT(*) FROM $table");
        $total_pages = ceil($total_items / $per_page);
        
        // Fetch orders, prioritizing active ones logic if we were strict, but date_desc is standard.
        // We filter Out 'Completed' in SQL to keep the board focused?
        // Let's just grab everything for now but bump limit.
        $orders = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table ORDER BY date_created DESC LIMIT %d OFFSET %d", $per_page, $offset));
        
        // Helper to get initials
        if(!function_exists('savvy_get_initials')) {
            function savvy_get_initials($name) {
                $parts = explode(' ', $name);
                $i = '';
                foreach($parts as $p) $i .= strtoupper(substr($p, 0, 1));
                return substr($i, 0, 2);
            }
        }

        // Helper: Render Kanban Card
        if(!function_exists('render_savvy_kanban_card')) {
            function render_savvy_kanban_card($p) {
                $wc_order = $p->wc_order_id ?: '';
                $wc_idx = $p->wc_build_index ?: '';
                $display_id = $wc_order ? ($wc_idx ? "$wc_order.$wc_idx" : $wc_order) : $p->id;
                $is_urgent = ($p->priority === 'High' || $p->priority === 'Urgent');
                $initials = savvy_get_initials($p->client_name);
                $progress = 0; 
                
                // Status Text Map
                $status_label = ($p->status == 'Pending' ? 'Not Started' : ($p->status == 'Testing' ? 'Burn-In' : $p->status));

                ob_start();
                ?>
                <div class="kanban-card order-row filter-target" data-id="<?php echo $p->id; ?>" data-urgent="<?php echo $is_urgent?'1':'0'; ?>" data-search="<?php echo esc_attr(strtolower($p->title . ' ' . $p->client_name . ' ' . $display_id)); ?>">
                    <div class="card-header">
                        <span class="card-id">#<?php echo $display_id; ?></span>
                        <?php if($is_urgent): ?><span class="badge-urgent-mini">URGENT</span><?php endif; ?>
                        <div class="card-avatar"><?php echo $initials; ?></div>
                    </div>
                    <div class="card-body">
                        <div class="card-title"><?php echo esc_html($p->client_name); ?></div>
                        <div class="card-sub"><?php echo esc_html($p->title); ?></div>
                        <div class="card-meta">
                            <div class="meta-row"><span class="label">Parts Allocated</span> <span class="val"><?php echo $progress; ?>%</span></div>
                            <div class="progress-track"><div class="progress-fill" style="width:<?php echo $progress; ?>%"></div></div>
                        </div>
                        <div class="card-footer">
                            <span class="status-text"><?php echo $status_label; ?></span>
                            <span class="time-text"><?php echo human_time_diff(strtotime($p->date_created), current_time('timestamp')); ?> ago</span>
                        </div>
                    </div>
                </div>
                <?php
                return ob_get_clean();
            }
        }
        ?>

        <!-- VIEW 1: KANBAN BOARD -->
        <div id="savvy-board-view" class="savvy-view-container active">
            <div class="savvy-kanban-grid">
                
                <!-- COL 1: ALLOCATION -->
                <div class="kanban-col" data-stage="Allocation">
                    <div class="col-header">
                        <span class="col-title">Awaiting Allocation</span>
                        <span class="col-count">0</span>
                    </div>
                    <div class="col-body">
                        <?php if($orders): foreach($orders as $p): 
                            if($p->status !== 'Pending' && $p->status !== 'Allocation') continue; 
                            echo render_savvy_kanban_card($p);
                        endforeach; endif; ?>
                    </div>
                </div>

                <!-- COL 2: PICKING -->
                <div class="kanban-col" data-stage="Picking">
                    <div class="col-header">
                        <span class="col-indicator" style="background:#3b82f6;"></span>
                        <span class="col-title">Picking</span>
                        <span class="col-count">0</span>
                    </div>
                    <div class="col-body">
                        <?php if($orders): foreach($orders as $p): 
                            if($p->status !== 'Picking') continue; 
                            echo render_savvy_kanban_card($p);
                        endforeach; endif; ?>
                    </div>
                </div>

                <!-- COL 3: ASSEMBLY -->
                <div class="kanban-col" data-stage="Assembly">
                    <div class="col-header">
                        <span class="col-indicator" style="background:#a855f7;"></span>
                        <span class="col-title">Assembly</span>
                        <span class="col-count">0</span>
                    </div>
                    <div class="col-body">
                         <?php if($orders): foreach($orders as $p): 
                            if($p->status !== 'Assembly') continue; 
                            echo render_savvy_kanban_card($p);
                        endforeach; endif; ?>
                    </div>
                </div>

                <!-- COL 4: TESTING -->
                <div class="kanban-col" data-stage="Testing">
                    <div class="col-header">
                        <span class="col-indicator" style="background:#10b981;"></span>
                        <span class="col-title">Testing / Burn-In</span>
                        <span class="col-count">0</span>
                    </div>
                    <div class="col-body">
                        <?php if($orders): foreach($orders as $p): 
                            if($p->status !== 'Testing') continue; 
                            echo render_savvy_kanban_card($p);
                        endforeach; endif; ?>
                    </div>
                </div>

            </div>
        </div>

        <!-- VIEW 2: LIST TABLE -->
        <div id="savvy-list-view" class="savvy-view-container" style="display:none;">
            <div class="savvy-table-card">
                <table class="savvy-clean-table">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Client</th>
                            <th>Stage</th>
                            <th>Allocation</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($orders): foreach($orders as $p): 
                            $wc_order = $p->wc_order_id ?: '';
                            $wc_idx = $p->wc_build_index ?: '';
                            $display_id = $wc_order ? ($wc_idx ? "$wc_order.$wc_idx" : $wc_order) : $p->id;
                            $is_urgent = ($p->priority === 'High' || $p->priority === 'Urgent');
                        ?>
                        <tr class="order-row filter-target" data-id="<?php echo $p->id; ?>" data-urgent="<?php echo $is_urgent ? '1' : '0'; ?>" data-search="<?php echo esc_attr(strtolower($p->title . ' ' . $p->client_name . ' ' . $display_id)); ?>">
                            <td>
                                <span class="tbl-id">#<?php echo $display_id; ?></span>
                                <?php if($is_urgent): ?><span class="badge-urgent">URGENT</span><?php endif; ?>
                            </td>
                            <td>
                                <div class="tbl-client"><?php echo esc_html($p->client_name); ?></div>
                            </td>
                            <td><span class="badge-status status-<?php echo strtolower($p->status); ?>"><?php echo $p->status; ?></span></td>
                            <td><div class="progress-bar-mini"><div class="fill" style="width:0%"></div></div> <span class="prog-text">0%</span></td>
                            <td><?php echo date('M d', strtotime($p->date_created)); ?> <span class="time-ago"><?php echo human_time_diff(strtotime($p->date_created), current_time('timestamp')); ?> ago</span></td>
                            <td>-</td>
                        </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if($total_pages > 1): ?>
                <div class="savvy-pagination">
                    <!-- Pagination Links (Keep existing logic if needed) -->
                </div>
            <?php endif; ?>
        </div>

    </div>

    <!-- INLINE PHP TEMPLATE FOR CARD (Used in Loop above) -->
    <?php
    /* 
       This is a hack to reuse code inside the loop. 
       In a real app, this would be a function or separate file. 
       Wrapping in a strictly false condition so it doesn't execute on load, 
       but we will copy the logic into the loops above.
    */
    ?>
    
    <!-- ACTUAL CARD RENDER LOGIC (To be copy-pasted or included) -->
    <!-- Ideally, I'd write a function, but I'll inline the logic in the loops for simplicity in this single file edit. -->
    
    <?php
    // REDEFINING THE CARD TEMPLATE FOR THE EXECUTION STEP:
    /*
    $wc_order = $p->wc_order_id ?: '';
    $wc_idx = $p->wc_build_index ?: '';
    $display_id = $wc_order ? ($wc_idx ? "$wc_order.$wc_idx" : $wc_order) : $p->id;
    $is_urgent = ($p->priority === 'High' || $p->priority === 'Urgent');
    $initials = savvy_get_initials($p->client_name);
    
    // Components (Mock for UI, real data needs join)
    $progress = 0; 
    
    echo '<div class="kanban-card order-row filter-target" data-id="'.$p->id.'" data-urgent="'.($is_urgent?'1':'0').'" data-search="'.esc_attr(strtolower($p->title . ' ' . $p->client_name . ' ' . $display_id)).'">';
        echo '<div class="card-header">';
            echo '<span class="card-id">#'.$display_id.'</span>';
            if($is_urgent) echo '<span class="badge-urgent-mini">URGENT</span>';
            echo '<div class="card-avatar">'.$initials.'</div>';
        echo '</div>';
        
        echo '<div class="card-body">';
            echo '<div class="card-title">'.esc_html($p->client_name).'</div>';
            echo '<div class="card-sub">'.esc_html($p->title).'</div>';
            
            echo '<div class="card-meta">';
                echo '<div class="meta-row"><span class="label">Parts Allocated</span> <span class="val">'.$progress.'%</span></div>';
                echo '<div class="progress-track"><div class="progress-fill" style="width:'.$progress.'%"></div></div>';
            echo '</div>';
            
            echo '<div class="card-footer">';
                echo '<span class="status-text">'.($p->status == 'Pending' ? 'Not Started' : $p->status).'</span>';
                echo '<span class="time-text">'.human_time_diff(strtotime($p->date_created), current_time('timestamp')).' ago</span>';
            echo '</div>';
        echo '</div>';
    echo '</div>';
    */
    ?>

</div>

<!-- DARK MODE ORDER MODAL -->
<!-- Wrapper is the Overlay to match Inventory UI -->
<div id="modal-order-details" class="savvy-modal-overlay" style="display:none;">
    <div class="savvy-modal">
        
        <!-- HEADER -->
        <div class="modal-header">
            <div>
                <h2 id="modal-order-title">Order #...</h2>
                <div id="modal-order-subtitle">
                    <span class="status-dot" style="width:8px; height:8px; background:var(--modal-accent-warning); border-radius:50%; margin-right:6px;"></span>
                    Client Name
                </div>
            </div>
            <div style="display:flex; gap:10px;">
                <button class="btn btn-secondary btn-small">View Order</button>
                <!-- Close Button -->
                <button class="btn btn-secondary btn-small modal-close" style="width:32px; padding:0; justify-content:center;"><span class="dashicons dashicons-no-alt"></span></button>
            </div>
        </div>
        
        <!-- MODAL LAYOUT -->
        <div class="modal-layout">
            
            <!-- SIDEBAR -->
            <div class="modal-sidebar-nav">
                <!-- JS Injects Tabs Here -->
                <div id="modal-build-tabs">
                    <!-- Example: <div class="build-tab active">Picking</div> -->
                </div>

                <!-- Builder Profile Removed as per request -->
            </div>

            <!-- CONTENT AREA -->
            <div class="modal-content-area">
                
                <!-- This container holds what JS injects for components -->
                 <div id="tab-picking" class="tab-content active">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:30px;">
                        <span class="modal-section-title" style="margin:0; border:none; width:auto;">Allocation Scan</span>
                        <div style="display:flex; gap:10px;">
                            <input type="text" class="input-glass" placeholder="Scan Serial...">
                            <button class="btn btn-primary btn-small">Scan</button>
                        </div>
                    </div>

                    <!-- Duplicate Table Header Removed - JS handles it -->

                    <!-- The JS populates this list -->
                    <div id="modal-component-list">
                        <div class="loading-spinner">Loading...</div>
                    </div>
                </div>

                <!-- Placeholders for other tabs if we implement them later -->
                <div id="modal-client-info" style="display:none;"></div> 

            </div>
        </div>

        <!-- FOOTER -->
        <div class="modal-footer" style="justify-content: flex-end;">
            <button class="btn btn-primary" id="btn-complete-stage" style="padding:0 30px;">Complete Stage</button>
        </div>

    </div>
</div>

<!-- CREATE ORDER MODAL -->
<div id="modal-create-order" class="savvy-modal-overlay" style="display:none;">
    <div class="savvy-modal" style="background:#fff; color:#333; width:500px; padding:0; border-radius:8px;">
        <div class="modal-header" style="padding:15px 20px; border-bottom:1px solid #eee; display:flex; justify-content:space-between; align-items:center;">
            <h2 style="margin:0; font-size:18px;">New Production Order</h2>
            <span class="dashicons dashicons-no-alt modal-close-create" style="cursor:pointer; font-size:20px;"></span>
        </div>
        <div class="modal-body" style="padding:20px;">
            <form id="form-create-order">
                <div style="margin-bottom:15px;">
                    <label style="display:block; font-weight:bold; margin-bottom:5px;">Client Name</label>
                    <input type="text" name="client_name" style="width:100%;" required placeholder="e.g. John Doe">
                </div>
                <div style="margin-bottom:15px;">
                    <label style="display:block; font-weight:bold; margin-bottom:5px;">Order Title</label>
                    <input type="text" name="order_title" style="width:100%;" required placeholder="e.g. Custom Gaming PC">
                </div>
                <div style="margin-bottom:20px;">
                    <label style="display:block; font-weight:bold; margin-bottom:5px;">Priority</label>
                    <select name="priority" style="width:100%;">
                        <option value="Normal">Normal</option>
                        <option value="High">High</option>
                        <option value="Urgent">Urgent</option>
                    </select>
                </div>
                <div style="text-align:right;">
                    <button type="button" class="button modal-close-create" style="margin-right:10px;">Cancel</button>
                    <button type="submit" class="button button-primary">Create Order</button>
                </div>
            </form>
        </div>
    </div>
</div>
    </div>
</div>
