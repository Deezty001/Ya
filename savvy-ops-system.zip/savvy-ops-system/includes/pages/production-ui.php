<div class="savvy-wrapper">
    <div class="savvy-header">
        <h1>Production Hub (SQL V2)</h1>
        <div class="savvy-actions">
            <!-- SQL Modal Trigger -->
            <button id="btn-create-order" class="button button-primary">Create Order (SQL)</button>
            <a href="<?php echo admin_url('admin.php?page=savvy-settings'); ?>" class="button">Settings</a>
        </div>
    </div>

    <!-- ORDERS LIST -->
    <script>
    if (typeof savvy_vars === 'undefined') {
        var savvy_vars = {
            ajax_url: <?php echo json_encode( admin_url( 'admin-ajax.php' ) ); ?>,
            nonce: <?php echo json_encode( wp_create_nonce( 'savvy_inventory_nonce' ) ); ?>
        };
    }
    </script>
    <div class="savvy-section">
        <table class="widefat striped" id="orders-table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Client / Title</th>
                    <th>Status</th>
                    <th>Allocation</th>
                    <th>Date (Sorted By)</th>
                </tr>
            </thead>
            <tbody>
                <?php
                global $wpdb;
                $table = $wpdb->prefix . 'savvy_orders';
                
                // Pagination Logic
                $per_page = 20;
                $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
                $offset = ($paged - 1) * $per_page;
                
                // Get Total
                $total_items = $wpdb->get_var("SELECT COUNT(*) FROM $table");
                $total_pages = ceil($total_items / $per_page);
                
                // Get Page Items
                $orders = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table ORDER BY date_created DESC LIMIT %d OFFSET %d", $per_page, $offset));
                
                if($orders): foreach($orders as $p): 
                    $wc_order = $p->wc_order_id ?: '';
                    $wc_idx = $p->wc_build_index ?: '';
                    
                    // Display ID: OrderNum.BuildNum
                    $display_id = $wc_order ? ($wc_idx ? "$wc_order.$wc_idx" : $wc_order) : $p->id;
                    
                    // Priority Badge
                    $priority_html = '';
                    if($p->priority === 'High') {
                        $priority_html = '<span class="badge" style="background:#fff1f0; color:#cf1322; border:1px solid #ffa39e; margin-left:5px;">URGENT</span>';
                    }

                    // Allocation Status (Placeholder for now, could join via SQL later)
                    $alloc_status = '<span style="color:#999;">Pending</span>'; 
                ?>
                    <tr class="order-row" data-id="<?php echo $p->id; ?>" style="cursor:pointer;">
                        <td><strong>#<?php echo $display_id; ?></strong></td>
                        <td>
                            <strong><?php echo esc_html($p->title); ?></strong>
                            <?php echo $priority_html; ?>
                        </td>
                        <td><?php echo $p->status; ?></td>
                        <td><?php echo $alloc_status; ?></td>
                        <td>
                            <?php echo date('Y-m-d H:i', strtotime($p->date_created)); ?>
                            <br><small style="color:#ccc;"><?php echo $p->date_created; ?></small>
                        </td>
                    </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="5">No active orders found. (Total: <?php echo $total_items; ?>)</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        
        <?php if($total_pages > 1): ?>
        <div class="savvy-pagination" style="margin-top:15px; display:flex; justify-content:center; gap:10px;">
            <?php if($paged > 1): ?>
                <a href="<?php echo add_query_arg('paged', $paged - 1); ?>" class="button">&laquo; Previous</a>
            <?php endif; ?>
            
            <span style="line-height:2.1; color:#888;">Page <?php echo $paged; ?> of <?php echo $total_pages; ?></span>
            
            <?php if($paged < $total_pages): ?>
                <a href="<?php echo add_query_arg('paged', $paged + 1); ?>" class="button">Next &raquo;</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

</div>

<!-- DARK MODE ORDER MODAL -->
<!-- Wrapper is the Overlay to match Inventory UI -->
<div id="modal-order-details" class="savvy-modal-overlay" style="display:none;">
    <div class="savvy-modal dark-mode" style="background:#1a1a1a; color:#fff; width:90%; max-width:1000px; border:1px solid #333; display:flex; flex-direction:column;">
        
        <div class="modal-header" style="border-bottom:1px solid #333; padding:20px; display:flex; justify-content:space-between; align-items:center;">
            <div>
                <h2 id="modal-order-title" style="color:#fff; margin:0; font-size:24px;">Order #...</h2>
                <div id="modal-order-subtitle" style="color:#00b9eb; font-size:14px; margin-top:5px;">Client Name</div>
            </div>
            <!-- Close Button -->
            <span class="dashicons dashicons-no-alt modal-close" style="color:#fff; font-size:24px; cursor:pointer;"></span>
        </div>
        
        <div class="modal-body" style="padding:20px; display:flex; gap:30px; overflow-y:auto;">
            
            <!-- LEFT: COMPONENT MANIFEST -->
            <div style="flex:2;">
                <!-- Build Tabs Container -->
                <div id="modal-build-tabs" style="display:flex; gap:10px; margin-bottom:15px; border-bottom:1px solid #333; padding-bottom:10px;">
                    <!-- Tabs injected via JS -->
                </div>

                <h3 style="color:#888; text-transform:uppercase; font-size:12px; margin-bottom:15px; padding-bottom:5px;">
                    <span class="dashicons dashicons-table-col-before"></span> Component Manifest
                </h3>
                
                <div id="modal-component-list" style="display:flex; flex-direction:column; gap:10px;">
                    <!-- Items injected by JS -->
                    <div class="loading-spinner">Loading...</div>
                </div>
            </div>

            <!-- RIGHT: INFO & ACTIONS -->
            <div style="flex:1; background:#222; padding:20px; border-radius:8px; border:1px solid #333; height:fit-content;">
                <h3 style="color:#888; text-transform:uppercase; font-size:12px; margin-bottom:15px;">Customer Profile</h3>
                <div id="modal-client-info" style="margin-bottom:30px;">
                    <!-- Client info here -->
                </div>

                <h3 style="color:#888; text-transform:uppercase; font-size:12px; margin-bottom:15px;">Progression</h3>
                <div class="progression-steps">
                    <button class="button button-disabled" id="btn-start-build" style="width:100%; margin-bottom:10px;">Ready to Build</button>
                </div>
            </div>

                </div>
    </div>
</div>

<!-- CREATE ORDER MODAL -->
<div id="modal-create-order" class="savvy-modal-overlay" style="display:none;">
    <div class="savvy-modal" style="background:#fff; color:#333; width:500px; padding:0; border-radius:8px;">
        <div class="modal-header" style="padding:15px 20px; border-bottom:1px solid #eee; display:flex; justify-content:space-between; align-items:center;">
            <h2 style="margin:0; font-size:18px;">New Production Order</h2>
            <span class="dashicons dashicons-no-alt modal-close-create" style="cursor:pointer; font-size:20px;"></span>
        </div>
        <div class="modal-body" style="padding:20px;">
            <form id="form-create-order">
                <div style="margin-bottom:15px;">
                    <label style="display:block; font-weight:bold; margin-bottom:5px;">Client Name</label>
                    <input type="text" name="client_name" style="width:100%;" required placeholder="e.g. John Doe">
                </div>
                <div style="margin-bottom:15px;">
                    <label style="display:block; font-weight:bold; margin-bottom:5px;">Order Title</label>
                    <input type="text" name="order_title" style="width:100%;" required placeholder="e.g. Custom Gaming PC">
                </div>
                <div style="margin-bottom:20px;">
                    <label style="display:block; font-weight:bold; margin-bottom:5px;">Priority</label>
                    <select name="priority" style="width:100%;">
                        <option value="Normal">Normal</option>
                        <option value="High">High</option>
                        <option value="Urgent">Urgent</option>
                    </select>
                </div>
                <div style="text-align:right;">
                    <button type="button" class="button modal-close-create" style="margin-right:10px;">Cancel</button>
                    <button type="submit" class="button button-primary">Create Order</button>
                </div>
            </form>
        </div>
    </div>
</div>
    </div>
</div>
