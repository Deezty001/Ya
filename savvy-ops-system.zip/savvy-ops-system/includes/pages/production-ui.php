<div class="savvy-wrapper">
    <div class="savvy-header">
        <h1>Production Hub</h1>
        <div class="savvy-actions">
            <a href="<?php echo admin_url('post-new.php?post_type=savvy_project'); ?>" class="button button-primary">Create Order</a>
        </div>
    </div>

    <!-- ORDERS LIST -->
    <script>
    if (typeof savvy_vars === 'undefined') {
        var savvy_vars = {
            ajax_url: <?php echo json_encode( admin_url( 'admin-ajax.php' ) ); ?>,
            nonce: <?php echo json_encode( wp_create_nonce( 'savvy_inventory_nonce' ) ); ?>
        };
    }
    </script>
    <div class="savvy-section">
        <table class="widefat striped" id="orders-table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Client / Title</th>
                    <th>Status</th>
                    <th>Allocation</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                global $wpdb;
                $table = $wpdb->prefix . 'savvy_orders';
                $orders = $wpdb->get_results("SELECT * FROM $table ORDER BY date_created DESC");
                
                // DEBUG
                if(empty($orders)) {
                    echo '<tr><td colspan="5" style="color:red; pading:10px;">Debug: No orders found. Last Error: ' . $wpdb->last_error . ' | Table: ' . $table . '</td></tr>';
                }

                if($orders): foreach($orders as $p): 
                    $wc_order = $p->wc_order_id ?: '';
                    $wc_idx = $p->wc_build_index ?: '';
                    
                    // Display ID: OrderNum.BuildNum
                    $display_id = $wc_order ? ($wc_idx ? "$wc_order.$wc_idx" : $wc_order) : $p->id;
                    
                    // Priority Badge
                    $priority_html = '';
                    if($p->priority === 'High') {
                        $priority_html = '<span class="badge" style="background:#fff1f0; color:#cf1322; border:1px solid #ffa39e; margin-left:5px;">URGENT</span>';
                    }

                    // Allocation Status (Placeholder for now, could join via SQL later)
                    $alloc_status = '<span style="color:#999;">Pending</span>'; 
                ?>
                    <tr class="order-row" data-id="<?php echo $p->id; ?>" style="cursor:pointer;">
                        <td><strong>#<?php echo $display_id; ?></strong></td>
                        <td>
                            <strong><?php echo esc_html($p->title); ?></strong>
                            <?php echo $priority_html; ?>
                        </td>
                        <td><?php echo $p->status; ?></td>
                        <td><?php echo $alloc_status; ?></td>
                        <td><?php echo date('Y-m-d', strtotime($p->date_created)); ?></td>
                    </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="5">No active orders (SQL).</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<!-- DARK MODE ORDER MODAL -->
<!-- Wrapper is the Overlay to match Inventory UI -->
<div id="modal-order-details" class="savvy-modal-overlay" style="display:none;">
    <div class="savvy-modal dark-mode" style="background:#1a1a1a; color:#fff; width:90%; max-width:1000px; border:1px solid #333; display:flex; flex-direction:column;">
        
        <div class="modal-header" style="border-bottom:1px solid #333; padding:20px; display:flex; justify-content:space-between; align-items:center;">
            <div>
                <h2 id="modal-order-title" style="color:#fff; margin:0; font-size:24px;">Order #...</h2>
                <div id="modal-order-subtitle" style="color:#00b9eb; font-size:14px; margin-top:5px;">Client Name</div>
            </div>
            <!-- Close Button -->
            <span class="dashicons dashicons-no-alt modal-close" style="color:#fff; font-size:24px; cursor:pointer;"></span>
        </div>
        
        <div class="modal-body" style="padding:20px; display:flex; gap:30px; overflow-y:auto;">
            
            <!-- LEFT: COMPONENT MANIFEST -->
            <div style="flex:2;">
                <!-- Build Tabs Container -->
                <div id="modal-build-tabs" style="display:flex; gap:10px; margin-bottom:15px; border-bottom:1px solid #333; padding-bottom:10px;">
                    <!-- Tabs injected via JS -->
                </div>

                <h3 style="color:#888; text-transform:uppercase; font-size:12px; margin-bottom:15px; padding-bottom:5px;">
                    <span class="dashicons dashicons-table-col-before"></span> Component Manifest
                </h3>
                
                <div id="modal-component-list" style="display:flex; flex-direction:column; gap:10px;">
                    <!-- Items injected by JS -->
                    <div class="loading-spinner">Loading...</div>
                </div>
            </div>

            <!-- RIGHT: INFO & ACTIONS -->
            <div style="flex:1; background:#222; padding:20px; border-radius:8px; border:1px solid #333; height:fit-content;">
                <h3 style="color:#888; text-transform:uppercase; font-size:12px; margin-bottom:15px;">Customer Profile</h3>
                <div id="modal-client-info" style="margin-bottom:30px;">
                    <!-- Client info here -->
                </div>

                <h3 style="color:#888; text-transform:uppercase; font-size:12px; margin-bottom:15px;">Progression</h3>
                <div class="progression-steps">
                    <button class="button button-disabled" id="btn-start-build" style="width:100%; margin-bottom:10px;">Ready to Build</button>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Scripts & Styles -->
<style>
    /* Dark Mode Premium Styles */
    :root {
        --savvy-dark: #1a1a1a;
        --savvy-panel: #252525;
        --savvy-border: #333;
        --savvy-text: #e0e0e0;
        --savvy-check: #00b9eb;
        --savvy-hover: #2a2a2a;
    }

    /* Modal Overlay (Wrapper) - Matches Inventory UI Structure */
    .savvy-modal-overlay {
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0,0,0,0.85); /* Slightly darker to replace blur */
        z-index: 9999;
        display: none; 
        /* Flexbox for centering the child .savvy-modal */
        display: flex; justify-content: center; align-items: center; 
    }
    
    /* The Modal Box itself */
    .savvy-modal {
        background: var(--savvy-dark); color: var(--savvy-text);
        box-shadow: 0 10px 30px rgba(0,0,0,0.5); /* Lighter shadow for perf */
        border-radius: 12px;
        max-height: 90vh;
        position: relative;
        overflow: hidden; /* For rounded corners */
    }

    /* Premium Table Styling */
    #orders-table {
        border-collapse: separate; border-spacing: 0 8px; background: transparent; box-shadow: none; border: none;
    }
    #orders-table thead th {
        background: transparent; border: none; color: #888; text-transform: uppercase; font-size: 11px; letter-spacing: 1px; padding-bottom: 0;
    }
    #orders-table tbody tr {
        background: #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.03); transition: transform 0.2s, box-shadow 0.2s;
    }
    #orders-table tbody tr:hover {
        transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0,0,0,0.08); background: #fcfcfc; z-index: 10;
    }
    #orders-table td {
        padding: 15px 12px; border-top: 1px solid #eee; border-bottom: 1px solid #eee; vertical-align: middle;
    }
    #orders-table td:first-child { border-left: 1px solid #eee; border-radius: 6px 0 0 6px; }
    #orders-table td:last-child { border-right: 1px solid #eee; border-radius: 0 6px 6px 0; }
    
    /* Component Row */
    .component-row { 
        background: var(--savvy-panel); padding: 15px; border-radius: 6px; border: 1px solid var(--savvy-border); 
        display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;
        transition: 0.2s;
    }
    .component-row:hover { border-color: #555; background: var(--savvy-hover); }
    .comp-label { color: #888; font-size: 11px; font-weight: bold; width: 60px; text-transform: uppercase; }
    .comp-name { color: #fff; font-weight: 500; flex: 1; font-size: 14px; }
    .comp-status { margin-left: 15px; display: flex; align-items: center; gap: 10px; position: relative; }
    
    .badge-unalloc { background: #333; color: #aaa; font-size: 10px; padding: 4px 8px; border-radius: 4px; text-transform: uppercase; letter-spacing: 0.5px; }
    .badge-alloc { background: #135200; color: #b7eb8f; border: 1px solid #237804; font-size: 10px; padding: 4px 8px; border-radius: 4px; text-transform: uppercase; letter-spacing: 0.5px; }
    
    .action-icon { color: var(--savvy-check); cursor: pointer; font-size: 16px; opacity: 0.7; transition: 0.2s; }
    .action-icon:hover { opacity: 1; transform: scale(1.1); }

    /* Allocation Dropdown */
    .alloc-dropdown {
        position: absolute; right: 0; top: 100%; margin-top: 5px;
        background: #333; border: 1px solid #555; padding: 5px; z-index: 100;
        width: 300px; box-shadow: 0 10px 20px rgba(0,0,0,0.5); border-radius: 6px;
        display: none;
    }
    .alloc-dropdown input {
        width: 100%; background: #222; border: 1px solid #444; color: #fff; padding: 8px; border-radius: 4px; margin-bottom: 5px;
    }
    .alloc-list { max-height: 150px; overflow-y: auto; }
    .alloc-item { 
        padding: 8px; border-bottom: 1px solid #444; cursor: pointer; font-size: 12px; color: #ccc;
    }
    .alloc-item:hover { background: var(--savvy-check); color: #fff; }
    .alloc-item:last-child { border-bottom: none; }
</style>

<!-- UNIT DETAILS MODAL MOVED TO GLOBAL PARTIAL -->

<script>
jQuery(document).ready(function($) {
    console.log("Savvy Production UI Loaded");

    // 1. Open Order Modal
    $(document).on('click', '.order-row', function(e) {
        e.preventDefault(); // Stop any default link behavior
        
        console.log("CLICK DETECTED ON ROW");
        // alert("Click detected on row!"); // Uncomment if needed for extreme debug
        
        var id = $(this).data('id');
        console.log("Clicked Order Row ID:", id);

        var title = $(this).find('td:nth-child(2) strong').text();
        $('#modal-order-title').text('Order #' + id); 
        $('#modal-order-subtitle').text(title);

        // RESET Content
        $('#modal-component-list').html('<div class="loading-spinner">Loading...</div>');
        $('#modal-client-info').html('');

        // FADE IN with Flex
        // Note: fadeIn() sets display:block which breaks centering.
        // We use css('display','flex').hide().fadeIn() but override display via CSS !important or reset it.
        // Better approach:
        $('#modal-order-details').css({
            'display': 'flex',
            'opacity': 0
        }).animate({ opacity: 1 }, 100);

        loadOrderDetails(id);
    });

    // 2. Close Logic
    function closeModal() {
        $('#modal-order-details').animate({ opacity: 0 }, 100, function() {
            $(this).css('display', 'none');
        });
        $('.alloc-dropdown').hide();
    }
    $('.modal-close').on('click', closeModal);

    $(document).on('click', '#modal-order-details', function(e) {
        if(e.target.id === 'modal-order-details') closeModal();
    });

    $(document).on('keyup', function(e) {
        if (e.key === "Escape") {
            if($('#modal-unit-details').is(':visible')) {
                $('#modal-unit-details').fadeOut(100);
            } else if($('#modal-order-details').is(':visible')) {
                closeModal();
            }
        }
    });

    // 3. Unit Details Modal Logic
    $('.unit-modal-close').on('click', function() {
        $('#modal-unit-details').fadeOut(100);
    });

    $(document).on('click', '#modal-unit-details', function(e) {
        if(e.target.id === 'modal-unit-details') $('#modal-unit-details').fadeOut(100);
    });

    // Open Unit Details
    $(document).on('click', '.view-unit-details', function(e) {
        e.stopPropagation();
        var uid = $(this).data('uid');
        console.log("View Unit:", uid);

        $('#modal-unit-details').css('display', 'flex').hide().fadeIn(100);
        
        // Reset/Loading
        $('#view-title').text('Loading...');
        $('#view-cost').text('...');
        $('#view-serial').text('SN: ...');

        $.post(savvy_vars.ajax_url, {
            action: 'savvy_get_unit_details',
            nonce: savvy_vars.nonce,
            unit_id: uid
        }, function(res) {
             if(res.success) {
                 var d = res.data;
                 $('#view-title').text(d.title);
                 $('#view-serial').text('SN: ' + d.serial);
                 $('#view-cost').text('$' + d.cost);
                 $('#view-date').text(d.date);
                 $('#view-upc').text(d.upc);
                 $('#view-condition').text(d.condition);
             }
        });
    });

    // 4. Load Order Helper & Tab Logic
    var currentOrderData = null;

    function renderManifest(buildID) {
        if(!currentOrderData || !currentOrderData.builds) return;
        
        // Find build in data
        // Note: IDs might be strings or ints, use flexible comparison
        var build = currentOrderData.builds.find(function(b) { return b.id == buildID; });
        if(!build) return;
        
        // Update Context for Allocation
        $('#modal-order-details').data('order-id', buildID);

        // Update Tabs UI
        $('.build-tab').css({'color':'#888', 'border-bottom':'2px solid transparent', 'font-weight':'normal'});
        $('.build-tab[data-bid="'+buildID+'"]').css({'color':'#fff', 'border-bottom':'2px solid #00b9eb', 'font-weight':'bold'});

        var html = '';
        if(build.components && build.components.length > 0) {
            build.components.forEach(function(c) {
                var status_html = '';
                if (c.allocated) {
                    status_html = '<span class="badge-alloc view-unit-details" data-uid="'+c.unit_id+'" style="cursor:pointer;">Allocated</span> ' +
                                  '<span class="view-unit-details" data-uid="'+c.unit_id+'" style="font-size:11px; color:#aaa; cursor:pointer; margin-right:5px;">'+c.unit_serial+'</span> ' +
                                  '<span class="dashicons dashicons-edit action-icon btn-allocate" title="Change Unit"></span>';
                } else {
                    status_html = '<span class="badge-unalloc">Unallocated</span> ' +
                                  '<span class="dashicons dashicons-edit action-icon btn-allocate" title="Allocate Stock"></span>';
                }

                html += '<div class="component-row" data-cat="'+c.category+'" data-part="'+c.part_id+'">' +
                            '<div class="comp-label">'+c.category+'</div>' +
                            '<div class="comp-name">'+c.part_name+'</div>' +
                            '<div class="comp-status">' +
                                status_html +
                                '<div class="alloc-dropdown">' +
                                    '<input type="text" placeholder="Search Serial..." class="alloc-search">' +
                                    '<div class="alloc-list">Loading units...</div>' +
                                '</div>' +
                            '</div>' +
                        '</div>';
            });
            $('#modal-component-list').html(html);
        } else {
             $('#modal-component-list').html('<p style="padding:20px; color:#999;">No components configured for this build.</p>');
        }
    }

    $(document).on('click', '.build-tab', function() {
        var bid = $(this).data('bid');
        renderManifest(bid);
    });

    function loadOrderDetails(id) {
        $('#modal-order-details').data('order-id', id);
        console.log("Fetching details for:", id);
        
        $.post(savvy_vars.ajax_url, {
            action: 'savvy_get_order_details',
            nonce: savvy_vars.nonce,
            order_id: id
        }, function(res) {
            console.log("Order Details Res:", res);
            if(res.success) {
                var d = res.data;
                currentOrderData = d;
                
                // Header (Main Order ID)
                $('#modal-order-title').text('Order #' + d.main_display_id);
                $('#modal-order-subtitle').text(d.title);
                
                // Render Tabs
                var tabs = '';
                if(d.builds && d.builds.length > 0) {
                    d.builds.forEach(function(b) {
                        tabs += `<div class="build-tab" data-bid="${b.id}" style="cursor:pointer; padding:8px 15px; font-size:13px; color:#888;">${b.display_id}</div>`;
                    });
                }
                $('#modal-build-tabs').html(tabs);

                // Initial Render (Current Selection)
                renderManifest(id);

                // Customer Info
                if(d.customer) {
                    var c = d.customer;
                    var c_html = `
                        <div style="font-size:14px; font-weight:bold; color:#fff; margin-bottom:5px;">${c.name}</div>
                        <div style="font-size:12px; color:#aaa; margin-bottom:5px;">${c.email}</div>
                        <div style="font-size:12px; color:#aaa; margin-bottom:10px;">${c.phone}</div>
                        <div style="font-size:12px; color:#888; margin-bottom:15px; border-left:2px solid #333; padding-left:10px; line-height:1.4;">
                            ${c.address}
                        </div>
                        <a href="${c.profile_url}" target="_blank" class="button" style="width:100%; text-align:center; display:block;">View Profile</a>
                    `;
                    $('#modal-client-info').html(c_html);
                }

            } else {
                $('#modal-component-list').html('<p style="color:red;">Error loading details: ' + res.data + '</p>');
            }
        });
    }

    // 5. Allocation Logic
    $(document).on('click', '.btn-allocate', function(e) {
        e.stopPropagation();
        var $row = $(this).closest('.component-row');
        var $dropdown = $row.find('.alloc-dropdown');
        var partID = $row.data('part');

        console.log("Allocate clicked for Part:", partID);

        $('.alloc-dropdown').not($dropdown).hide();
        $dropdown.slideDown(150);
        $dropdown.find('.alloc-search').focus(); 

        if( $dropdown.find('.alloc-item').length === 0 ) {
            $.post(savvy_vars.ajax_url, {
                action: 'savvy_get_available_units',
                nonce: savvy_vars.nonce,
                part_id: partID
            }, function(res) {
                if(res.success) {
                    var html = '';
                    if(res.data.length > 0) {
                        res.data.forEach(function(u) {
                            html += `<div class="alloc-item" data-uid="${u.id}">${u.serial}</div>`;
                        });
                    } else {
                        html = '<div style="padding:10px; color:#999; font-style:italic;">No stock available.</div>';
                    }
                    $dropdown.find('.alloc-list').html(html);
                }
            });
        }
    });

    $(document).on('click', '.alloc-dropdown', function(e) { e.stopPropagation(); });
    $(document).on('click', function() { $('.alloc-dropdown').hide(); });

    $(document).on('click', '.alloc-item', function() {
        var $item = $(this);
        var unitID = $item.data('uid');
        var $row = $item.closest('.component-row');
        var $dropdown = $item.closest('.alloc-dropdown');
        var orderID = $('#modal-order-details').data('order-id');
        var category = $row.data('cat');

        if(!unitID) return;
        $item.text('Allocating...').css('opacity', '0.5');

        $.post(savvy_vars.ajax_url, {
            action: 'savvy_allocate_unit',
            nonce: savvy_vars.nonce,
            order_id: orderID,
            unit_id: unitID,
            category: category
        }, function(res) {
            if(res.success) {
                loadOrderDetails(orderID);
            } else {
                alert('Error allocating: ' + res.data);
                $item.text($item.text().replace('Allocating...', '')).css('opacity', '1');
            }
        });
    });

    // 6. Unit Modal Logic Removed (Handled by Global savvy-inventory.js)

    $(document).on('keyup', '.alloc-search', function() {
        var val = $(this).val().toLowerCase();
        $(this).closest('.alloc-dropdown').find('.alloc-item').each(function() {
            var text = $(this).text().toLowerCase();
            $(this).toggle(text.indexOf(val) > -1);
        });
    });
});
</script>
