<?php
// Savvy Settings Page

// 1. Fetch Parts (SQL)
global $wpdb;
$t_cat = $wpdb->prefix . 'savvy_catalogue';
$parts = $wpdb->get_results("SELECT * FROM $t_cat ORDER BY title ASC");

$categories = ['CPU', 'Motherboard', 'RAM', 'GPU', 'Storage', 'PSU', 'Case', 'Cooler'];
?>

<div class="savvy-wrapper">
    
    <div class="savvy-header">
        <div>
            <h1>Settings & Configuration</h1>
        </div>
    </div>

    <!-- TABS -->
    <h2 class="nav-tab-wrapper" style="margin-bottom:20px;">
        <a href="#tab-catalogue" class="nav-tab nav-tab-active">Product Catalogue</a>
        <a href="#tab-general" class="nav-tab">General Settings</a>
    </h2>

    <!-- TAB 1: PRODUCT CATALOGUE -->
    <div id="tab-catalogue" class="savvy-tab-content">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
            <h3>Master Product List</h3>
            <button id="btn-create-part" class="button button-primary" style="background:#2271b1;">
                <span class="dashicons dashicons-plus"></span> Create New Part
            </button>
        </div>

        <div class="savvy-inventory-list">
            <table class="units-table" style="background:#fff; box-shadow:0 1px 3px rgba(0,0,0,0.1); border-radius:8px;">
                <thead>
                    <tr>
                        <th style="padding:15px;">Category</th>
                        <th>Brand & Model</th>
                        <th>Part ID</th>
                        <th>Specs Summary</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($parts): foreach($parts as $p): 
                        $specs = json_decode($p->specs, true);
                        if(!is_array($specs)) $specs = [];
                        
                        $cat = $p->category ?: '-';
                        
                        // Build Spec Summary
                        $s_list = [];
                        if($cat == 'CPU') $s_list[] = $specs['cpu_socket'] ?? '';
                        if($cat == 'GPU') $s_list[] = $specs['gpu_series'] ?? '';
                        if($cat == 'RAM') $s_list[] = ($specs['ram_capacity'] ?? '') . 'GB ' . ($specs['ram_ddr_type'] ?? '');
                        if($cat == 'Motherboard') $s_list[] = ($specs['mb_socket'] ?? '') . ' ' . ($specs['mb_form_factor'] ?? '');
                        
                        $spec_str = implode(', ', array_filter($s_list));
                    ?>
                        <tr>
                            <td style="padding:15px;"><span class="badge <?php echo strtolower($cat); ?>"><?php echo esc_html($cat); ?></span></td>
                            <td><strong><?php echo esc_html($p->title); ?></strong></td>
                            <td><?php echo esc_html($p->sku); ?></td>
                            <td><?php echo esc_html($spec_str); ?></td>
                            <td><a href="#" style="font-size:12px; color:#888;">Edit (Coming Soon)</a></td>
                        </tr>
                    <?php endforeach; else: ?>
                        <tr><td colspan="5" style="text-align:center; padding:20px;">No parts defined. Create one to get started.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- TAB 2: GENERAL SETTINGS -->
    <div id="tab-general" class="savvy-tab-content" style="display:none;">
        <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
            <h3>General Configuration</h3>
            <p>Global settings for the Savvy Ops System will go here.</p>
            <hr>
            <div class="form-group">
                <label>Company Name</label>
                <input type="text" value="Savvy Computers" style="width:300px;">
            </div>
        </div>
    </div>

</div>

<!-- Modal: Create Part (Same as before) -->
<div id="modal-create-part" class="savvy-modal-overlay">
    <div class="savvy-modal">
        <form id="form-create-part">
            <div class="modal-header">
                <h2>Create Catalogue Item</h2>
                <span class="dashicons dashicons-no-alt modal-close" style="cursor:pointer;"></span>
            </div>
            
            <div class="modal-body">
                
                <!-- Quick Scan (Universal) -->
                <div class="form-group" style="background:#f6ffed; padding:10px; border:1px dashed #52c41a; border-radius:4px; margin-bottom:15px;">
                    <label style="color:#389e0d; font-weight:bold;">⚡ Universal Scan (UPC/EAN)</label>
                    <div style="display:flex; gap:10px;">
                        <input type="text" id="scan-universal-settings" placeholder="Scan any barcode here..." style="flex:1; border:1px solid #52c41a;" autocomplete="off">
                        <button type="button" class="button btn-scan-trigger" data-target="#scan-universal-settings" data-reader="#reader-settings" title="Use Camera"><span class="dashicons dashicons-camera" style="margin-top:3px;"></span></button>
                    </div>
                    <div id="reader-settings" class="savvy-scanner-container" style="display:none; margin-top:10px; border:1px solid #ccc;"></div>
                </div>

                <!-- Identity -->
                <h4 style="margin-top:0; border-bottom:1px solid #eee; padding-bottom:5px;">Identity</h4>
                <div class="form-grid">
                    <div class="form-group">
                        <label>Category</label>
                        <select name="savvy_category" id="new-part-category" required>
                            <option value="">-- Select --</option>
                            <?php foreach($categories as $cat) echo "<option value='$cat'>$cat</option>"; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Brand</label>
                        <input type="text" name="savvy_brand" placeholder="e.g. ASUS" required>
                    </div>
                    <div class="form-group" style="grid-column: span 2;">
                        <label>Model Name</label>
                        <input type="text" name="savvy_model" placeholder="e.g. ROG Strix GeForce RTX 4090" required>
                    </div>
                        <div class="form-group">
                    <div class="form-group">
                        <label>Part ID (Internal SKU)</label>
                        <input type="text" name="savvy_part_id" placeholder="SKU-123">
                    </div>
                    <div class="form-group">
                        <label>Generic UPC (12)</label>
                        <input type="text" name="savvy_upc" placeholder="Universal Product Code">
                    </div>
                    <div class="form-group">
                        <label>Generic EAN (13)</label>
                        <input type="text" name="savvy_ean" placeholder="European Article Number">
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="savvy_status">
                            <option value="Active">Active</option>
                            <option value="Discontinued">Discontinued</option>
                        </select>
                    </div>
                </div>

                <!-- Tech Specs (Conditional) -->
                <div id="tech-specs-section" style="display:none; background:#f9f9f9; padding:10px; border-radius:4px; margin-top:15px;">
                    <h4 style="margin-top:0;">Technical Specs</h4>
                    <div class="savvy-form-grid">
                        <!-- CPU -->
                        <div class="savvy-form-group spec-group field-cpu_socket savvy-hidden"><label>Socket</label><input type="text" name="cpu_socket" placeholder="AM5"></div>
                        <div class="savvy-form-group spec-group field-cpu_platform savvy-hidden"><label>Platform</label><select name="cpu_platform"><option>AMD</option><option>Intel</option></select></div>
                        
                        <!-- MB -->
                        <div class="savvy-form-group spec-group field-mb_socket savvy-hidden"><label>Socket</label><input type="text" name="mb_socket"></div>
                        <div class="savvy-form-group spec-group field-mb_chipset savvy-hidden"><label>Chipset</label><input type="text" name="mb_chipset"></div>
                        <div class="savvy-form-group spec-group field-mb_form_factor savvy-hidden"><label>Form Factor</label><select name="mb_form_factor"><option>ATX</option><option>mATX</option><option>ITX</option></select></div>
                        <div class="savvy-form-group spec-group field-mb_ram_type savvy-hidden"><label>RAM Type</label><select name="mb_ram_type"><option>DDR4</option><option>DDR5</option></select></div>
                            
                        <!-- RAM -->
                        <div class="savvy-form-group spec-group field-ram_ddr_type savvy-hidden"><label>DDR Type</label><select name="ram_ddr_type"><option>DDR4</option><option>DDR5</option></select></div>
                        <div class="savvy-form-group spec-group field-ram_capacity savvy-hidden"><label>Capacity (GB)</label><input type="number" name="ram_capacity"></div>
                        <div class="savvy-form-group spec-group field-ram_speed savvy-hidden"><label>Speed (MT/s)</label><input type="number" name="ram_speed"></div>
                        <div class="savvy-form-group spec-group field-ram_cas savvy-hidden"><label>CAS Latency</label><input type="text" name="ram_cas"></div>

                        <!-- GPU -->
                        <div class="savvy-form-group spec-group field-gpu_platform savvy-hidden"><label>Platform</label><select name="gpu_platform"><option>NVIDIA</option><option>AMD</option></select></div>
                        <div class="savvy-form-group spec-group field-gpu_series savvy-hidden"><label>Series</label><input type="text" name="gpu_series" placeholder="RTX 4090"></div>
                        <div class="savvy-form-group spec-group field-gpu_length savvy-hidden"><label>Length (mm)</label><input type="number" name="gpu_length"></div>

                        <!-- PSU -->
                        <div class="savvy-form-group spec-group field-psu_wattage savvy-hidden"><label>Wattage</label><input type="number" name="psu_wattage"></div>
                        <div class="savvy-form-group spec-group field-psu_rating savvy-hidden"><label>Efficiency</label><select name="psu_rating"><option>Bronze</option><option>Gold</option><option>Platinum</option><option>Titanium</option></select></div>
                        <div class="savvy-form-group spec-group field-psu_modularity savvy-hidden"><label>Modularity</label><select name="psu_modularity"><option>Full</option><option>Semi</option><option>Non</option></select></div>

                        <!-- Case -->
                        <div class="savvy-form-group spec-group field-case_size savvy-hidden"><label>Size</label><select name="case_size"><option>ATX</option><option>mATX</option><option>ITX</option></select></div>
                        <div class="savvy-form-group spec-group field-case_mb_support savvy-hidden"><label>MB Support</label><select name="case_mb_support"><option>ATX</option><option>mATX</option><option>ITX</option></select></div>
                        <div class="savvy-form-group spec-group field-case_gpu_max savvy-hidden"><label>Max GPU (mm)</label><input type="number" name="case_gpu_max"></div>
                        <div class="savvy-form-group spec-group field-case_cpu_max savvy-hidden"><label>Max Cooler (mm)</label><input type="number" name="case_cpu_max"></div>

                        <!-- Cooler -->
                        <div class="savvy-form-group spec-group field-cooler_type savvy-hidden"><label>Type</label><select name="cooler_type" id="cooler_type"><option value="">--</option><option value="Air">Air</option><option value="AIO">AIO (Liquid)</option></select></div>
                        <div class="savvy-form-group spec-group field-cooler_radiator savvy-hidden"><label>Radiator Size</label><select name="cooler_radiator"><option>120</option><option>240</option><option>280</option><option>360</option></select></div>
                        <div class="savvy-form-group spec-group field-cooler_height savvy-hidden"><label>Height (mm)</label><input type="number" name="cooler_height"></div>

                        <!-- Storage -->
                        <div class="savvy-form-group spec-group field-storage_type savvy-hidden"><label>Type</label><select name="storage_type"><option>NVMe</option><option>SATA</option></select></div>
                        <div class="savvy-form-group spec-group field-storage_form savvy-hidden"><label>Form Factor</label><select name="storage_form"><option>M.2 2280</option><option>2.5"</option></select></div>
                        <div class="savvy-form-group spec-group field-storage_cap savvy-hidden"><label>Capacity</label><input type="text" name="storage_cap"></div>
                        <div class="savvy-form-group spec-group field-storage_iface savvy-hidden"><label>Interface</label><input type="text" name="storage_iface" placeholder="PCIe Gen4"></div>
                    </div>
                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="button btn-cancel">Cancel</button>
                <button type="submit" class="button button-primary btn-save">Create Part</button>
            </div>
        </form>
    </div>
</div>

<script>
    // Tab Switcher Simple Inline
    jQuery(document).ready(function($) {
        $('.nav-tab').on('click', function(e) {
            e.preventDefault();
            $('.nav-tab').removeClass('nav-tab-active');
            $(this).addClass('nav-tab-active');
            
            $('.savvy-tab-content').hide();
            const target = $(this).attr('href');
            $(target).show();
        });
    });
</script>
