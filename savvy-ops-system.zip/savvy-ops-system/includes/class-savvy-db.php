<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Class Savvy_DB
 * Centralized Database Abstraction Layer for Savvy Ops.
 * Enforces strict typing and security.
 */
class Savvy_DB {

    /**
     * Get table name with prefix
     */
    public static function table( string $name ): string {
        global $wpdb;
        return $wpdb->prefix . 'savvy_' . $name;
    }

    /**
     * Get Standard Categories
     */
    public static function get_categories(): array {
        return ['CPU', 'Cooler', 'Motherboard', 'RAM', 'Storage', 'GPU', 'PSU', 'Case'];
    }

    /**
     * SEARCH Parts (Catalogue)
     * 
     * @param string $term Search term
     * @param string $category Category filter (optional)
     * @param int $limit Max results
     * @return array Array of objects {id, title, category, sku}
     */
    public static function search_parts( string $term, string $category = '', int $limit = 50 ): array {
        global $wpdb;
        $t_cat = self::table('catalogue');
        
        $term = sanitize_text_field($term);
        
        $where_clauses = ["1=1"];
        $args = [];

        // Category Filter
        if ( !empty($category) && $category !== 'ALL' ) {
            $where_clauses[] = "category = %s";
            $args[] = $category;
        }

        // Search Term
        if ( !empty($term) ) {
            $where_clauses[] = "(title LIKE %s OR sku LIKE %s)";
            $like = '%' . $wpdb->esc_like($term) . '%';
            $args[] = $like;
            $args[] = $like;
        }

        $where_sql = implode(' AND ', $where_clauses);
        $sql = "SELECT id, title, category, sku, stock_count FROM $t_cat WHERE $where_sql ORDER BY title ASC LIMIT %d";
        $args[] = $limit;

        return $wpdb->get_results( $wpdb->prepare( $sql, $args ) );
    }

    /**
     * GET Single Part by ID
     * 
     * @param int $id Part ID
     * @return object|null Row or null
     */
    public static function get_part( int $id ) {
        if(!$id) return null;
        global $wpdb;
        $t = self::table('catalogue');
        return $wpdb->get_row( $wpdb->prepare("SELECT * FROM $t WHERE id = %d", $id) );
    }

    /**
     * GET Batch Parts by IDs (Solves N+1)
     * 
     * @param array $ids List of Part IDs
     * @return array Keyed by ID [ id => {row} ]
     */
    public static function get_parts_batch( array $ids ): array {
        if(empty($ids)) return [];
        global $wpdb;
        $t = self::table('catalogue');
        
        // Sanitize integers
        $clean_ids = array_map('absint', $ids);
        $in_str = implode(',', $clean_ids);
        
        $results = $wpdb->get_results("SELECT * FROM $t WHERE id IN ($in_str)");
        
        $mapped = [];
        if($results) {
            foreach($results as $r) {
                $mapped[$r->id] = $r;
            }
        }
        return $mapped;
    }

    /**
     * SAVE Configuration (Connector)
     * 
     * @param int $product_id Base Product ID
     * @param array $data Configuration Array
     * @return int New Config ID
     */
    public static function save_config( int $product_id, array $data ): int {
        global $wpdb;
        $t = self::table('configurations');
        
        $json = json_encode($data);
        $hash = hash('sha256', $json . time()); 

        $res = $wpdb->insert($t, [
            'base_product_id'    => $product_id,
            'configuration_data' => $json,
            'config_hash'        => $hash,
            'created_at'         => current_time('mysql')
        ]);

        return $res ? $wpdb->insert_id : 0;
    }

    /**
     * GET Configuration
     * 
     * @param int $id Config ID
     * @return array|null Decoded data or null
     */
    public static function get_config( int $id ) {
        if(!$id) return null;
        global $wpdb;
        $t = self::table('configurations');
        
        $row = $wpdb->get_row($wpdb->prepare("SELECT configuration_data FROM $t WHERE id = %d", $id));
        if($row && !empty($row->configuration_data)) {
            return json_decode($row->configuration_data, true);
        }
        return null;
    }

    /**
     * VERIFY Nonce & Capability (Security Helper)
     * 
     * @param string $action Nonce action name
     * @param string $cap Capability required (default 'edit_posts')
     */
    public static function verify_ajax( string $action, string $cap = 'edit_posts' ): void {
        check_ajax_referer( $action, 'nonce' );
        if ( ! current_user_can( $cap ) ) {
            wp_send_json_error( 'Forbidden: Insufficient Permissions' );
        }
    }

    /**
     * CREATE Savvy Order (Sync)
     * 
     * @param array $data {wc_order_id, wc_build_index, client_name, title, status, priority}
     * @return int New Order ID
     */
    public static function create_savvy_order( array $data ): int {
        global $wpdb;
        $t = self::table('orders');
        
        // Defaults
        $defaults = [
            'status' => 'Pending', 
            'priority' => 'Normal',
            'date_created' => current_time('mysql')
        ];
        $insert = array_merge($defaults, $data);
        
        $res = $wpdb->insert($t, $insert);
        return $res ? $wpdb->insert_id : 0;
    }

    /**
     * ADD Component to Savvy Order
     * 
     * @param int $order_id Savvy Order ID
     * @param string $category Category Name
     * @param int $catalogue_id Part ID
     * @return int New Component ID
     */
    public static function add_order_component( int $order_id, string $category, int $catalogue_id ): int {
        global $wpdb;
        $t = self::table('order_components');
        
        $res = $wpdb->insert($t, [
            'order_id' => $order_id,
            'category' => $category,
            'required_catalogue_id' => $catalogue_id
        ]);
        return $res ? $wpdb->insert_id : 0;
    }
    
    /**
     * DELETE Savvy Order & Components
     * 
     * @param int $savvy_order_id
     */
    public static function delete_savvy_order( int $savvy_order_id ): void {
        global $wpdb;
        $t_orders = self::table('orders');
        $t_comps = self::table('order_components');
        
        $wpdb->delete($t_comps, ['order_id' => $savvy_order_id]);
        $wpdb->delete($t_orders, ['id' => $savvy_order_id]);
    }
    /**
     * CLEAR Components (Refresh Logic)
     *
     * @param int $savvy_order_id
     */
    public static function clear_order_components( int $savvy_order_id ): void {
        global $wpdb;
        $t = self::table('order_components');
        $wpdb->delete($t, ['order_id' => $savvy_order_id]);
    }
}
