<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * INVENTORY HUB - HELPER FUNCTIONS
 * Note: Legacy CPT Admin Columns/Metaboxes have been removed.
 * This file now explicitly handles AJAX for the modern SQL-based Inventory Hub.
 */

// 4. AJAX: Get Unit Details (Modal)
add_action( 'wp_ajax_savvy_get_unit_details', 'savvy_ajax_get_unit_details' );
function savvy_ajax_get_unit_details() {
    check_ajax_referer( 'savvy_inventory_nonce', 'nonce' );
    global $wpdb;
    
    // JS sends 'unit_id', not 'uid'
    $uid = absint($_POST['unit_id']);
    
    $t_units = $wpdb->prefix . 'savvy_units';
    $t_cat = $wpdb->prefix . 'savvy_catalogue';
    $t_orders = $wpdb->prefix . 'savvy_orders';
    
    // Fetch Unit + Part Info
    $sql = "SELECT u.*, c.title as part_title, c.sku, c.upc, o.wc_order_id, o.title as order_title 
            FROM $t_units u 
            JOIN $t_cat c ON u.catalogue_id = c.id
            LEFT JOIN $t_orders o ON u.order_id = o.id
            WHERE u.id = %d";
            
    $unit = $wpdb->get_row($wpdb->prepare($sql, $uid));
    
    if(!$unit) wp_send_json_error('Unit not found');
    
    // Format Data to match JS expectations
    $data = [
        'id' => $unit->id,
        'serial' => $unit->serial,
        'cost' => $unit->cost, 
        'date' => date('Y-m-d', strtotime($unit->date_received)),
        'status' => $unit->status,
        'condition' => $unit->item_condition ?? 'New',
        'title' => $unit->part_title, // JS expects 'title'
        'sku' => $unit->sku,
        'upc' => $unit->upc,
        'allocated_to' => $unit->order_title ? $unit->order_title : '-',
        'history' => [] // placeholder
    ];
    
    wp_send_json_success($data);
}

// 5. AJAX: Search Parts (Select2)
add_action( 'wp_ajax_savvy_search_parts', 'savvy_ajax_search_parts' );
function savvy_ajax_search_parts() {
    // SECURITY: Verify Nonce & Capability
    // This is STRICTLY for Admin usage now.
    Savvy_DB::verify_ajax('savvy_inventory_nonce', 'edit_products');
    
    $term = sanitize_text_field( $_GET['term'] ?? '' );
    $cat = sanitize_text_field( $_GET['category'] ?? '' );
    
    // Strict Type Search via Helper
    $results = Savvy_DB::search_parts($term, $cat);

    $options = [];
    if($results) {
        $grouped = [];
        foreach($results as $r) {
            $c = $r->category ?: 'Other';
            if(!isset($grouped[$c])) $grouped[$c] = [];
            // Admin gets full transparency if needed
            $grouped[$c][] = ['id' => $r->id, 'text' => $r->title . ' (#' . $r->sku . ')'];
        }
        
        foreach($grouped as $g_name => $items) {
            $options[] = ['text' => $g_name, 'children' => $items];
        }
    }

    wp_send_json(['results' => $options]);
}

// 6. AJAX: Public Limited Search (Frontend Builder)
add_action( 'wp_ajax_savvy_public_part_search', 'savvy_ajax_public_part_search' );
add_action( 'wp_ajax_nopriv_savvy_public_part_search', 'savvy_ajax_public_part_search' );

function savvy_ajax_public_part_search() {
    // No capability check for public search, but we limit DATA strictly.
    // Ensure term is passed
    $term = sanitize_text_field( $_GET['term'] ?? '' );
    
    // Whitelist Categories
    $cat = sanitize_text_field( $_GET['category'] ?? '' );
    $valid_cats = Savvy_DB::get_categories();
    
    // Force specific category or ALL? 
    // Builder usually requests specific category.
    
    // Allow 'ALL' but only if really needed? 
    // The previous frontend code allowed dynamic category.
    
    // Helper search
    $results = Savvy_DB::search_parts($term, $cat, 30); // Limit 30 for frontend

    $options = [];
    if($results) {
        $grouped = [];
        foreach($results as $r) {
            $c = $r->category ?: 'Other';
            if(!isset($grouped[$c])) $grouped[$c] = [];
            
            // SECURITY: ONLY return ID and Title. No Cost, No SKU if internal.
            // Using Title and ID.
            $grouped[$c][] = ['id' => $r->id, 'text' => $r->title];
        }
        
        foreach($grouped as $g_name => $items) {
            $options[] = ['text' => $g_name, 'children' => $items];
        }
    }

    wp_send_json(['results' => $options]);
}
