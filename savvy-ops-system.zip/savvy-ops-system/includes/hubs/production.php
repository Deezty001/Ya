<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

// AJAX: Get Order Details for Modal
// AJAX: Get Order Details for Modal
// AJAX: Get Order Details for Modal
add_action( 'wp_ajax_savvy_get_order_details', 'savvy_ajax_get_order_details' );

// AJAX: Create Order (SQL)
add_action( 'wp_ajax_savvy_create_order', 'savvy_ajax_create_order' );

function savvy_ajax_create_order() {
    check_ajax_referer( 'savvy_inventory_nonce', 'nonce' );
    if(!current_user_can('edit_shop_orders')) wp_send_json_error('Forbidden');

    $raw = [];
    parse_str($_POST['data'], $raw);

    $client = sanitize_text_field($raw['client_name'] ?? 'Guest');
    $title = sanitize_text_field($raw['order_title'] ?? 'New Order');
    $priority = sanitize_text_field($raw['priority'] ?? 'Normal');

    global $wpdb;
    $res = $wpdb->insert($wpdb->prefix . 'savvy_orders', [
        'client_name' => $client,
        'title' => $title,
        'status' => 'Pending',
        'priority' => $priority,
        'wc_order_id' => 0 // Manual order
    ]);

    if($res) {
        wp_send_json_success();
    } else {
        wp_send_json_error($wpdb->last_error);
    }
}

function savvy_ajax_get_order_details() {
    check_ajax_referer( 'savvy_inventory_nonce', 'nonce' );
    if(!current_user_can('edit_shop_orders')) wp_send_json_error('Forbidden');
    global $wpdb;
    
    $requested_id = absint( $_POST['order_id'] );
    $t_orders = $wpdb->prefix . 'savvy_orders';
    $t_comps = $wpdb->prefix . 'savvy_order_components';
    $t_cat = $wpdb->prefix . 'savvy_catalogue';
    $t_units = $wpdb->prefix . 'savvy_units';

    // 1. Get Context (Requested Order)
    $order = $wpdb->get_row($wpdb->prepare("SELECT * FROM $t_orders WHERE id = %d", $requested_id));
    if(!$order) wp_send_json_error('Order not found');

    $wc_id = $order->wc_order_id;
    
    // 2. Fetch Customer Details from WooCommerce
    $customer = [
        'name' => $order->client_name ?: 'Guest',
        'email' => '-',
        'phone' => '-',
        'address' => 'No address provided',
        'profile_url' => '#'
    ];

    if ($wc_id && function_exists('wc_get_order')) {
        $wc_obj = wc_get_order($wc_id);
        if ($wc_obj) {
            $customer['name'] = $wc_obj->get_formatted_billing_full_name();
            $customer['email'] = $wc_obj->get_billing_email();
            $customer['phone'] = $wc_obj->get_billing_phone();
            $customer['address'] = $wc_obj->get_formatted_billing_address(); // Returns break-separated HTML
            $customer['profile_url'] = get_edit_post_link($wc_id);
        }
    }

    // 3. Find Sibling Builds (or just self)
    if($wc_id) {
        $siblings = $wpdb->get_results($wpdb->prepare("SELECT * FROM $t_orders WHERE wc_order_id = %d ORDER BY wc_build_index ASC", $wc_id));
    } else {
        $siblings = [$order];
    }

    $builds_data = [];
    $main_title = $order->title; // Default
    if(!empty($siblings)) $main_title = $siblings[0]->title; // Use first build's title

    // 4. Loop Builds and Fetch Components
    foreach($siblings as $build) {
        $b_wc_id = $build->wc_order_id;
        $b_idx = $build->wc_build_index;
        $disp_id = $b_wc_id ? ($b_idx ? "$b_wc_id.$b_idx" : $b_wc_id) : $build->id;

        // Fetch Components
        $sql_c = "SELECT 
                    c.category, 
                    c.required_catalogue_id as part_id, 
                    cat.title as part_name, 
                    u.id as unit_id, 
                    u.serial as unit_serial
                  FROM $t_comps c
                  LEFT JOIN $t_cat cat ON c.required_catalogue_id = cat.id
                  LEFT JOIN $t_units u ON c.allocated_unit_id = u.id
                  WHERE c.order_id = %d";
                  
        $raw_components = $wpdb->get_results($wpdb->prepare($sql_c, $build->id));
        
        $components = [];
        foreach($raw_components as $rc) {
            $components[] = [
                'category' => $rc->category,
                'part_name' => $rc->part_name,
                'part_id' => $rc->part_id,
                'allocated' => !empty($rc->unit_id),
                'unit_id' => $rc->unit_id,
                'unit_serial' => $rc->unit_serial
            ];
        }

        $builds_data[] = [
            'id' => $build->id,
            'display_id' => $disp_id,
            'status' => $build->status,
            'components' => $components
        ];
    }
    
    // 5. Response
    $data = [
        'id' => $requested_id, 
        'main_display_id' => $wc_id ? $wc_id : $requested_id, 
        'title' => $main_title,
        'customer' => $customer,
        'builds' => $builds_data
    ];

    wp_send_json_success($data);
}


// AJAX: Get Available Units for a Part
add_action( 'wp_ajax_savvy_get_available_units', 'savvy_ajax_get_available_units' );
function savvy_ajax_get_available_units() {
    check_ajax_referer( 'savvy_inventory_nonce', 'nonce' );
    if(!current_user_can('edit_shop_orders')) wp_send_json_error('Forbidden');
    global $wpdb;
    
    $cat_id = absint($_POST['part_id']);
    $units = $wpdb->get_results($wpdb->prepare(
        "SELECT id, serial FROM {$wpdb->prefix}savvy_units WHERE catalogue_id = %d AND status = 'In_Stock'", 
        $cat_id
    ));
    
    wp_send_json_success($units);
}

// AJAX: Allocate Unit (SQL)
add_action( 'wp_ajax_savvy_allocate_unit', 'savvy_ajax_allocate_unit' );
function savvy_ajax_allocate_unit() {
    check_ajax_referer( 'savvy_inventory_nonce', 'nonce' );
    if(!current_user_can('edit_shop_orders')) wp_send_json_error('Forbidden');
    global $wpdb;
    
    $order_id = absint($_POST['order_id']);
    $unit_id = absint($_POST['unit_id']);
    $cat_name = sanitize_text_field($_POST['category']); // 'CPU' etc
    
    $t_comps = $wpdb->prefix . 'savvy_order_components';
    $t_units = $wpdb->prefix . 'savvy_units';

    // 1. Get Component Row
    $comp = $wpdb->get_row($wpdb->prepare("SELECT * FROM $t_comps WHERE order_id = %d AND category = %s", $order_id, $cat_name));
    if(!$comp) wp_send_json_error('Component requirement not found');
    
    // 2. Unallocate Existing (if any)
    if($comp->allocated_unit_id) {
        $wpdb->update($t_units, 
            ['status' => 'In_Stock', 'order_id' => NULL],
            ['id' => $comp->allocated_unit_id]
        );
    }
    
    // 3. Allocate New
    // Verify stock
    $unit = $wpdb->get_row($wpdb->prepare("SELECT status FROM $t_units WHERE id = %d", $unit_id));
    if(!$unit || $unit->status !== 'In_Stock') wp_send_json_error('Unit unavailable');
    
    // Update Component
    $wpdb->update($t_comps, 
        ['allocated_unit_id' => $unit_id],
        ['id' => $comp->id]
    );
    
    // Update Unit
    $wpdb->update($t_units,
        ['status' => 'Allocated', 'order_id' => $order_id],
        ['id' => $unit_id]
    );
    
    wp_send_json_success();
}

/**
 * HELPER: Simple Audit Logger using WordPress Comments
 */
// AJAX: Complete Stage (Advance Status)
add_action( 'wp_ajax_savvy_complete_stage', 'savvy_ajax_complete_stage' );
function savvy_ajax_complete_stage() {
    check_ajax_referer( 'savvy_inventory_nonce', 'nonce' );
    if(!current_user_can('edit_shop_orders')) wp_send_json_error('Forbidden');
    global $wpdb;
    
    $order_id = absint($_POST['order_id']);
    $t_orders = $wpdb->prefix . 'savvy_orders';
    
    // Get current status
    $order = $wpdb->get_row($wpdb->prepare("SELECT status FROM $t_orders WHERE id = %d", $order_id));
    if(!$order) {
        error_log("Savvy Debug: Order $order_id not found.");
        wp_send_json_error('Order not found');
    }
    
    $current = $order->status;
    error_log("Savvy Debug: Order $order_id status is '$current'.");

    $next = '';
    
    // Status Flow
    $flow = ['Pending', 'Allocation', 'Picking', 'Assembly', 'Testing', 'Completed'];
    // Normalize for search
    $idx = array_search(ucfirst(strtolower($current)), $flow);
    // Try exact match if normalization fails (e.g. if mixed case in array)
    if($idx === false) $idx = array_search($current, $flow);

    if($idx !== false && isset($flow[$idx + 1])) {
        $next = $flow[$idx + 1];
    } else {
        error_log("Savvy Debug: Cannot advance from '$current'. IDX: " . ($idx === false ? 'FALSE' : $idx));
        wp_send_json_error("Cannot advance from '$current'");
    }
    
    if($next) {
        $res = $wpdb->update($t_orders, ['status' => $next], ['id' => $order_id]);
        if($res === false) {
             error_log("Savvy Debug: SQL Update Failed: " . $wpdb->last_error);
             wp_send_json_error("DB Update Failed");
        }
        savvy_log_history(0, "Order #$order_id advanced from $current to $next by " . wp_get_current_user()->user_login);
        wp_send_json_success($next);
    }
}

function savvy_log_history($post_id, $message) {
    if($post_id === 0) {
        // Log to a custom table or just file if no post_id. 
        // For now, let's just error_log to avoid losing data
        error_log('Savvy Log: ' . $message);
        return;
    }
    
    $user = wp_get_current_user();
    $user_name = $user->exists() ? $user->user_login : 'System';
    
    $data = array(
        'comment_post_ID' => $post_id,
        'comment_author' => $user_name,
        'comment_content' => $message,
        'comment_type' => 'savvy_log',
        'comment_date' => current_time('mysql'),
        'comment_approved' => 1,
    );
    wp_insert_comment($data);
}

// End of production.php
