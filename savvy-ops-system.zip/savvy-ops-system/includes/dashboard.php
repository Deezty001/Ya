<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function savvy_ops_add_admin_menu() {
    // 1. Top Level Menu
    add_menu_page(
        'Savvy Operations',
        'Savvy Ops',
        'manage_options',
        'savvy-ops',
        'savvy_ops_dashboard_page',
        'dashicons-chart-pie',
        2
    );

    // 2. Submenus (Manual Construction)
    
    // Production (Projects)
    add_submenu_page(
        'savvy-ops',
        'Production Hub',
        'Production',
        'manage_options',
        'savvy-production',
        'savvy_ops_production_page_handler'
    );
    
    // Inventory (Operations)
    add_submenu_page(
        'savvy-ops',
        'Stock Operations',
        'Inventory',
        'manage_options',
        'savvy-inventory', // Slug
        'savvy_ops_inventory_page_handler' // Callback
    );
    
    // Support (Tickets)
    add_submenu_page(
        'savvy-ops',
        'Support Hub',
        'Support',
        'manage_options',
        'edit.php?post_type=savvy_ticket'
    );
    
    // Clients
     add_submenu_page(
        'savvy-ops',
        'Client Hub',
        'Clients',
        'manage_options',
        'edit.php?post_type=savvy_client'
    );

    // Settings (Catalogue + Misc)
    add_submenu_page(
        'savvy-ops',
        'Settings', 
        'Settings', 
        'manage_options',
        'savvy-settings', 
        'savvy_ops_settings_page_handler'
    );
}
add_action( 'admin_menu', 'savvy_ops_add_admin_menu' );

function savvy_ops_dashboard_page() {
    ?>
    <div class="wrap">
        <h1>Savvy Operations Dashboard</h1>
        <p>Welcome to the central hub for Savvy Computers.</p>
        
        <div class="savvy-widgets" style="display:flex; gap:20px; flex-wrap:wrap;">
            <!-- Active Projects -->
            <div class="card" style="flex:1; min-width:250px;">
                <h2>Active Projects</h2>
                <?php 
                global $wpdb;
                $active_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}savvy_orders WHERE status != 'Completed' AND status != 'Cancelled'");
                echo '<p class="text-4xl">' . intval($active_count) . '</p>';
                ?>
                <a href="<?php echo admin_url('admin.php?page=savvy-production'); ?>" class="button">View Projects</a>
            </div>

            <!-- Open Tickets -->
            <div class="card" style="flex:1; min-width:250px;">
                <h2>Support Tickets</h2>
                <?php 
                $tickets = wp_count_posts('savvy_ticket'); 
                echo '<p class="text-4xl">' . $tickets->publish . '</p>';
                ?>
                <a href="<?php echo admin_url('edit.php?post_type=savvy_ticket'); ?>" class="button">View Tickets</a>
            </div>
            
             <!-- Inventory Alert -->
            <div class="card" style="flex:1; min-width:250px;">
                <h2>Stock Levels</h2>
                <?php 
                $stock_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}savvy_units WHERE status = 'In_Stock'");
                echo '<p class="text-4xl">' . intval($stock_count) . ' <small style="font-size:14px; color:#888;">units</small></p>';
                ?>
                <a href="<?php echo admin_url('admin.php?page=savvy-inventory'); ?>" class="button">Manage Stock</a>
            </div>
        </div>
    </div>
    <?php
}


function savvy_ops_inventory_page_handler() {
    require_once plugin_dir_path( __FILE__ ) . 'pages/inventory-ui.php';
}


function savvy_ops_settings_page_handler() {
    require_once plugin_dir_path( __FILE__ ) . 'pages/settings-ui.php';
}

function savvy_ops_production_page_handler() {
    require_once plugin_dir_path( __FILE__ ) . 'pages/production-ui.php';
}
