<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 1. Add "Savvy Parts" Tab
 */
add_filter( 'woocommerce_product_data_tabs', 'savvy_ops_add_product_data_tab' );
function savvy_ops_add_product_data_tab( $tabs ) {
	$tabs['savvy_parts'] = array(
		'label'    => 'Savvy Parts',
		'target'   => 'savvy_parts_product_data',
		'class'    => array( 'show_if_simple', 'show_if_variable' ),
		'priority' => 21,
	);
	return $tabs;
}

/**
 * 1.5 Force Enqueue Select2 (Search)
 */
add_action( 'admin_enqueue_scripts', 'savvy_ops_enqueue_wc_scripts' );
function savvy_ops_enqueue_wc_scripts( $hook ) {
    if ( 'post.php' === $hook || 'post-new.php' === $hook ) {
        if( function_exists('wc_enqueue_js') ) {
            wp_enqueue_script( 'wc-enhanced-select' );
        }
    }
}

/**
 * 2. Add Tab Content (Panels) - AJAX Powered
 */
add_action( 'woocommerce_product_data_panels', 'savvy_ops_add_product_data_fields' );
function savvy_ops_add_product_data_fields() {
    global $post, $wpdb;
	echo '<div id="savvy_parts_product_data" class="panel woocommerce_options_panel hidden">';
    echo '<p class="form-field"><strong>Define PC Components (AJAX Powered)</strong><br>Select the standard Savvy Parts used in this build.</p>';

    $categories = Savvy_DB::get_categories();
    
    echo '<div style="padding:10px;">';
    
    // PERF: Batch Fetch Saved IDs to fix N+1
    $saved_ids = [];
    foreach ($categories as $cat) {
        $key = '_savvy_component_' . strtolower( $cat );
        $sid = get_post_meta($post->ID, $key, true);
        if($sid) $saved_ids[] = $sid;
    }
    $part_lookup = Savvy_DB::get_parts_batch($saved_ids);

    foreach ( $categories as $cat ) {
        $key = '_savvy_component_' . strtolower( $cat );
        $saved_id = get_post_meta($post->ID, $key, true);
        
        $saved_title = '';
        if($saved_id) {
            if(isset($part_lookup[$saved_id])) {
                $saved_title = $part_lookup[$saved_id]->title;
            } else {
                $saved_title = 'Part #' . $saved_id;
            }
        }

        echo '<div class="options_group savvy_component_row_' . strtolower($cat) . '" style="border-bottom:1px solid #eee; padding-bottom:15px; margin-bottom:10px; display:flex; align-items:center; flex-wrap:wrap;">';
        
        // Label
        echo '<label style="width:150px; font-weight:bold;">' . $cat . ':</label>';
        
        // Select2 Container (Use normal Select, initialized by our JS)
        echo '<select id="' . $key . '" name="' . $key . '" class="savvy-ajax-base-select" style="width: 400px; margin-right:20px;" data-cat="' . $cat . '">';
        if($saved_id) {
            echo '<option value="'.esc_attr($saved_id).'" selected>'.esc_html($saved_title).'</option>';
        }
        echo '</select>';
        
        // Spec Label
        $spec_key = '_savvy_spec_label_' . strtolower( $cat );
        $spec_val = get_post_meta($post->ID, $spec_key, true);
        echo '<input type="text" id="'.$spec_key.'" name="'.$spec_key.'" value="'.esc_attr($spec_val).'" placeholder="Public Spec Label (Auto-fills)" style="width:300px;">';
        
        echo '</div>';
    }
    
    echo '</div>'; // end padding container
    
    ?>
    <script>
    jQuery(document).ready(function($) {
        
        // Initialize Select2 with AJAX
        $('.savvy-ajax-base-select').each(function() {
            var $el = $(this);
            var cat = $el.data('cat');
            
            $el.select2({
                width: 'resolve',
                placeholder: 'Search ' + cat + '...',
                minimumInputLength: 0,
                ajax: {
                    url: ajaxurl,
                    dataType: 'json',
                    delay: 250,
                    data: function (params) {
                        return {
                            action: 'savvy_search_parts',
                            term: params.term, 
                            category: cat
                        };
                    },
                    processResults: function (data) {
                        return { results: data.results };
                    },
                    cache: true
                }
            });

            // Auto-fill Spec Label on selection
            $el.on('select2:select', function (e) {
                 var data = e.params.data;
                 var text = data.text;
                 var $row = $(this).closest('.options_group');
                 var $input = $row.find('input[type="text"]');
                 
                 // Only fill if empty or looks like default
                 // Explicit action: Update label when part changes
                 $input.val(text);
            });
        });
    });
    </script>
    <?php

	echo '</div>';
}

/**
 * 3. Save Fields
 */
add_action( 'woocommerce_process_product_meta', 'savvy_ops_save_product_data_fields' );
function savvy_ops_save_product_data_fields( $post_id ) {
    $categories = Savvy_DB::get_categories();
    foreach ( $categories as $cat ) {
        $cat_key = strtolower( $cat );
        $key_id = '_savvy_component_' . $cat_key;
        if ( isset( $_POST[ $key_id ] ) ) {
            update_post_meta( $post_id, $key_id, sanitize_text_field( $_POST[ $key_id ] ) );
        }
        $key_label = '_savvy_spec_label_' . $cat_key;
        if ( isset( $_POST[ $key_label ] ) ) {
            update_post_meta( $post_id, $key_label, sanitize_text_field( $_POST[ $key_label ] ) );
        }
    }
}

/**
 * HELPER: Case-Insensitive Map Value
 */
function savvy_get_map_val($map, $key) {
    if(empty($map)) return false;
    // Check exact
    if(isset($map[$key]) && !empty($map[$key])) return $map[$key];
    // Check Upper
    $u = strtoupper($key);
    if(isset($map[$u]) && !empty($map[$u])) return $map[$u];
    // Check Lower
    $l = strtolower($key);
    if(isset($map[$l]) && !empty($map[$l])) return $map[$l];
    // Check Title
    $t = ucfirst(strtolower($key));
    if(isset($map[$t]) && !empty($map[$t])) return $map[$t];
    
    return false;
}

/**
 * 4. Order Sync: Create Project Logic
 */
// Listen to multiple hooks to ensure we catch all order creations (manual and checkout)
add_action( 'woocommerce_checkout_order_processed', 'savvy_ops_import_wc_order', 10, 1 );
add_action( 'woocommerce_order_status_processing', 'savvy_ops_import_wc_order', 10, 1 );
add_action( 'woocommerce_order_status_completed',  'savvy_ops_import_wc_order', 10, 1 );
add_action( 'woocommerce_new_order', 'savvy_ops_import_wc_order', 20, 1 ); 
add_action( 'woocommerce_new_order', 'savvy_ops_import_wc_order', 20, 1 ); 
add_action( 'woocommerce_saved_order_items', 'savvy_ops_import_wc_order', 10, 1 ); // Crucial for Admin Edits

// Cancellation / Refund Logic
add_action( 'woocommerce_order_status_refunded', 'savvy_ops_handle_cancellation', 10, 1 );
add_action( 'woocommerce_order_status_cancelled', 'savvy_ops_handle_cancellation', 10, 1 );
add_action( 'woocommerce_order_status_failed', 'savvy_ops_handle_cancellation', 10, 1 );

function savvy_ops_handle_cancellation($order_id) {
    global $wpdb;
    $t_orders = $wpdb->prefix . 'savvy_orders';
    // Update status to Cancelled
    $wpdb->update($t_orders, ['status' => 'Cancelled'], ['wc_order_id' => $order_id]);
    
    // Optional: We could clear components here, but keeping record is usually safer for history.
}

// Catch manual updates in admin
add_action( 'save_post_shop_order', 'savvy_ops_import_on_save', 10, 3 );
add_action( 'woocommerce_process_shop_order_meta', 'savvy_ops_import_wc_order', 10, 1 );

function savvy_ops_import_on_save($post_id, $post, $update) {
    if($post->post_status === 'auto-draft') return;
    savvy_ops_import_wc_order($post_id);
}

/**
 * 5. RE-SYNC Components for an existing order.
 * Called when Admin PC Builder updates options.
 * (Now redundant with robust import, but kept for compatibility)
 */
function savvy_ops_refresh_components($wc_order_id) {
    // Forward to main import function which handles clear/refresh now
    savvy_ops_import_wc_order($wc_order_id);
}

/**
 * 6. DELETE Sync: Remove from Savvy Ops when WC Order is deleted
 */
add_action('wp_trash_post', 'savvy_ops_handle_order_delete'); // For moved to trash
add_action('before_delete_post', 'savvy_ops_handle_order_delete'); // For permanent delete

function savvy_ops_handle_order_delete($post_id) {
    if(get_post_type($post_id) !== 'shop_order') return;

    global $wpdb;
    $t_orders = $wpdb->prefix . 'savvy_orders';
    
    // Find Savvy Builds linked to this Order
    $builds = $wpdb->get_results($wpdb->prepare("SELECT id FROM $t_orders WHERE wc_order_id = %d", $post_id));
    
    if($builds) {
        foreach($builds as $b) {
            Savvy_DB::delete_savvy_order($b->id);
        }
    }
}

/**
 * 7. Manual Sync Button (Debugging Tool)
 */
add_action( 'add_meta_boxes', 'savvy_add_sync_metabox' );
function savvy_add_sync_metabox() {
    $screen = class_exists( '\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController' ) && wc_get_container()->get( \Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController::class )->custom_orders_table_usage_is_enabled()
        ? wc_get_page_screen_id( 'shop-order' )
        : 'shop_order';
        
    add_meta_box( 'savvy_sync_box', 'Savvy Ops Sync', 'savvy_render_sync_box', $screen, 'side', 'high' );
}

function savvy_render_sync_box($post_or_order) {
    // HPOS passes order object, Legacy passes post object
    $id = ( $post_or_order instanceof WC_Order ) ? $post_or_order->get_id() : $post_or_order->ID;
    echo '<button type="button" class="button button-primary" id="savvy-force-sync" data-id="'.$id.'">Sync to Production Hub</button>';
    echo '<span id="savvy-sync-msg" style="margin-left:10px;"></span>';
    ?>
    <script>
    jQuery(document).ready(function($){
        $('#savvy-force-sync').click(function(){
            var btn = $(this);
            btn.prop('disabled', true).text('Syncing...');
            $.post(ajaxurl, {
                action: 'savvy_manual_sync',
                order_id: btn.data('id'),
                nonce: '<?php echo wp_create_nonce('savvy_sync_nonce'); ?>'
            }, function(res){
                if(res.success) {
                    btn.text('Synced!');
                    $('#savvy-sync-msg').text(res.data).css('color','green'); 
                    setTimeout(function(){ btn.prop('disabled', false).text('Sync to Production Hub'); }, 2000);
                } else {
                    btn.text('Retry');
                     btn.prop('disabled', false);
                    $('#savvy-sync-msg').text('Failed').css('color','red');
                    alert(res.data);
                }
            });
        });
    });
    </script>
    <?php
}

    
add_action('wp_ajax_savvy_manual_sync', function(){
    if(!current_user_can('edit_shop_orders')) wp_send_json_error('Forbidden');
    check_ajax_referer('savvy_sync_nonce', 'nonce');
    
    $oid = intval($_POST['order_id']);
    $logs = []; 
    savvy_ops_import_wc_order($oid, $logs); 
    
    // Check if it worked
    global $wpdb;
    $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}savvy_orders WHERE wc_order_id = %d LIMIT 1", $oid));
    
    // Truncate logs for display
    $log_msg = count($logs) . ' Ops: ' . implode(' | ', $logs);
    if(strlen($log_msg) > 100) $log_msg = substr($log_msg, 0, 97) . '...';

    if($exists) wp_send_json_success('Sync OK. ' . $log_msg);
    else wp_send_json_error('No order. ' . $log_msg);
});

function savvy_ops_import_wc_order( $order_id, &$logs = [] ) {
    if ( ! $order_id ) { $logs[] = 'No Order ID'; return; }
    
    // RACE CONDITION LOCK: Prevent multiple hooks firing simultaneously
    $lock_key = 'savvy_sync_lock_' . $order_id;
    if( get_transient($lock_key) ) {
        $logs[] = 'Locked (Debounced)';
        return; 
    }
    set_transient($lock_key, true, 5); // 5 Second Lock

    try {
        global $wpdb;
        $t_orders = $wpdb->prefix . 'savvy_orders';

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
             $logs[] = 'Could not load WC Order object';
             return;
        }

        $client = $order->get_formatted_billing_full_name();
        if(empty($client)) $client = 'Guest / Manual Order';

        // Get Historical Date for Sorting (Offset to Site Timezone)
        $date_obj = $order->get_date_created();
        if($date_obj) {
            // Ensure we are in the site's configured timezone
            $date_obj->setTimezone( new DateTimeZone( wp_timezone_string() ) );
            $date_created = $date_obj->format('Y-m-d H:i:s');
        } else {
            $date_created = current_time('mysql');
        }

        $build_counter = 0;
        $items = $order->get_items();
        
        if(empty($items)) {
             $logs[] = 'No Items found in Order (Yet?)';
             return;
        }

        // Loop Items
        foreach ( $items as $item_id => $item ) {
            $product = $item->get_product();
            if ( ! $product ) {
                $logs[] = "Item #$item_id has no product";
                continue;
            }
            
            $qty = $item->get_quantity();
            $logs[] = "Item: " . $product->get_name() . " (Qty: $qty)";
            
            // Loop Quantity
            for($q=0; $q < $qty; $q++) {
                $build_counter++;
                
                // 1. Check Existing
                $existing_id = $wpdb->get_var($wpdb->prepare(
                    "SELECT id FROM $t_orders WHERE wc_order_id = %d AND wc_build_index = %d LIMIT 1", 
                    $order_id, $build_counter
                ));

                $current_build_id = 0;

                if($existing_id) {
                    $wpdb->update($t_orders, [
                        'client_name' => $client,
                        'title' => 'Order #' . $order_id . ' - ' . $product->get_name(),
                        'date_created' => $date_created // Fix sorting for re-syncs
                    ], ['id' => $existing_id]);
                    
                    $current_build_id = $existing_id;
                    $logs[] = "Upd Build #$build_counter ($date_created)";
                    
                    // CLEAR COMPONENTS to ensure fresh sync
                    Savvy_DB::clear_order_components($current_build_id);
                } 
                else {
                    // CREATE
                    $build_title = 'Order #' . $order_id . ' - ' . $product->get_name();
                    
                    $current_build_id = Savvy_DB::create_savvy_order([
                        'wc_order_id' => $order_id,
                        'wc_build_index' => $build_counter,
                        'client_name' => $client,
                        'title' => $build_title,
                        'status' => 'Pending',
                        'priority' => 'Normal',
                        'date_created' => $date_created // Use historical date
                    ]);
                    $logs[] = "New Build #$build_counter ($date_created)";
                }
                
                // 3. Add Components (Fresh)
                $upgrade_map = [];
                $savvy_config_id = $item->get_meta('_savvy_config_id');
                if($savvy_config_id) {
                    $config = Savvy_DB::get_config($savvy_config_id);
                    if($config && isset($config['upgrade_map'])) $upgrade_map = $config['upgrade_map'];
                } 
                if(empty($upgrade_map)) $upgrade_map = $item->get_meta('_savvy_upgrade_map'); 
                
                $categories = Savvy_DB::get_categories();
                foreach ( $categories as $cat ) {
                    $final_sql_id = 0;
                    $upg_val = savvy_get_map_val($upgrade_map, $cat);
                    
                    if( $upg_val ) $final_sql_id = $upg_val;
                    else {
                        $cpt_part_id = $product->get_meta( '_savvy_component_' . strtolower( $cat ) );
                        if ( $cpt_part_id ) $final_sql_id = $cpt_part_id;
                    }
                    
                    if($final_sql_id) {
                        Savvy_DB::add_order_component($current_build_id, $cat, (int)$final_sql_id);
                    }
                }
            }
        }
    } catch (Exception $e) {
        $logs[] = 'Exception: ' . $e->getMessage();
        error_log('Savvy Sync Error: ' . $e->getMessage());
    }
}
