<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 1. Add "Savvy Parts" Tab
 */
add_filter( 'woocommerce_product_data_tabs', 'savvy_ops_add_product_data_tab' );
function savvy_ops_add_product_data_tab( $tabs ) {
	$tabs['savvy_parts'] = array(
		'label'    => 'Savvy Parts',
		'target'   => 'savvy_parts_product_data',
		'class'    => array( 'show_if_simple', 'show_if_variable' ),
		'priority' => 21,
	);
	return $tabs;
}

/**
 * 1.5 Force Enqueue Select2 (Search)
 */
add_action( 'admin_enqueue_scripts', 'savvy_ops_enqueue_wc_scripts' );
function savvy_ops_enqueue_wc_scripts( $hook ) {
    if ( 'post.php' === $hook || 'post-new.php' === $hook ) {
        if( function_exists('wc_enqueue_js') ) {
            wp_enqueue_script( 'wc-enhanced-select' );
        }
    }
}

/**
 * 2. Add Tab Content (Panels) - AJAX Powered
 */
add_action( 'woocommerce_product_data_panels', 'savvy_ops_add_product_data_fields' );
function savvy_ops_add_product_data_fields() {
    global $post, $wpdb;
	echo '<div id="savvy_parts_product_data" class="panel woocommerce_options_panel hidden">';
    echo '<p class="form-field"><strong>Define PC Components (AJAX Powered)</strong><br>Select the standard Savvy Parts used in this build.</p>';

    $categories = ['CPU', 'Cooler', 'Motherboard', 'RAM', 'Storage', 'GPU', 'PSU', 'Case'];
    
    echo '<div style="padding:10px;">';
    
    // PERF: Batch Fetch Saved IDs to fix N+1
    $saved_ids = [];
    foreach ($categories as $cat) {
        $key = '_savvy_component_' . strtolower( $cat );
        $sid = get_post_meta($post->ID, $key, true);
        if($sid) $saved_ids[] = $sid;
    }
    $part_lookup = Savvy_DB::get_parts_batch($saved_ids);

    foreach ( $categories as $cat ) {
        $key = '_savvy_component_' . strtolower( $cat );
        $saved_id = get_post_meta($post->ID, $key, true);
        
        $saved_title = '';
        if($saved_id) {
            if(isset($part_lookup[$saved_id])) {
                $saved_title = $part_lookup[$saved_id]->title;
            } else {
                $saved_title = 'Part #' . $saved_id;
            }
        }

        echo '<div class="options_group savvy_component_row_' . strtolower($cat) . '" style="border-bottom:1px solid #eee; padding-bottom:15px; margin-bottom:10px; display:flex; align-items:center; flex-wrap:wrap;">';
        
        // Label
        echo '<label style="width:150px; font-weight:bold;">' . $cat . ':</label>';
        
        // Select2 Container (Use normal Select, initialized by our JS)
        echo '<select id="' . $key . '" name="' . $key . '" class="savvy-ajax-base-select" style="width: 400px; margin-right:20px;" data-cat="' . $cat . '">';
        if($saved_id) {
            echo '<option value="'.esc_attr($saved_id).'" selected>'.esc_html($saved_title).'</option>';
        }
        echo '</select>';
        
        // Spec Label
        $spec_key = '_savvy_spec_label_' . strtolower( $cat );
        $spec_val = get_post_meta($post->ID, $spec_key, true);
        echo '<input type="text" id="'.$spec_key.'" name="'.$spec_key.'" value="'.esc_attr($spec_val).'" placeholder="Public Spec Label (Auto-fills)" style="width:300px;">';
        
        echo '</div>';
    }
    
    echo '</div>'; // end padding container
    
    ?>
    <script>
    jQuery(document).ready(function($) {
        
        // Initialize Select2 with AJAX
        $('.savvy-ajax-base-select').each(function() {
            var $el = $(this);
            var cat = $el.data('cat');
            
            $el.select2({
                width: 'resolve',
                placeholder: 'Search ' + cat + '...',
                minimumInputLength: 0,
                ajax: {
                    url: ajaxurl,
                    dataType: 'json',
                    delay: 250,
                    data: function (params) {
                        return {
                            action: 'savvy_search_parts',
                            term: params.term, 
                            category: cat
                        };
                    },
                    processResults: function (data) {
                        return { results: data.results };
                    },
                    cache: true
                }
            });

            // Auto-fill Spec Label on selection
            $el.on('select2:select', function (e) {
                 var data = e.params.data;
                 var text = data.text;
                 var $row = $(this).closest('.options_group');
                 var $input = $row.find('input[type="text"]');
                 
                 // Only fill if empty or looks like default
                 // Explicit action: Update label when part changes
                 $input.val(text);
            });
        });
    });
    </script>
    <?php

	echo '</div>';
}

/**
 * 3. Save Fields
 */
add_action( 'woocommerce_process_product_meta', 'savvy_ops_save_product_data_fields' );
function savvy_ops_save_product_data_fields( $post_id ) {
    $categories = ['CPU', 'Cooler', 'Motherboard', 'RAM', 'Storage', 'GPU', 'PSU', 'Case'];
    foreach ( $categories as $cat ) {
        $cat_key = strtolower( $cat );
        $key_id = '_savvy_component_' . $cat_key;
        if ( isset( $_POST[ $key_id ] ) ) {
            update_post_meta( $post_id, $key_id, sanitize_text_field( $_POST[ $key_id ] ) );
        }
        $key_label = '_savvy_spec_label_' . $cat_key;
        if ( isset( $_POST[ $key_label ] ) ) {
            update_post_meta( $post_id, $key_label, sanitize_text_field( $_POST[ $key_label ] ) );
        }
    }
}

/**
 * HELPER: Case-Insensitive Map Value
 */
function savvy_get_map_val($map, $key) {
    if(empty($map)) return false;
    // Check exact
    if(isset($map[$key]) && !empty($map[$key])) return $map[$key];
    // Check Upper
    $u = strtoupper($key);
    if(isset($map[$u]) && !empty($map[$u])) return $map[$u];
    // Check Lower
    $l = strtolower($key);
    if(isset($map[$l]) && !empty($map[$l])) return $map[$l];
    // Check Title
    $t = ucfirst(strtolower($key));
    if(isset($map[$t]) && !empty($map[$t])) return $map[$t];
    
    return false;
}

/**
 * 4. Order Sync: Create Project Logic
 */
// Listen to multiple hooks to ensure we catch all order creations (manual and checkout)
add_action( 'woocommerce_order_status_processing', 'savvy_ops_import_wc_order', 10, 1 );
add_action( 'woocommerce_order_status_completed',  'savvy_ops_import_wc_order', 10, 1 );
add_action( 'woocommerce_new_order', 'savvy_ops_import_wc_order', 10, 1 ); 
// Catch manual updates in admin if not yet created
add_action( 'save_post_shop_order', 'savvy_ops_import_on_save', 10, 3 );

function savvy_ops_import_on_save($post_id, $post, $update) {
    // Only if not auto-draft
    if($post->post_status === 'auto-draft') return;
    savvy_ops_import_wc_order($post_id);
}

function savvy_ops_import_wc_order( $order_id ) {
    if ( ! $order_id ) return;
    
    global $wpdb;
    $t_orders = $wpdb->prefix . 'savvy_orders';
    $t_comps = $wpdb->prefix . 'savvy_order_components';

    // 1. Check if already exists (Idempotency)
    $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $t_orders WHERE wc_order_id = %d LIMIT 1", $order_id));
    if($exists) return; 

    $order = wc_get_order( $order_id );
    if ( ! $order ) return;

    $client = $order->get_formatted_billing_full_name();
    if(empty($client)) $client = 'Guest / Manual Order';

    $build_counter = 0;

    // Loop Items
    foreach ( $order->get_items() as $item_id => $item ) {
        $product = $item->get_product();
        if ( ! $product ) continue;
        
        $qty = $item->get_quantity();
        
        // Loop Quantity (Create separate build for each unit)
        for($q=0; $q < $qty; $q++) {
            $build_counter++;
            
            // 2. Create Order Row
            $build_title = 'Order #' . $order_id . ' - ' . $product->get_name();
            
            $new_build_id = Savvy_DB::create_savvy_order([
                'wc_order_id' => $order_id,
                'wc_build_index' => $build_counter,
                'client_name' => $client,
                'title' => $build_title,
                'status' => 'Pending',
                'priority' => 'Normal'
            ]);
            
            // 3. Add Components
            $upgrade_map = [];
            
            // Connector Strategy: Hydrate from Config ID
            $savvy_config_id = $item->get_meta('_savvy_config_id');
            if($savvy_config_id) {
                // Fetch using Helper
                $config = Savvy_DB::get_config($savvy_config_id);
                if($config && isset($config['upgrade_map'])) {
                    $upgrade_map = $config['upgrade_map'];
                }
            } 
            // Legacy Fallback
            if(empty($upgrade_map)) {
                $upgrade_map = $item->get_meta('_savvy_upgrade_map'); 
            }
            
            if(defined('WP_DEBUG') && WP_DEBUG) {
                error_log("Savvy Sync: Importing Order #$order_id Item #$item_id. Map found via " . ($savvy_config_id ? "Config #$savvy_config_id" : "Legacy Meta"));
            }

            $categories = ['CPU', 'Cooler', 'Motherboard', 'RAM', 'Storage', 'GPU', 'PSU', 'Case'];
            foreach ( $categories as $cat ) {
                $final_sql_id = 0;
                
                // A. CHECK UPGRADE (Priority with Case Insensitive Check)
                $upg_val = savvy_get_map_val($upgrade_map, $cat);
                
                if( $upg_val ) {
                    $final_sql_id = $upg_val;
                } 
                // B. BASE SPEC (Fallback)
                else {
                    $cat_key = strtolower( $cat ); 
                    $cpt_part_id = $product->get_meta( '_savvy_component_' . $cat_key );
                    
                    if ( $cpt_part_id ) {
                        $final_sql_id = $cpt_part_id;
                    }
                }
                
                // INSERT into Build List
                if($final_sql_id) {
                    Savvy_DB::add_order_component($new_build_id, $cat, (int)$final_sql_id);
                }
            }
        }
    }
}

/**
 * 5. RE-SYNC Components for an existing order.
 * Called when Admin PC Builder updates options.
 */
function savvy_ops_refresh_components($wc_order_id) {
    global $wpdb;
    $t_orders = $wpdb->prefix . 'savvy_orders';
    $t_comps = $wpdb->prefix . 'savvy_order_components';

    if(defined('WP_DEBUG') && WP_DEBUG) {
        error_log("Savvy Refresh: Triggered for Order #$wc_order_id");
    }

    // 1. Get Existing Builds for this Order
    $builds = $wpdb->get_results($wpdb->prepare("SELECT id, wc_build_index FROM $t_orders WHERE wc_order_id = %d ORDER BY wc_build_index ASC", $wc_order_id));
    
    // If no builds exist yet (e.g. manual order creation flow didn't catch it yet), try to import it first
    if(!$builds) {
        savvy_ops_import_wc_order($wc_order_id);
        $builds = $wpdb->get_results($wpdb->prepare("SELECT id, wc_build_index FROM $t_orders WHERE wc_order_id = %d ORDER BY wc_build_index ASC", $wc_order_id));
        if(!$builds) return; // Still nothing
    }

    $build_map = [];
    foreach($builds as $b) {
        $build_map[$b->wc_build_index] = $b->id;
    }

    // 2. Re-Loop WC Items
    $order = wc_get_order($wc_order_id);
    if(!$order) return;

    $build_counter = 0;

    foreach ( $order->get_items() as $item_id => $item ) {
        $product = $item->get_product();
        if ( ! $product ) continue;
        
        $qty = $item->get_quantity();
        
        for($q=0; $q < $qty; $q++) {
            $build_counter++;
            
            if(!isset($build_map[$build_counter])) continue;
            $current_build_id = $build_map[$build_counter];

            // 3. CLEAR existing components
            Savvy_DB::clear_order_components($current_build_id);

            // 4. GENERATE new components
            $upgrade_map = [];

            // Connector Strategy: Hydrate
            $savvy_config_id = $item->get_meta('_savvy_config_id');
            if($savvy_config_id) {
                 $config = Savvy_DB::get_config($savvy_config_id);
                 if($config && isset($config['upgrade_map'])) $upgrade_map = $config['upgrade_map'];
            }
            // Legacy Fallback
            if(empty($upgrade_map)) {
                $upgrade_map = $item->get_meta('_savvy_upgrade_map'); 
            }
            
            if(defined('WP_DEBUG') && WP_DEBUG) {
                // IMPORTANT: Log the map to debug 'RAM' vs 'Ram'
                error_log("Savvy Refresh: Processing Build #$current_build_id (Item #$item_id).");
            }
            
            $categories = ['CPU', 'Cooler', 'Motherboard', 'RAM', 'Storage', 'GPU', 'PSU', 'Case'];
            foreach ( $categories as $cat ) {
                $final_sql_id = 0;
                
                // A. CHECK UPGRADE (Case Insensitive)
                $upg_val = savvy_get_map_val($upgrade_map, $cat);

                if( $upg_val ) {
                    $final_sql_id = $upg_val;
                } 
                // B. BASE SPEC
                else {
                    $cat_key = strtolower( $cat );
                    $cpt_part_id = $product->get_meta( '_savvy_component_' . $cat_key );
                    if ( $cpt_part_id ) {
                         $final_sql_id = $cpt_part_id;
                    }
                }
                
                // INSERT
                if($final_sql_id) {
                    Savvy_DB::add_order_component($current_build_id, $cat, (int)$final_sql_id);
                }
            }
        }
    }
}

/**
 * 6. DELETE Sync: Remove from Savvy Ops when WC Order is deleted
 */
add_action('wp_trash_post', 'savvy_ops_handle_order_delete'); // For moved to trash
add_action('before_delete_post', 'savvy_ops_handle_order_delete'); // For permanent delete

function savvy_ops_handle_order_delete($post_id) {
    if(get_post_type($post_id) !== 'shop_order') return;

    global $wpdb;
    $t_orders = $wpdb->prefix . 'savvy_orders';
    $t_comps = $wpdb->prefix . 'savvy_order_components';
    
    // Find Savvy Builds linked to this Order
    $builds = $wpdb->get_results($wpdb->prepare("SELECT id FROM $t_orders WHERE wc_order_id = %d", $post_id));
    
    if($builds) {
        foreach($builds as $b) {
            Savvy_DB::delete_savvy_order($b->id);
        }
    }
}
