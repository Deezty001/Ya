jQuery(document).ready(function ($) {

    // --- 1. Filter Logic (Inventory Page) ---
    $('.filter-btn').on('click', function () {
        $('.filter-btn').removeClass('active');
        $(this).addClass('active');
        const cat = $(this).data('cat');

        if (cat === 'all') {
            $('.inventory-item').show();
        } else {
            $('.inventory-item').hide();
            $('.inventory-item[data-category="' + cat + '"]').show();
        }
    });

    // --- 2. Accordion Logic (Inventory Page) ---
    $(document).on('click', '.item-header', function () {
        const parent = $(this).closest('.inventory-item');
        const details = parent.find('.item-details');
        const arrow = $(this).find('.item-arrow .dashicons'); // Fix: Only target the right arrow

        if (details.is(':visible')) {
            details.slideUp(200); // Fix: Smooth slide up
            arrow.removeClass('dashicons-arrow-up-alt2').addClass('dashicons-arrow-down-alt2');
        } else {
            details.slideDown(200); // Fix: Smooth slide down
            arrow.removeClass('dashicons-arrow-down-alt2').addClass('dashicons-arrow-up-alt2');
        }
    });

    // --- 3. Modal Open/Close Logic ---

    // Inventory: Receive Stock
    $('#btn-add-inventory').on('click', function (e) {
        e.preventDefault();
        $('#modal-add-inventory').css('display', 'flex');
    });

    // Catalogue: Create New Part (Settings Page)
    $('#btn-create-part').on('click', function (e) {
        e.preventDefault();
        $('#modal-create-part').css('display', 'flex');
    });

    // Close via Button (X or Cancel)
    $(document).on('click', '.modal-close, .btn-cancel', function () {
        $('.savvy-modal-overlay').hide();
    });

    // Close via Click Outside (Overlay)
    $('.savvy-modal-overlay').on('click', function (e) {
        if ($(e.target).is('.savvy-modal-overlay')) {
            $(this).hide();
        }
    });

    // Close via Escape Key
    $(document).on('keydown', function (e) {
        if (e.key === "Escape") {
            $('.savvy-modal-overlay').hide();
        }
    });

    // --- 4. Technical Specs Logic (Catalogue Page) ---
    const specsMap = {
        'CPU': ['cpu_socket', 'cpu_platform'],
        'Motherboard': ['mb_socket', 'mb_chipset', 'mb_form_factor', 'mb_ram_type'],
        'RAM': ['ram_ddr_type', 'ram_capacity', 'ram_speed', 'ram_cas'],
        'GPU': ['gpu_platform', 'gpu_series', 'gpu_length'],
        'PSU': ['psu_wattage', 'psu_rating', 'psu_modularity'],
        'Case': ['case_size', 'case_mb_support', 'case_gpu_max', 'case_cpu_max'],
        'Cooler': ['cooler_type', 'cooler_radiator', 'cooler_height'],
        'Storage': ['storage_type', 'storage_form', 'storage_cap', 'storage_iface']
    };

    $('#new-part-category').on('change', function () {
        const cat = $(this).val();

        // Hide all fields first
        $('.spec-group').hide();

        if (specsMap[cat]) {
            // Show fields for this category
            specsMap[cat].forEach(field => {
                $('.field-' + field).show();
            });
            $('#tech-specs-section').show();
        } else {
            $('#tech-specs-section').hide();
        }

        // Trigger sub-logic if needed
        if (cat === 'Cooler') $('#cooler_type').trigger('change');
    });

    $('#cooler_type').on('change', function () {
        const type = $(this).val();
        if (type === 'AIO') $('.field-cooler_radiator').show();
        if (type === 'Air') $('.field-cooler_height').show();
    });

    // --- 5. AJAX Form Submission ---

    // A. Add Inventory (Stock)
    $('#form-add-inventory').on('submit', function (e) {
        e.preventDefault();
        submitForm($(this), 'savvy_add_inventory', 'Inventory Added!');
    });

    // B. Create Part (Catalogue)
    $('#form-create-part').on('submit', function (e) {
        e.preventDefault();
        submitForm($(this), 'savvy_create_part', 'Part Created!');
    });

    function submitForm(form, action, successMsg) {
        const btn = form.find('.btn-save');
        const originalText = btn.text();

        btn.prop('disabled', true).text('Saving...');

        const formData = form.serialize();

        $.post(savvy_vars.ajax_url, {
            action: action,
            nonce: savvy_vars.nonce,
            data: formData
        }, function (response) {
            if (response.success) {
                alert(successMsg);
                location.reload();
            } else {
                alert('Error: ' + (response.data || 'Unknown error'));
                btn.prop('disabled', false).text(originalText);
            }
        }).fail(function () {
            alert('Server Error');
            btn.prop('disabled', false).text(originalText);
        });
    }

    // --- 6. Unit Detail Modal (Global AJAX + Tabs) ---

    // A. Tab Switching
    $(document).on('click', '.savvy-tab', function () {
        var target = $(this).data('tab');

        // Update Tabs
        $('.savvy-tab').removeClass('active').css({ 'color': '#999', 'border-color': 'transparent' });
        $(this).addClass('active').css({ 'color': '#333', 'border-color': '#00b9eb' });

        // Update Content
        $('.tab-content').hide();
        $('#' + target).show();
    });

    // B. Open Modal
    $(document).on('click', '.view-unit-details', function (e) {
        e.preventDefault();
        e.stopPropagation();

        var uid = $(this).data('uid');
        console.log("View Unit Details:", uid);

        if (!uid) return;

        $('#modal-unit-details').css('display', 'flex').hide().fadeIn(100);

        // Reset Tabs
        $('.savvy-tab').removeClass('active').css({ 'color': '#999', 'border-color': 'transparent' });
        $('.savvy-tab[data-tab="tab-details"]').addClass('active').css({ 'color': '#333', 'border-color': '#00b9eb' });
        $('.tab-content').hide();
        $('#tab-details').show();

        // Reset Data / Loading State
        $('#view-title').text('Loading...');
        $('#view-cost').text('...');
        $('#view-serial').text('SN: ...');
        $('#view-history').html('<div style="color:#ccc; padding:20px; text-align:center;">Loading audit logs...</div>');
        $('#view-status-badge').hide();

        // AJAX Fetch
        $.post(savvy_vars.ajax_url, {
            action: 'savvy_get_unit_details',
            nonce: savvy_vars.nonce,
            unit_id: uid
        }, function (res) {
            if (res.success) {
                var d = res.data;
                $('#view-title').text(d.title);
                $('#view-serial').text('SN: ' + d.serial);
                $('#view-cost').text('$' + d.cost);
                $('#view-date').text(d.date);
                $('#view-upc').text(d.upc);
                $('#view-condition').text(d.condition);

                // Show Allocated Badge if Status is Allocated (or implied)
                // Note: Frontend mostly uses 'condition' for New vs Used, but we can assume 'Allocated' logic?
                // Actually, savvy_get_unit_details doesn't return 'status' explicitly yet, but let's leave badge hidden for now 
                // unless we add status to the response. 
                // Update: Logic in production-ui.php had separate badge. Global modal has #view-status-badge.

                // Render History in Audit Tab
                var hist = '';
                if (d.history && d.history.length > 0) {
                    hist += '<div style="display:flex; flex-direction:column; gap:10px;">';
                    d.history.forEach(function (h) {
                        hist += '<div style="background:#f9f9f9; padding:10px; border-radius:6px; border:1px solid #eee;">' +
                            '<div style="font-weight:600; font-size:12px; color:#333; margin-bottom:2px;">' + h.msg + '</div>' +
                            '<div style="font-size:10px; color:#999; display:flex; justify-content:space-between;">' +
                            '<span>' + h.user + '</span>' +
                            '<span>' + h.date + '</span>' +
                            '</div>' +
                            '</div>';
                    });
                    hist += '</div>';
                } else {
                    hist = '<div style="text-align:center; padding:30px; color:#ccc;">No history recorded.</div>';
                }
                $('#view-history').html(hist);
            } else {
                $('#view-title').text('Error loading details');
            }
        });
    });

    // C. Close Modal (Specific)
    $('.unit-modal-close').on('click', function () {
        $('#modal-unit-details').fadeOut(100);
    });

    // Close on overlay click (handled by generic listener above, but ensure #modal-unit-details ID is covered)
    // The generic listener covers .savvy-modal-overlay, which this ID has.

});
