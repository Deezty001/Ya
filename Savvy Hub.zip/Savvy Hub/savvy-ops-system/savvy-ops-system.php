<?php
/**
 * Plugin Name: Savvy Operations System
 * Plugin URI:  https://savvycomputers.com.au
 * Description: Complete Operations System for Savvy Computers (Dashboard, Production, Inventory, Support, Client).
 * Version:     1.0.0
 * Author:      Savvy Dev
 * Text Domain: savvy-ops
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SAVVY_OPS_VERSION', '1.0.0' );
define( 'SAVVY_OPS_PATH', plugin_dir_path( __FILE__ ) );
define( 'SAVVY_OPS_URL', plugin_dir_url( __FILE__ ) );

// Include Core Components
require_once plugin_dir_path( __FILE__ ) . 'includes/cpt-loader.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/dashboard.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/field-manager.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/woocommerce-sync.php'; // WooCommerce Integration
require_once SAVVY_OPS_PATH . 'includes/hubs/production.php';
require_once SAVVY_OPS_PATH . 'includes/hubs/inventory.php';
require_once SAVVY_OPS_PATH . 'includes/db-init.php';
require_once SAVVY_OPS_PATH . 'includes/migration.php';

// Activation/Deactivation hooks
register_activation_hook( __FILE__, 'savvy_ops_activate' );

function savvy_ops_activate() {
    // Create Custom Tables
    savvy_ops_create_tables();
    
    // Flush rewrite rules for CPTs
    savvy_ops_register_cpts();
    flush_rewrite_rules();
}

function savvy_ops_system_init() {
    // Enqueue Admin Styles & Scripts
    add_action( 'admin_enqueue_scripts', function( $hook ) {
        // Only load on Savvy Pages (check for 'savvy' in the hook name)
        // If debugging, comment out this check to load everywhere.
        // if ( strpos( $hook, 'savvy' ) === false ) {
        //      return;
        // }

        wp_enqueue_style( 'savvy-ops-admin-css', plugin_dir_url( __FILE__ ) . 'assets/admin-style.css' ); 
        wp_enqueue_style( 'savvy-inventory-css', plugin_dir_url( __FILE__ ) . 'assets/savvy-inventory.css', array(), time() ); // Time for cache busting
        
        wp_enqueue_script( 'savvy-inventory-js', plugin_dir_url( __FILE__ ) . 'assets/savvy-inventory.js', array('jquery'), time(), true );
        
        wp_localize_script( 'savvy-inventory-js', 'savvy_vars', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'savvy_inventory_nonce' )
        ));
    });

    // Handle AJAX: Add Inventory (Stock)
    add_action( 'wp_ajax_savvy_add_inventory', 'savvy_ajax_add_inventory' );
    
    // Handle AJAX: Create Part (Catalogue)
    add_action( 'wp_ajax_savvy_create_part', 'savvy_ajax_create_part' );
}
add_action( 'plugins_loaded', 'savvy_ops_system_init' );

// 1. Add Stock Unit (SQL)
function savvy_ajax_add_inventory() {
    check_ajax_referer( 'savvy_inventory_nonce', 'nonce' );
    parse_str( $_POST['data'], $form_data );
    global $wpdb;
    
    $cat_id = absint($form_data['existing_part_id']);
    
    if( $cat_id && !empty($form_data['savvy_serial']) ) {
        $wpdb->insert($wpdb->prefix . 'savvy_units', [
            'catalogue_id' => $cat_id,
            'serial' => $form_data['savvy_serial'],
            'cost' => $form_data['savvy_cost'],
            'date_received' => $form_data['savvy_date_received'],
            'status' => 'In_Stock'
        ]);
        
        // Update Stock Count
        $count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}savvy_units WHERE catalogue_id = %d AND status = 'In_Stock'", $cat_id));
        $wpdb->update($wpdb->prefix . 'savvy_catalogue', ['stock_count' => $count], ['id' => $cat_id]);
        
        wp_send_json_success();
    } else {
        wp_send_json_error('Missing Part ID or Serial Number');
    }
}

// 2. Create Catalogue Part (SQL)
function savvy_ajax_create_part() {
    check_ajax_referer( 'savvy_inventory_nonce', 'nonce' );
    parse_str( $_POST['data'], $form_data );
    global $wpdb;

    $specs = [
        'cpu_socket' => $form_data['cpu_socket'] ?? '',
        'ram_type' => $form_data['ram_ddr_type'] ?? '',
        // Can add more fields here as needed
    ];
    
    $res = $wpdb->insert($wpdb->prefix . 'savvy_catalogue', [
        'title' => $form_data['savvy_brand'] . ' ' . $form_data['savvy_model'],
        'brand' => $form_data['savvy_brand'],
        'model' => $form_data['savvy_model'],
        'sku' => $form_data['savvy_part_id'],
        'category' => $form_data['savvy_category'],
        'upc' => $form_data['savvy_upc'] ?? '',
        'ean' => $form_data['savvy_ean'] ?? '',
        'specs' => json_encode($specs),
        'stock_count' => 0
    ]);
    
    if( $res ) {
        wp_send_json_success();
    } else {
        wp_send_json_error( $wpdb->last_error );
    }
}

// 6. Global Footer (Modals)
add_action('admin_footer', 'savvy_ops_global_modals');
function savvy_ops_global_modals() {
    // Only load on Savvy Pages
    if ( isset( $_GET['page'] ) && strpos( $_GET['page'], 'savvy' ) !== false ) {
        include_once plugin_dir_path( __FILE__ ) . 'includes/partials/modal-unit-details.php';
    }
}
