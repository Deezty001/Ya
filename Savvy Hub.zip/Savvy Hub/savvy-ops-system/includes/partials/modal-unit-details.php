<?php
/**
 * Shared Unit Details Modal (Tabbed)
 * Used in: Production Hub, Inventory Hub
 */
?>
<!-- UNIT DETAILS MODAL (Clean White Card) -->
<div id="modal-unit-details" class="savvy-modal-overlay" style="z-index:10000; background:rgba(0,0,0,0.6); display:none;">
    <div class="savvy-modal" style="background:#fff; color:#333; max-width:450px; text-align:center; padding:0; border-radius:12px; box-shadow:0 20px 40px rgba(0,0,0,0.4);">
        <span class="dashicons dashicons-no-alt unit-modal-close" style="position:absolute; top:15px; right:15px; cursor:pointer; color:#999; z-index:10;"></span>
        
        <div class="modal-body" style="padding:0; display:flex; flex-direction:column; height:500px;">
            
            <!-- HEADER (Fixed) -->
            <div style="padding:30px 30px 10px 30px;">
                <!-- Badge -->
                <div style="margin-bottom:10px;">
                    <span id="view-status-badge" class="badge" style="background:#f6ffed; color:#389e0d; border:1px solid #b7eb8f; margin-right:5px; padding:4px 8px; border-radius:4px; font-size:11px; font-weight:bold; display:none;">ALLOCATED</span>
                    <span id="view-condition" class="badge" style="background:#e6f7ff; color:#096dd9; border:1px solid #91d5ff; padding:4px 8px; border-radius:4px; font-size:11px; font-weight:bold;">New</span>
                </div>
                <!-- Title -->
                <h3 id="view-title" style="margin:0 0 5px 0; font-size:18px; color:#333;">Loading...</h3>
                <p id="view-serial" style="margin:0; color:#666; font-family:monospace; font-size:14px;">SN: -</p>
            </div>

            <!-- TABS -->
            <div style="display:flex; border-bottom:1px solid #eee; padding:0 20px;">
                <div class="savvy-tab active" data-tab="tab-details" style="padding:10px 15px; cursor:pointer; font-size:12px; font-weight:600; color:#333; border-bottom:2px solid #00b9eb;">Details</div>
                <div class="savvy-tab" data-tab="tab-rma" style="padding:10px 15px; cursor:pointer; font-size:12px; font-weight:600; color:#999; border-bottom:2px solid transparent;">RMA History</div>
                <div class="savvy-tab" data-tab="tab-audit" style="padding:10px 15px; cursor:pointer; font-size:12px; font-weight:600; color:#999; border-bottom:2px solid transparent;">Audit Log</div>
            </div>

            <!-- CONTENT AREA (Scrollable) -->
            <div style="flex:1; overflow-y:auto; padding:30px; text-align:left;">
                
                <!-- TAB 1: DETAILS -->
                <div id="tab-details" class="tab-content">
                    <div style="background:#fafafa; border-radius:8px; padding:20px; margin-bottom:20px; text-align:center;">
                        <span style="display:block; font-size:10px; text-transform:uppercase; color:#999; letter-spacing:1px; font-weight:600;">Unit Cost</span>
                        <span id="view-cost" style="font-size:32px; font-weight:800; color:#333;">$0.00</span>
                    </div>

                    <div style="font-size:13px; color:#555;">
                        <div style="padding:10px 0; border-bottom:1px solid #eee; display:flex; justify-content:space-between;">
                            <span>Date Added</span>
                            <strong id="view-date">-</strong>
                        </div>
                        <div style="padding:10px 0; border-bottom:1px solid #eee; display:flex; justify-content:space-between;">
                            <span>UPC</span>
                            <strong id="view-upc">-</strong>
                        </div>
                    </div>
                </div>

                <!-- TAB 2: RMA HISTORY -->
                <div id="tab-rma" class="tab-content" style="display:none;">
                    <div style="text-align:center; padding:40px 0; color:#999;">
                        <span class="dashicons dashicons-warning" style="font-size:32px; height:32px; width:32px; margin-bottom:10px;"></span>
                        <p>No RMA records found for this unit.</p>
                        <button class="button button-small" style="margin-top:10px;">Create RMA Case</button>
                    </div>
                </div>

                <!-- TAB 3: AUDIT LOG -->
                <div id="tab-audit" class="tab-content" style="display:none;">
                    <div id="view-history" style="font-size:12px; color:#666;">
                        Loading audit log...
                    </div>
                </div>

            </div>
            
            <!-- FOOTER -->
            <div style="padding:20px; border-top:1px solid #eee; background:#fcfcfc; border-radius:0 0 12px 12px;">
                <button class="button button-disabled" style="width:100%;">Edit Unit (Coming Soon)</button>
            </div>

        </div>
    </div>
</div>
