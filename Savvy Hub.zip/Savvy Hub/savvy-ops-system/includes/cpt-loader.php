<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function savvy_ops_register_cpts() {
    
    // 1. Projects (Production Hub)
    register_post_type( 'savvy_project', array(
        'labels' => array(
            'name'          => 'Projects',
            'singular_name' => 'Project',
            'menu_name'     => 'Production',
            'add_new'       => 'New Project',
        ),
        'public'      => true,
        'has_archive' => true,
        'show_ui'     => true,
        'show_in_menu'=> false, // HIDDEN: We add manually in dashboard.php
        'menu_icon'   => 'dashicons-hammer',
        'supports'    => array( 'title', 'editor', 'custom-fields', 'comments' ),
        'show_in_rest' => true,
    ));

    // 2. Parts Catalogue (Inventory Hub - Standard Parts)
    register_post_type( 'savvy_part', array(
        'labels' => array(
            'name'          => 'Parts Catalogue',
            'singular_name' => 'Part',
            'menu_name'     => 'Inventory',
            'add_new'       => 'Add Standard Part',
        ),
        'public'      => true,
        'has_archive' => true,
        'show_ui'     => true,
        'show_in_menu'=> false, // HIDDEN
        'menu_icon'   => 'dashicons-products',
        'supports'    => array( 'title', 'thumbnail' ), 
        'show_in_rest' => true,
    ));

    // 3. Individual Units (Inventory Hub - Stock)
    register_post_type( 'savvy_unit', array(
        'labels' => array(
            'name'          => 'Stock Units',
            'singular_name' => 'Unit',
            'menu_name'     => 'Stock Units', 
        ),
        'public'      => true,
        'show_ui'     => true,
        'show_in_menu'=> false, // HIDDEN
        'supports'    => array( 'title', 'custom-fields' ),
        'show_in_rest' => true,
    ));

    // 4. Tickets (Support Hub)
    register_post_type( 'savvy_ticket', array(
        'labels' => array(
            'name'          => 'Tickets',
            'singular_name' => 'Ticket',
            'menu_name'     => 'Support',
        ),
        'public'      => true,
        'has_archive' => true,
        'show_ui'     => true,
        'show_in_menu'=> false, // HIDDEN
        'menu_icon'   => 'dashicons-sos',
        'supports'    => array( 'title', 'editor', 'custom-fields', 'comments' ),
        'show_in_rest' => true,
    ));

     // 5. Clients (Client Hub)
    register_post_type( 'savvy_client', array(
        'labels' => array(
            'name'          => 'Clients',
            'singular_name' => 'Client',
            'menu_name'     => 'Clients',
        ),
        'public'      => true,
        'has_archive' => true,
        'show_ui'     => true,
        'show_in_menu'=> false, // HIDDEN
        'menu_icon'   => 'dashicons-businessperson',
        'supports'    => array( 'title', 'editor', 'thumbnail', 'custom-fields' ),
        'show_in_rest' => true,
    ));
}
add_action( 'init', 'savvy_ops_register_cpts' );
