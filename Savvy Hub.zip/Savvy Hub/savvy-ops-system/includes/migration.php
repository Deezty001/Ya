<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// Register Migration Page
add_action('admin_menu', function() {
    add_submenu_page(
        'savvy-ops',
        'Database Migration',
        'DB Migration',
        'manage_options',
        'savvy-migration',
        'savvy_ops_migration_page'
    );
});

function savvy_ops_migration_page() {
    global $wpdb;
    
    // Fix Tables Trigger
    if(isset($_POST['fix_tables']) && check_admin_referer('savvy_migration_action')) {
         if(function_exists('savvy_ops_create_tables')) {
             savvy_ops_create_tables();
             echo '<div class="notice notice-info"><p>Database Tables Repaired/Created.</p></div>';
         } else {
             echo '<div class="notice notice-error"><p>Error: Create function not found.</p></div>';
         }
    }

    // Reset Data Trigger
    if(isset($_POST['reset_data']) && check_admin_referer('savvy_migration_action')) {
        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}savvy_orders");
        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}savvy_order_components");
        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}savvy_units");
        // Reset stock counts only
        $wpdb->query("UPDATE {$wpdb->prefix}savvy_catalogue SET stock_count = 0");
        
        echo '<div class="notice notice-warning"><p>Orders and Stock cleared. Catalogue definitions preserved.</p></div>';
    }
    
    // Check for Run Trigger
    if(isset($_POST['run_migration']) && check_admin_referer('savvy_migration_action')) {
        $stats = savvy_ops_run_migration();
        echo '<div class="notice notice-success"><p>Migration Completed Successfully!</p>' .
             '<ul>' .
             '<li>Orders Imported: ' . $stats['orders'] . '</li>' .
             '<li>Parts Imported: ' . $stats['parts'] . '</li>' .
             '<li>Units: Found ' . $stats['units_found'] . ', Imported ' . $stats['units'] . '</li>' .
             '</ul></div>';
    }

    echo '<div class="wrap"><h1>System Database Migration</h1>';
    echo '<p>This tool will migrate data from WordPress Posts to the new High-Performance SQL Tables.</p>';
    echo '<form method="post">';
    wp_nonce_field('savvy_migration_action');
    echo '<input type="hidden" name="run_migration" value="1">';
    echo '<button class="button button-primary button-hero">Start Migration</button>';
    echo '<br><br>';
    echo '<button class="button button-secondary" name="fix_tables" value="1">Force Fix Tables</button>';
    echo '<button class="button button-link-delete" name="reset_data" value="1" onclick="return confirm(\'Warning: This will delete all Orders and Stock Units. Catalogue items (Titles) will be kept. Continue?\');" style="margin-left:20px; color:red;">Reset Orders & Stock</button>';
    echo '</form></div>';
}

function savvy_ops_run_migration() {
    global $wpdb;
    
    // ID Mappings [Old_ID => New_ID]
    $part_map = [];
    $unit_map = [];
    $order_map = [];

    // 1. MIGRATE PARTS (savvy_part -> savvy_catalogue)
    $parts = get_posts(['post_type'=>'savvy_part', 'numberposts'=>-1]);
    foreach($parts as $p) {
        $meta = get_post_meta($p->ID);
        
        // Encode specs
        $specs = [
            'cpu_socket' => $meta['cpu_socket'][0] ?? '',
            'ram_type' => $meta['ram_ddr_type'][0] ?? '',
            // ... Add others as needed, simplified for now
        ];

        $wpdb->insert($wpdb->prefix.'savvy_catalogue', [
            'title' => $p->post_title,
            'brand' => $meta['savvy_brand'][0] ?? '',
            'model' => $meta['savvy_model'][0] ?? '',
            'sku'   => $meta['savvy_part_id'][0] ?? '',
            'category' => $meta['savvy_category'][0] ?? '',
            'upc'   => $meta['savvy_upc'][0] ?? '',
            'ean'   => $meta['savvy_ean'][0] ?? '',
            'specs' => json_encode($specs),
            'stock_count' => (int)($meta['stock_on_hand'][0] ?? 0)
        ]);
        $part_map[$p->ID] = $wpdb->insert_id;
    }

    // 2. MIGRATE ORDERS (savvy_project -> savvy_orders)
    $orders = get_posts(['post_type'=>'savvy_project', 'numberposts'=>-1]);
    foreach($orders as $o) {
        $meta = get_post_meta($o->ID);
        
        $wpdb->insert($wpdb->prefix.'savvy_orders', [
            'wc_order_id' => $meta['_wc_order_id'][0] ?? 0,
            'wc_build_index' => $meta['_wc_build_index'][0] ?? 0,
            'client_name' => 'Unknown Client', // Meta doesn't have it yet?
            'title' => $o->post_title,
            'status' => $meta['savvy_status'][0] ?? 'Pending',
            'priority' => $meta['savvy_priority'][0] ?? 'Normal',
            'date_created' => $o->post_date
        ]);
        $order_map[$o->ID] = $wpdb->insert_id;
    }

    // 3. MIGRATE UNITS (savvy_unit -> savvy_units)
    $units = get_posts(['post_type'=>'savvy_unit', 'numberposts'=>-1]);
    foreach($units as $u) {
        $meta = get_post_meta($u->ID);
        $old_parent = $meta['savvy_unit_parent'][0] ?? 0;
        $new_cat_id = $part_map[$old_parent] ?? 0;

        if($new_cat_id) {
            $wpdb->insert($wpdb->prefix.'savvy_units', [
                'catalogue_id' => $new_cat_id,
                'serial' => $meta['savvy_serial'][0] ?? '',
                'cost' => $meta['savvy_cost'][0] ?? 0,
                'date_received' => $meta['savvy_date_received'][0] ?? current_time('mysql'),
                'item_condition' => $meta['savvy_condition'][0] ?? 'New',
                'status' => 'In_Stock' // Default, will update in next step
            ]);
            $unit_map[$u->ID] = $wpdb->insert_id;
        }
    }

    // 4. MIGRATE MANIFEST & UNIT ALLOCATIONS (savvy_order_components)
    // We loop through the OLD orders again to check their meta components
    foreach($orders as $o) {
        $new_order_id = $order_map[$o->ID];
        $meta = get_post_meta($o->ID);
        $categories = ['CPU', 'Cooler', 'Motherboard', 'RAM', 'SSD', 'GPU', 'PSU', 'Case'];
        
        foreach($categories as $cat) {
            $cat_key = strtolower($cat);
            $part_id = $meta['savvy_component_' . $cat_key][0] ?? '';
            $alloc_unit_id = $meta['_allocated_unit_' . $cat_key][0] ?? '';

            if($part_id && isset($part_map[$part_id])) {
                $new_part_id = $part_map[$part_id];
                $new_unit_id = ($alloc_unit_id && isset($unit_map[$alloc_unit_id])) ? $unit_map[$alloc_unit_id] : NULL;

                $wpdb->insert($wpdb->prefix.'savvy_order_components', [
                    'order_id' => $new_order_id,
                    'category' => $cat,
                    'required_catalogue_id' => $new_part_id,
                    'allocated_unit_id' => $new_unit_id
                ]);

                // Update Unit Status if allocated
                if($new_unit_id) {
                    $wpdb->update($wpdb->prefix.'savvy_units', 
                        ['status' => 'Allocated', 'order_id' => $new_order_id], 
                        ['id' => $new_unit_id]
                    );
                }
            }
        }
    }

    return [
        'parts' => count($part_map),
        'orders' => count($order_map),
        'units' => count($unit_map),
        'units_found' => count($units)
    ];
}
