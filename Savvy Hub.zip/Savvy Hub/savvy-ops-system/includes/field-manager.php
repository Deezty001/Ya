<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Savvy_Field_Manager {

    public function __construct() {
        add_action( 'add_meta_boxes', array( $this, 'add_part_meta_boxes' ) );
        add_action( 'save_post', array( $this, 'save_part_meta' ) );
        add_action( 'admin_footer', array( $this, 'print_conditional_script' ) );
    }

    public function add_part_meta_boxes() {
        add_meta_box(
            'savvy_part_identity',
            'Part Identity',
            array( $this, 'render_identity_box' ),
            'savvy_part',
            'normal',
            'high'
        );

        add_meta_box(
            'savvy_part_specs',
            'Tech Specs',
            array( $this, 'render_specs_box' ),
            'savvy_part',
            'normal',
            'high'
        );
        
        add_meta_box(
            'savvy_part_inventory_data',
            'Inventory Settings',
            array( $this, 'render_inventory_box' ),
            'savvy_part',
            'side',
            'default'
        );

        add_meta_box(
            'savvy_part',
            'normal',
            'low'
        );

        // PRODUCTION: Project Details
        add_meta_box(
            'savvy_project_details',
            'Project Settings',
            array( $this, 'render_project_box' ),
            'savvy_project',
            'side',
            'high'
        );

        add_meta_box(
            'savvy_project_specs',
            'Build Specifications',
            array( $this, 'render_project_specs' ),
            'savvy_project',
            'normal',
            'high'
        );
    }

    public function render_identity_box( $post ) {
        $meta = get_post_meta( $post->ID );
        ?>
        <div class="savvy-field-group">
            <p>
                <label><strong>Category</strong></label><br>
                <select name="savvy_category" id="savvy_category_select" style="width:100%;">
                    <option value="">-- Select Category --</option>
                    <?php 
                    $cats = ['CPU', 'Cooler', 'Motherboard', 'RAM', 'SSD', 'GPU', 'PSU', 'Case'];
                    $current = $meta['savvy_category'][0] ?? '';
                    foreach($cats as $c) {
                        echo '<option value="'.$c.'" '.selected($current, $c, false).'>'.$c.'</option>';
                    }
                    ?>
                </select>
            </p>
            <p>
                <label>Brand</label>
                <input type="text" name="savvy_brand" value="<?php echo esc_attr( $meta['savvy_brand'][0] ?? '' ); ?>" class="widefat">
            </p>
            <p>
                <label>Model</label>
                <input type="text" name="savvy_model" value="<?php echo esc_attr( $meta['savvy_model'][0] ?? '' ); ?>" class="widefat">
            </p>
            <p>
                <label>Part ID (Internal)</label>
                <input type="text" name="savvy_part_id" value="<?php echo esc_attr( $meta['savvy_part_id'][0] ?? '' ); ?>" class="widefat">
            </p>
        </div>
        <?php
    }

    public function render_inventory_box( $post ) {
         $meta = get_post_meta( $post->ID );
         
         // 1. Calculate Stock Counts
         // Stock On Hand = Count of published 'savvy_unit' children
         $units_on_hand = new WP_Query([
            'post_type' => 'savvy_unit',
            'meta_key' => 'savvy_unit_parent',
            'meta_value' => $post->ID,
            'post_status' => 'publish',
            'fields' => 'ids'
         ]);
         $on_hand_count = $units_on_hand->found_posts;
         update_post_meta($post->ID, 'stock_on_hand', $on_hand_count); // Cache it

         // Stock Allocated = Manual field (for now) or sum of units linked to active Projects
         $allocated = (int) ($meta['stock_allocated'][0] ?? 0);
         
         // Stock Available = Hand - Allocated
         $available = $on_hand_count - $allocated;

         ?>
         <p>
            <label>Status</label>
            <select name="savvy_status" class="widefat">
                <?php
                $statuses = ['Active', 'Discontinued', 'Backorder', 'Coming Soon'];
                $cur = $meta['savvy_status'][0] ?? 'Active';
                foreach($statuses as $s) {
                    echo '<option value="'.$s.'" '.selected($cur, $s, false).'>'.$s.'</option>';
                }
                ?>
            </select>
         </p>
         
         <hr>
         
         <div style="background:#f0f0f1; padding:10px; border-radius:5px;">
             <p style="margin:0 0 5px 0;"><strong>Stock on Hand:</strong> <span style="float:right; font-size:1.2em;"><?php echo $on_hand_count; ?></span></p>
             <p style="margin:0 0 5px 0;">
                 <label>Allocated:</label> 
                 <input type="number" name="stock_allocated" value="<?php echo $allocated; ?>" style="width:60px; float:right; text-align:right;">
             </p>
             <hr style="margin:5px 0;">
             <p style="margin:0; font-weight:bold; color: <?php echo ($available > 0) ? 'green' : 'red'; ?>;">
                 Available: <span style="float:right; font-size:1.2em;"><?php echo $available; ?></span>
             </p>
         </div>

         <hr>
         <p>
            <label>Reorder Qty</label>
            <input type="number" name="savvy_reorder_qty" value="<?php echo esc_attr( $meta['savvy_reorder_qty'][0] ?? '' ); ?>" class="widefat">
         </p>
         <?php
    }

    public function render_linked_units_box( $post ) {
        // Show table of individual units
        $units = get_posts([
            'post_type' => 'savvy_unit',
            'meta_key' => 'savvy_unit_parent',
            'meta_value' => $post->ID,
            'numberposts' => -1
        ]);
        
        echo '<table class="widefat striped">';
        echo '<thead><tr><th>Serial #</th><th>Date In</th><th>Cost</th><th>Action</th></tr></thead>';
        echo '<tbody>';
        
        if($units) {
            foreach($units as $u) {
                $serial = get_post_meta($u->ID, 'savvy_serial', true);
                $date = get_post_meta($u->ID, 'savvy_date_received', true);
                $cost = get_post_meta($u->ID, 'savvy_cost', true);
                $edit_link = get_edit_post_link($u->ID);
                
                echo '<tr>';
                echo '<td><a href="'.$edit_link.'"><strong>'.($serial ?: '(No Serial)').'</strong></a></td>';
                echo '<td>'.($date ?: '-').'</td>';
                echo '<td>$'.($cost ?: '0.00').'</td>';
                echo '<td><a href="'.$edit_link.'" class="button button-small">Edit</a></td>';
                echo '</tr>';
            }
        } else {
            echo '<tr><td colspan="4">No units in stock.</td></tr>';
        }
        
        echo '</tbody></table>';
        echo '<p><a href="'.admin_url('post-new.php?post_type=savvy_unit').'" class="button button-primary">+ Add New Unit</a></p>';
    }

    public function render_specs_box( $post ) {
        $meta = get_post_meta( $post->ID );
        
        // Helper to output fields
        $text = function($id, $label) use ($meta) {
            $val = $meta[$id][0] ?? '';
            echo '<div class="savvy-spec-field" data-id="'.$id.'"><label>'.$label.'</label><br><input type="text" name="'.$id.'" value="'.esc_attr($val).'" class="widefat"></div>';
        };
        $select = function($id, $label, $opts) use ($meta) {
            $val = $meta[$id][0] ?? '';
            echo '<div class="savvy-spec-field" data-id="'.$id.'"><label>'.$label.'</label><br><select name="'.$id.'" class="widefat"><option value="">-</option>';
            foreach($opts as $o) echo '<option value="'.$o.'" '.selected($val, $o, false).'>'.$o.'</option>';
            echo '</select></div>';
        };
        
        echo '<div id="savvy-specs-container">';

        // CPU fields
        echo '<div class="spec-group" data-cat="CPU">';
        $select('cpu_socket', 'Socket', ['AM5', 'AM4', 'LGA1700', 'LGA1200']);
        $select('cpu_platform', 'Platform', ['AMD', 'Intel']);
        echo '</div>';

        // Cooler fields
        echo '<div class="spec-group" data-cat="Cooler" style="display:none;">';
        $select('cooler_type', 'Cooler Type', ['Air', 'AIO']);
        $select('cooler_radiator', 'Radiator Size (AIO)', ['120', '240', '280', '360']);
        $text('cooler_height', 'Air Cooler Height (mm)');
        echo '</div>';

        // Motherboard fields
        echo '<div class="spec-group" data-cat="Motherboard" style="display:none;">';
        $select('mb_socket', 'Socket', ['AM5', 'AM4', 'LGA1700']);
        $text('mb_chipset', 'Chipset');
        $select('mb_form_factor', 'Form Factor', ['ATX', 'mATX', 'ITX']);
        $select('mb_ram_type', 'RAM Type', ['DDR4', 'DDR5']);
        echo '</div>';
        
        // RAM fields
        echo '<div class="spec-group" data-cat="RAM" style="display:none;">';
        $select('ram_type', 'DDR Type', ['DDR4', 'DDR5']);
        $text('ram_capacity', 'Capacity (GB)');
        $text('ram_speed', 'Speed (MT/s)');
        $text('ram_latency', 'CAS Latency');
        echo '</div>';

        // Storage fields
        echo '<div class="spec-group" data-cat="SSD" style="display:none;">';
        $select('storage_type', 'Type', ['NVMe', 'SATA']);
        $select('storage_form', 'Form Factor', ['M.2 2280', '2.5"']);
        $text('storage_capacity', 'Capacity');
        $text('storage_interface', 'Interface');
        echo '</div>';

        // GPU fields
        echo '<div class="spec-group" data-cat="GPU" style="display:none;">';
        $select('gpu_platform', 'Platform', ['NVIDIA', 'AMD']);
        $text('gpu_series', 'Series');
        $text('gpu_length', 'Length (mm)');
        echo '</div>';

        // PSU fields
        echo '<div class="spec-group" data-cat="PSU" style="display:none;">';
        $text('psu_wattage', 'Wattage');
        $select('psu_eff', 'Efficiency', ['Bronze', 'Gold', 'Platinum', 'Titanium']);
        $select('psu_mod', 'Modularity', ['Full', 'Semi', 'Non']);
        echo '</div>';

        // Case fields
        echo '<div class="spec-group" data-cat="Case" style="display:none;">';
        $select('case_size', 'Case Size', ['ATX', 'mATX', 'ITX']);
        $select('case_mb_support', 'Supported Motherboard', ['ATX', 'mATX', 'ITX']);
        $text('case_gpu_max', 'Max GPU Length (mm)');
        $text('case_cooler_max', 'Max CPU Cooler Height (mm)');
        echo '</div>';

        echo '</div>'; // end container
    }

    public function save_part_meta( $post_id ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        
        $fields = [
            'savvy_category', 'savvy_brand', 'savvy_model', 'savvy_part_id', 
            'savvy_status', 'savvy_priority', 'savvy_reorder_qty', 'stock_allocated',
            'cpu_socket', 'cpu_platform',
            'cooler_type', 'cooler_radiator', 'cooler_height',
            'mb_socket', 'mb_chipset', 'mb_form_factor', 'mb_ram_type',
            'ram_type', 'ram_capacity', 'ram_speed', 'ram_latency',
            'storage_type', 'storage_form', 'storage_capacity', 'storage_interface',
            'gpu_platform', 'gpu_series', 'gpu_length',
            'psu_wattage', 'psu_eff', 'psu_mod',
            'case_size', 'case_mb_support', 'case_gpu_max', 'case_cooler_max'
        ];

        foreach ( $fields as $field ) {
            if ( isset( $_POST[ $field ] ) ) {
                update_post_meta( $post_id, $field, sanitize_text_field( $_POST[ $field ] ) );
            }
        }
    }

    public function print_conditional_script() {
        global $post;
        if ( ! $post || 'savvy_part' !== $post->post_type ) return;
        ?>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                var $cat = $('#savvy_category_select');
                var $groups = $('.spec-group');

                function updateFields() {
                    var val = $cat.val();
                    $groups.hide();
                    if(val) {
                        $('.spec-group[data-cat="' + val + '"]').show();
                    }
                }

                $cat.on('change', updateFields);
                updateFields(); // Run on load
            });
        </script>
     <?php
    }

    public function render_project_box( $post ) {
        $meta = get_post_meta( $post->ID );
        $status = $meta['savvy_status'][0] ?? 'Not Started';
        $priority = $meta['savvy_priority'][0] ?? 'Normal';
        $client = $meta['savvy_client_id'][0] ?? '';
        ?>
        <p>
            <label><strong>Status</strong></label><br>
            <select name="savvy_status" class="widefat">
                <?php 
                $statuses = ['Not Started', 'In Progress', 'Testing', 'Complete'];
                foreach($statuses as $s) echo '<option value="'.$s.'" '.selected($status,$s,false).'>'.$s.'</option>';
                ?>
            </select>
        </p>
        <p>
            <label><strong>Priority</strong></label><br>
            <select name="savvy_priority" class="widefat">
                <option value="Normal" <?php selected($priority, 'Normal'); ?>>Normal</option>
                <option value="High" <?php selected($priority, 'High'); ?>>High (Urgent)</option>
            </select>
        </p>
        <?php
    }
}

new Savvy_Field_Manager();
