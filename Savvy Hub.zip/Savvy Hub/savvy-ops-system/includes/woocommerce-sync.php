<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// 1. Add "Savvy Parts" Tab
add_filter( 'woocommerce_product_data_tabs', 'savvy_ops_add_product_data_tab' );
function savvy_ops_add_product_data_tab( $tabs ) {
	$tabs['savvy_parts'] = array(
		'label'    => 'Savvy Parts',
		'target'   => 'savvy_parts_product_data',
		'class'    => array( 'show_if_simple', 'show_if_variable' ),
		'priority' => 21, // Custom priority
	);
	return $tabs;
}

// 1.5 Force Enqueue Select2 (Search)
add_action( 'admin_enqueue_scripts', 'savvy_ops_enqueue_wc_scripts' );
function savvy_ops_enqueue_wc_scripts( $hook ) {
    if ( 'post.php' === $hook || 'post-new.php' === $hook ) {
        if( function_exists('wc_enqueue_js') ) {
            wp_enqueue_script( 'wc-enhanced-select' );
        }
    }
}

// 2. Add Tab Content (Panels)
add_action( 'woocommerce_product_data_panels', 'savvy_ops_add_product_data_fields' );
// 2. Add Tab Content (Panels)
add_action( 'woocommerce_product_data_panels', 'savvy_ops_add_product_data_fields' );
function savvy_ops_add_product_data_fields() {
	echo '<div id="savvy_parts_product_data" class="panel woocommerce_options_panel hidden">';
    echo '<p class="form-field"><strong>Define PC Components</strong><br>Select the standard Savvy Parts used in this build.</p>';

    // Categories to map
    $categories = ['CPU', 'Cooler', 'Motherboard', 'RAM', 'SSD', 'GPU', 'PSU', 'Case'];
    global $wpdb;
    $t_cat = $wpdb->prefix . 'savvy_catalogue';

    foreach ( $categories as $cat ) {
        // Fetch parts for this category (SQL)
        $parts = $wpdb->get_results($wpdb->prepare(
            "SELECT id, title FROM $t_cat WHERE category = %s ORDER BY title ASC", 
            $cat
        ));

        $options = array( '' => '-- Select ' . $cat . ' --' );
        if ( $parts ) {
            foreach ( $parts as $p ) {
                // Format: "Ryzen 5 5600 (#123)"
                $options[ $p->id ] = $p->title . ' (#' . $p->id . ')'; 
            }
        }

        // Render Select Field
        woocommerce_wp_select( array(
            'id'          => '_savvy_component_' . strtolower( $cat ),
            'label'       => $cat,
            'description' => 'Select the ' . $cat . ' used in this build.',
            'desc_tip'    => true,
            'options'     => $options,
            'class'       => 'wc-enhanced-select', 
            'style'       => 'width: 80%;' // Make it wide for readability
        ) );
    }

	echo '</div>';
}

// 3. Save Fields
add_action( 'woocommerce_process_product_meta', 'savvy_ops_save_product_data_fields' );
function savvy_ops_save_product_data_fields( $post_id ) {
    foreach ( $categories as $cat ) {
        $key = '_savvy_component_' . strtolower( $cat );
        if ( isset( $_POST[ $key ] ) ) {
            update_post_meta( $post_id, $key, sanitize_text_field( $_POST[ $key ] ) );
        }
    }
}

// 4. Order Sync: Create Project on Payment
add_action( 'woocommerce_order_status_processing', 'savvy_ops_import_wc_order', 10, 1 );
add_action( 'woocommerce_order_status_completed',  'savvy_ops_import_wc_order', 10, 1 );

function savvy_ops_import_wc_order( $order_id ) {
    if ( ! $order_id ) return;
    
    global $wpdb;
    $t_orders = $wpdb->prefix . 'savvy_orders';
    $t_comps = $wpdb->prefix . 'savvy_order_components';

    // Check availability (SQL)
    $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $t_orders WHERE wc_order_id = %d LIMIT 1", $order_id));
    if($exists) return; 

    $order = wc_get_order( $order_id );
    if ( ! $order ) return;

    $client = $order->get_formatted_billing_full_name();
    $build_counter = 0;

    // Loop Items
    foreach ( $order->get_items() as $item_id => $item ) {
        $product = $item->get_product();
        if ( ! $product ) continue;
        
        $qty = $item->get_quantity();
        
        // Loop Quantity (Create separate build for each unit)
        for($q=0; $q < $qty; $q++) {
            $build_counter++;
            
            // 1. Create Order Row
            $build_title = 'Order #' . $order_id . ' - ' . $product->get_name();
            
            $wpdb->insert($t_orders, [
                'wc_order_id' => $order_id,
                'wc_build_index' => $build_counter,
                'client_name' => $client,
                'title' => $build_title,
                'status' => 'Pending',
                'priority' => 'Normal'
            ]);
            $new_build_id = $wpdb->insert_id;
            
            // 2. Add Components
            $categories = ['CPU', 'Cooler', 'Motherboard', 'RAM', 'SSD', 'GPU', 'PSU', 'Case'];
            foreach ( $categories as $cat ) {
                $cat_key = strtolower( $cat );
                $cpt_part_id = $product->get_meta( '_savvy_component_' . $cat_key );
                
                if ( $cpt_part_id ) {
                // Determine Logic: Old CPT vs New SQL ID
                $sql_part_id = 0;
                
                // If it looks like a WP Post (Legacy CPT), check for mapped ID
                if ( get_post_type($cpt_part_id) === 'savvy_part' ) {
                    $mapped = get_post_meta($cpt_part_id, '_savvy_sql_id', true);
                    $sql_part_id = $mapped ? $mapped : 0; // If not mapped, maybe it failed migration?
                } else {
                    // Assume it's a direct SQL ID (New System)
                    $sql_part_id = $cpt_part_id;
                }
                
                if($sql_part_id) {
                    $wpdb->insert($t_comps, [
                        'order_id' => $new_build_id,
                        'category' => $cat,
                        'required_catalogue_id' => $sql_part_id
                    ]);
                }
            }
            }
        }
    }
}
