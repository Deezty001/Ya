<?php
// Savvy Inventory UI (Operations)

// 1. Fetch Parts (SQL)
global $wpdb;
$t_cat = $wpdb->prefix . 'savvy_catalogue';
$t_units = $wpdb->prefix . 'savvy_units';

$catalogue = $wpdb->get_results("SELECT * FROM $t_cat ORDER BY title ASC");

$categories = ['CPU', 'Motherboard', 'RAM', 'GPU', 'Storage', 'PSU', 'Case', 'Cooler'];
?>

<div class="savvy-wrapper">
    
    <div class="savvy-header">
        <div>
            <h1>Inventory Operations</h1>
            <p style="color:#646970; margin-top:5px;">Manage stock levels and receive incoming units.</p>
        </div>
        <div class="savvy-actions">
            <button id="btn-add-inventory" class="button button-primary" style="background:#2271b1;">
                <span class="dashicons dashicons-download"></span> Receive Stock
            </button>
        </div>
    </div>

    <!-- Search & Filters -->
    <div class="savvy-search-bar">
        <span class="dashicons dashicons-search" style="color:#ccc;"></span>
        <input type="text" class="savvy-search-input" placeholder="Search by Model, SKU, or Serial...">
        <div class="savvy-filters">
            <button class="filter-btn active" data-cat="all">All</button>
            <?php foreach($categories as $cat): ?>
                <button class="filter-btn" data-cat="<?php echo $cat; ?>"><?php echo $cat; ?></button>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- List -->
    <div class="savvy-inventory-list">
        <?php if($catalogue): foreach($catalogue as $p): 
            $pid = $p->id;
            $cat = $p->category ?: 'Uncategorized';
            
            // Fetch Units (SQL)
            $units = $wpdb->get_results($wpdb->prepare("SELECT * FROM $t_units WHERE catalogue_id = %d ORDER BY id DESC", $pid));
            
            $total = count($units);
            $allocated = 0;
            foreach($units as $u) if($u->status === 'Allocated') $allocated++;
            $available = $total - $allocated;
            // Update stock count in DB if mismatch? No, just display.
            
            $icon = 'dashicons-hardware'; 
            if($cat == 'CPU') $icon = 'dashicons-performance';
            if($cat == 'GPU') $icon = 'dashicons-desktop';
        ?>
            <div class="inventory-item" data-category="<?php echo $cat; ?>">
                <!-- Summary Row -->
                <div class="item-header">
                    <div class="item-icon"><span class="dashicons <?php echo $icon; ?>"></span></div>
                    <div class="item-title">
                        <h3><?php echo esc_html($p->title); ?></h3>
                        <div class="item-meta"><?php echo esc_html($p->brand); ?> | SKU: <?php echo esc_html($p->sku); ?></div>
                    </div>
                    <div class="item-cat">
                        <span class="badge <?php echo strtolower($cat); ?>"><?php echo $cat; ?></span>
                    </div>
                    <div class="item-stock">
                        <div class="stock-level <?php echo ($available < 1) ? 'out' : ''; ?>">
                            <?php echo $available; ?> Available
                        </div>
                        <div class="item-meta"><?php echo $allocated; ?> reserved</div>
                    </div>
                    <div class="item-arrow">
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </div>
                </div>

                <!-- Expanded (Stock Units) -->
                <div class="item-details">
                    <h4>Individual Units (<?php echo count($units); ?>)</h4>
                    <table class="units-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Serial #</th>
                                <th>Status</th>
                                <th>Cost</th>
                                <th>Date Added</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($units): foreach($units as $u): 
                                $status_class = 'badge-active';
                                if($u->status == 'Allocated') $status_class = 'badge-review';
                                if($u->status == 'Sold') $status_class = 'badge-inactive';
                                
                                $cost = $u->cost ?: '0.00';
                            ?>
                                <tr class="unit-row view-unit-details" 
                                    data-uid="<?php echo $u->id; ?>"
                                    style="cursor:pointer;"
                                >
                                    <td><strong>#<?php echo $u->id; ?></strong></td>
                                    <td><?php echo esc_html($u->serial); ?></td>
                                    <td><span class="badge <?php echo $status_class; ?>"><?php echo esc_html($u->status); ?></span></td>
                                    <td>$<?php echo $cost; ?></td>
                                    <td><?php echo date('Y-m-d', strtotime($u->date_received)); ?></td>
                                </tr>
                            <?php endforeach; else: ?>
                                <tr><td colspan="6">No inventory found (SQL).</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endforeach; else: ?>
            <p style="text-align:center; padding:20px;">No parts in catalogue. Run Migration to import parts.</p>
        <?php endif; ?>
    </div>

</div>

<!-- Modal: Receive Stock ONLY -->
<div id="modal-add-inventory" class="savvy-modal-overlay">
    <div class="savvy-modal">
        <form id="form-add-inventory">
            <div class="modal-header">
                <h2>Receive Stock</h2>
                <span class="dashicons dashicons-no-alt modal-close" style="cursor:pointer;"></span>
            </div>
            
            <div class="modal-body">
                <p style="margin-top:0; color:#666;">Add units to existing catalogue items.</p>
                
                <!-- Quick Scan -->
                <div class="form-group" style="background:#e6f7ff; padding:10px; border:1px dashed #1890ff; border-radius:4px; margin-bottom:15px;">
                    <label style="color:#0050b3; font-weight:bold;">⚡ Quick Scan (Barcode/UPC/EAN)</label>
                    <input type="text" id="scan-barcode" placeholder="Click here and scan box..." style="width:100%; border:1px solid #1890ff;" autocomplete="off">
                </div>

                <div class="form-group">
                    <label>Select Catalogue Item</label>
                    <select name="existing_part_id" id="existing-part-select" style="width:100%; height:40px;" required>
                        <option value="">-- Select or Search --</option>
                        <?php 
                        // Lightweight list with SEARCHABLE attributes
                        $all_parts = get_posts(['post_type'=>'savvy_part', 'numberposts'=>-1, 'orderby'=>'title', 'order'=>'ASC']);
                        foreach($all_parts as $p) {
                            $pid = $p->ID;
                            $sku = get_post_meta($pid, 'savvy_part_id', true);
                            $upc = get_post_meta($pid, 'savvy_upc', true);
                            $ean = get_post_meta($pid, 'savvy_ean', true);
                            
                            // Combine all identifiers for search
                            // We put them in data attributes for JS to find
                            echo "<option value='{$pid}' data-sku='{$sku}' data-upc='{$upc}' data-ean='{$ean}'>{$p->post_title}</option>";
                        }
                        ?>
                    </select>
                </div>

                <h4 style="margin-top:20px; border-bottom:1px solid #eee; padding-bottom:5px;">Unit Details</h4>
                <div class="form-grid">
                    <div class="form-group">
                        <label>Serial Number</label>
                        <input type="text" name="savvy_serial" placeholder="Scan or type..." required>
                    </div>
                    <div class="form-group">
                        <label>Unit Cost (ex GST)</label>
                        <input type="number" step="0.01" name="savvy_cost" placeholder="0.00">
                    </div>
                     <div class="form-group">
                         <label>Date Received</label>
                        <input type="date" name="savvy_date_received" value="<?php echo date('Y-m-d'); ?>">
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="button btn-cancel">Cancel</button>
                <button type="submit" class="button button-primary btn-save">Add to Stock</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal: Unit Details (Clean Card) -->
<!-- UNIT DETAILS MODAL MOVED TO GLOBAL PARTIAL -->
