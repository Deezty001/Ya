<?php
// Savvy Settings Page

// 1. Fetch Parts for Catalogue Tab
$args = [
    'post_type' => 'savvy_part',
    'posts_per_page' => -1,
    'post_status' => 'publish',
    'orderby' => 'title',
    'order' => 'ASC'
];
$parts = new WP_Query($args);

$categories = ['CPU', 'Motherboard', 'RAM', 'GPU', 'Storage', 'PSU', 'Case', 'Cooler'];
?>

<div class="savvy-wrapper">
    
    <div class="savvy-header">
        <div>
            <h1>Settings & Configuration</h1>
        </div>
    </div>

    <!-- TABS -->
    <h2 class="nav-tab-wrapper" style="margin-bottom:20px;">
        <a href="#tab-catalogue" class="nav-tab nav-tab-active">Product Catalogue</a>
        <a href="#tab-general" class="nav-tab">General Settings</a>
    </h2>

    <!-- TAB 1: PRODUCT CATALOGUE -->
    <div id="tab-catalogue" class="savvy-tab-content">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
            <h3>Master Product List</h3>
            <button id="btn-create-part" class="button button-primary" style="background:#2271b1;">
                <span class="dashicons dashicons-plus"></span> Create New Part
            </button>
        </div>

        <div class="savvy-inventory-list">
            <table class="units-table" style="background:#fff; box-shadow:0 1px 3px rgba(0,0,0,0.1); border-radius:8px;">
                <thead>
                    <tr>
                        <th style="padding:15px;">Category</th>
                        <th>Brand & Model</th>
                        <th>Part ID</th>
                        <th>Specs Summary</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($parts->have_posts()): while($parts->have_posts()): $parts->the_post(); 
                        $pid = get_the_ID();
                        $meta = get_post_meta($pid);
                        $cat = $meta['savvy_category'][0] ?? '-';
                        
                        $specs = [];
                        if($cat == 'CPU') $specs[] = $meta['cpu_socket'][0] ?? '';
                        if($cat == 'GPU') $specs[] = $meta['gpu_series'][0] ?? '';
                        if($cat == 'RAM') $specs[] = ($meta['ram_capacity'][0] ?? '') . 'GB ' . ($meta['ram_ddr_type'][0] ?? '');
                        $spec_str = implode(', ', array_filter($specs));
                    ?>
                        <tr>
                            <td style="padding:15px;"><span class="badge <?php echo strtolower($cat); ?>"><?php echo $cat; ?></span></td>
                            <td><strong><?php the_title(); ?></strong></td>
                            <td><?php echo $meta['savvy_part_id'][0] ?? '-'; ?></td>
                            <td><?php echo $spec_str; ?></td>
                            <td><a href="#" style="font-size:12px;">Edit</a></td>
                        </tr>
                    <?php endwhile; wp_reset_postdata(); else: ?>
                        <tr><td colspan="5" style="text-align:center; padding:20px;">No parts defined. Create one to get started.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- TAB 2: GENERAL SETTINGS -->
    <div id="tab-general" class="savvy-tab-content" style="display:none;">
        <div style="background:#fff; padding:20px; border-radius:8px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
            <h3>General Configuration</h3>
            <p>Global settings for the Savvy Ops System will go here.</p>
            <hr>
            <div class="form-group">
                <label>Company Name</label>
                <input type="text" value="Savvy Computers" style="width:300px;">
            </div>
        </div>
    </div>

</div>

<!-- Modal: Create Part (Same as before) -->
<div id="modal-create-part" class="savvy-modal-overlay">
    <div class="savvy-modal">
        <form id="form-create-part">
            <div class="modal-header">
                <h2>Create Catalogue Item</h2>
                <span class="dashicons dashicons-no-alt modal-close" style="cursor:pointer;"></span>
            </div>
            
            <div class="modal-body">
                
                <!-- Quick Scan (Universal) -->
                <div class="form-group" style="background:#f6ffed; padding:10px; border:1px dashed #52c41a; border-radius:4px; margin-bottom:15px;">
                    <label style="color:#389e0d; font-weight:bold;">⚡ Universal Scan (UPC/EAN)</label>
                    <input type="text" id="scan-universal-settings" placeholder="Scan any barcode here..." style="width:100%; border:1px solid #52c41a;" autocomplete="off">
                </div>

                <!-- Identity -->
                <h4 style="margin-top:0; border-bottom:1px solid #eee; padding-bottom:5px;">Identity</h4>
                <div class="form-grid">
                    <div class="form-group">
                        <label>Category</label>
                        <select name="savvy_category" id="new-part-category" required>
                            <option value="">-- Select --</option>
                            <?php foreach($categories as $cat) echo "<option value='$cat'>$cat</option>"; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Brand</label>
                        <input type="text" name="savvy_brand" placeholder="e.g. ASUS" required>
                    </div>
                    <div class="form-group" style="grid-column: span 2;">
                        <label>Model Name</label>
                        <input type="text" name="savvy_model" placeholder="e.g. ROG Strix GeForce RTX 4090" required>
                    </div>
                        <div class="form-group">
                    <div class="form-group">
                        <label>Part ID (Internal SKU)</label>
                        <input type="text" name="savvy_part_id" placeholder="SKU-123">
                    </div>
                    <div class="form-group">
                        <label>Generic UPC (12)</label>
                        <input type="text" name="savvy_upc" placeholder="Universal Product Code">
                    </div>
                    <div class="form-group">
                        <label>Generic EAN (13)</label>
                        <input type="text" name="savvy_ean" placeholder="European Article Number">
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="savvy_status">
                            <option value="Active">Active</option>
                            <option value="Discontinued">Discontinued</option>
                        </select>
                    </div>
                </div>

                <!-- Tech Specs (Conditional) -->
                <div id="tech-specs-section" style="display:none; background:#f9f9f9; padding:10px; border-radius:4px; margin-top:15px;">
                    <h4 style="margin-top:0;">Technical Specs</h4>
                    <div class="form-grid">
                        <!-- CPU -->
                        <div class="form-group spec-group field-cpu_socket hidden"><label>Socket</label><input type="text" name="cpu_socket" placeholder="AM5"></div>
                        <div class="form-group spec-group field-cpu_platform hidden"><label>Platform</label><select name="cpu_platform"><option>AMD</option><option>Intel</option></select></div>
                        
                        <!-- MB -->
                        <div class="form-group spec-group field-mb_socket hidden"><label>Socket</label><input type="text" name="mb_socket"></div>
                        <div class="form-group spec-group field-mb_chipset hidden"><label>Chipset</label><input type="text" name="mb_chipset"></div>
                        <div class="form-group spec-group field-mb_form_factor hidden"><label>Form Factor</label><select name="mb_form_factor"><option>ATX</option><option>mATX</option><option>ITX</option></select></div>
                        <div class="form-group spec-group field-mb_ram_type hidden"><label>RAM Type</label><select name="mb_ram_type"><option>DDR4</option><option>DDR5</option></select></div>
                            
                        <!-- RAM -->
                        <div class="form-group spec-group field-ram_ddr_type hidden"><label>DDR Type</label><select name="ram_ddr_type"><option>DDR4</option><option>DDR5</option></select></div>
                        <div class="form-group spec-group field-ram_capacity hidden"><label>Capacity (GB)</label><input type="number" name="ram_capacity"></div>
                        <div class="form-group spec-group field-ram_speed hidden"><label>Speed (MT/s)</label><input type="number" name="ram_speed"></div>
                        <div class="form-group spec-group field-ram_cas hidden"><label>CAS Latency</label><input type="text" name="ram_cas"></div>

                        <!-- GPU -->
                        <div class="form-group spec-group field-gpu_platform hidden"><label>Platform</label><select name="gpu_platform"><option>NVIDIA</option><option>AMD</option></select></div>
                        <div class="form-group spec-group field-gpu_series hidden"><label>Series</label><input type="text" name="gpu_series" placeholder="RTX 4090"></div>
                        <div class="form-group spec-group field-gpu_length hidden"><label>Length (mm)</label><input type="number" name="gpu_length"></div>

                        <!-- PSU -->
                        <div class="form-group spec-group field-psu_wattage hidden"><label>Wattage</label><input type="number" name="psu_wattage"></div>
                        <div class="form-group spec-group field-psu_rating hidden"><label>Efficiency</label><select name="psu_rating"><option>Bronze</option><option>Gold</option><option>Platinum</option><option>Titanium</option></select></div>
                        <div class="form-group spec-group field-psu_modularity hidden"><label>Modularity</label><select name="psu_modularity"><option>Full</option><option>Semi</option><option>Non</option></select></div>

                        <!-- Case -->
                        <div class="form-group spec-group field-case_size hidden"><label>Size</label><select name="case_size"><option>ATX</option><option>mATX</option><option>ITX</option></select></div>
                        <div class="form-group spec-group field-case_mb_support hidden"><label>MB Support</label><select name="case_mb_support"><option>ATX</option><option>mATX</option><option>ITX</option></select></div>
                        <div class="form-group spec-group field-case_gpu_max hidden"><label>Max GPU (mm)</label><input type="number" name="case_gpu_max"></div>
                        <div class="form-group spec-group field-case_cpu_max hidden"><label>Max Cooler (mm)</label><input type="number" name="case_cpu_max"></div>

                        <!-- Cooler -->
                        <div class="form-group spec-group field-cooler_type hidden"><label>Type</label><select name="cooler_type" id="cooler_type"><option value="">--</option><option value="Air">Air</option><option value="AIO">AIO (Liquid)</option></select></div>
                        <div class="form-group spec-group field-cooler_radiator hidden"><label>Radiator Size</label><select name="cooler_radiator"><option>120</option><option>240</option><option>280</option><option>360</option></select></div>
                        <div class="form-group spec-group field-cooler_height hidden"><label>Height (mm)</label><input type="number" name="cooler_height"></div>

                        <!-- Storage -->
                        <div class="form-group spec-group field-storage_type hidden"><label>Type</label><select name="storage_type"><option>NVMe</option><option>SATA</option></select></div>
                        <div class="form-group spec-group field-storage_form hidden"><label>Form Factor</label><select name="storage_form"><option>M.2 2280</option><option>2.5"</option></select></div>
                        <div class="form-group spec-group field-storage_cap hidden"><label>Capacity</label><input type="text" name="storage_cap"></div>
                        <div class="form-group spec-group field-storage_iface hidden"><label>Interface</label><input type="text" name="storage_iface" placeholder="PCIe Gen4"></div>
                    </div>
                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="button btn-cancel">Cancel</button>
                <button type="submit" class="button button-primary btn-save">Create Part</button>
            </div>
        </form>
    </div>
</div>

<script>
    // Tab Switcher Simple Inline
    jQuery(document).ready(function($) {
        $('.nav-tab').on('click', function(e) {
            e.preventDefault();
            $('.nav-tab').removeClass('nav-tab-active');
            $(this).addClass('nav-tab-active');
            
            $('.savvy-tab-content').hide();
            const target = $(this).attr('href');
            $(target).show();
        });
    });
</script>
