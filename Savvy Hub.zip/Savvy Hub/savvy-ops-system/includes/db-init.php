<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function savvy_ops_create_tables() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 1. Catalogue (Global Parts list)
    $table_cat = $wpdb->prefix . 'savvy_catalogue';
    $sql_cat = "CREATE TABLE $table_cat (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        title text NOT NULL,
        brand varchar(100),
        model varchar(100),
        sku varchar(100),
        category varchar(50),
        upc varchar(50),
        ean varchar(50),
        specs longtext,
        stock_count int(11) DEFAULT 0,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY sku (sku)
    ) $charset_collate;";

    // 2. Units (Physical Instance)
    $table_units = $wpdb->prefix . 'savvy_units';
    $sql_units = "CREATE TABLE $table_units (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        catalogue_id bigint(20) NOT NULL,
        serial varchar(100),
        cost decimal(10,2) DEFAULT 0.00,
        date_received datetime,
        item_condition varchar(50) DEFAULT 'New',
        status varchar(50) DEFAULT 'In_Stock',
        order_id bigint(20) DEFAULT NULL,
        notes text,
        PRIMARY KEY  (id),
        KEY catalogue_id (catalogue_id),
        KEY serial (serial),
        KEY status (status)
    ) $charset_collate;";

    // 3. Orders (Builds)
    $table_orders = $wpdb->prefix . 'savvy_orders';
    $sql_orders = "CREATE TABLE $table_orders (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        wc_order_id bigint(20) DEFAULT 0,
        wc_build_index int(11) DEFAULT 0,
        client_name text,
        title text,
        status varchar(50) DEFAULT 'Pending',
        priority varchar(50) DEFAULT 'Normal',
        date_created datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY wc_order_id (wc_order_id),
        KEY status (status)
    ) $charset_collate;";

    // 4. Order Components (Manifest)
    $table_comps = $wpdb->prefix . 'savvy_order_components';
    $sql_comps = "CREATE TABLE $table_comps (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        order_id bigint(20) NOT NULL,
        category varchar(50),
        required_catalogue_id bigint(20),
        allocated_unit_id bigint(20) DEFAULT NULL,
        PRIMARY KEY  (id),
        KEY order_id (order_id),
        KEY allocated_unit_id (allocated_unit_id)
    ) $charset_collate;";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql_cat );
    dbDelta( $sql_units );
    dbDelta( $sql_orders );
    dbDelta( $sql_comps );
}
