<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Client Hub customizations
// e.g. Show linked projects count in admin list

function savvy_ops_client_columns($columns) {
    $columns['linked_projects'] = 'Active Projects';
    return $columns;
}
add_filter('manage_savvy_client_posts_columns', 'savvy_ops_client_columns');

function savvy_ops_client_custom_column($column, $post_id) {
    switch ($column) {
        case 'linked_projects':
            // Counts projects where meta _savvy_client_id == $post_id
            $args = array(
                'post_type' => 'savvy_project',
                'meta_key' => '_savvy_client_id',
                'meta_value' => $post_id,
                'fields' => 'ids',
            );
            $query = new WP_Query($args);
            echo $query->found_posts;
            break;
    }
}
add_action('manage_savvy_client_posts_custom_column', 'savvy_ops_client_custom_column', 10, 2);
