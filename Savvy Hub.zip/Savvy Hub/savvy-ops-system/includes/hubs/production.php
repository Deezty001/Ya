<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

// AJAX: Get Order Details for Modal
// AJAX: Get Order Details for Modal
// AJAX: Get Order Details for Modal
add_action( 'wp_ajax_savvy_get_order_details', 'savvy_ajax_get_order_details' );
function savvy_ajax_get_order_details() {
    check_ajax_referer( 'savvy_inventory_nonce', 'nonce' );
    global $wpdb;
    
    $requested_id = absint( $_POST['order_id'] );
    $t_orders = $wpdb->prefix . 'savvy_orders';
    $t_comps = $wpdb->prefix . 'savvy_order_components';
    $t_cat = $wpdb->prefix . 'savvy_catalogue';
    $t_units = $wpdb->prefix . 'savvy_units';

    // 1. Get Context (Requested Order)
    $order = $wpdb->get_row($wpdb->prepare("SELECT * FROM $t_orders WHERE id = %d", $requested_id));
    if(!$order) wp_send_json_error('Order not found');

    $wc_id = $order->wc_order_id;
    
    // 2. Find Sibling Builds (or just self)
    if($wc_id) {
        $siblings = $wpdb->get_results($wpdb->prepare("SELECT * FROM $t_orders WHERE wc_order_id = %d ORDER BY wc_build_index ASC", $wc_id));
    } else {
        $siblings = [$order];
    }

    $builds_data = [];
    $main_title = $order->title; // Default
    if(!empty($siblings)) $main_title = $siblings[0]->title; // Use first build's title

    // 3. Loop Builds and Fetch Components
    foreach($siblings as $build) {
        $b_wc_id = $build->wc_order_id;
        $b_idx = $build->wc_build_index;
        $disp_id = $b_wc_id ? ($b_idx ? "$b_wc_id.$b_idx" : $b_wc_id) : $build->id;

        // Fetch Components
        $sql_c = "SELECT 
                    c.category, 
                    c.required_catalogue_id as part_id, 
                    cat.title as part_name, 
                    u.id as unit_id, 
                    u.serial as unit_serial
                  FROM $t_comps c
                  LEFT JOIN $t_cat cat ON c.required_catalogue_id = cat.id
                  LEFT JOIN $t_units u ON c.allocated_unit_id = u.id
                  WHERE c.order_id = %d";
                  
        $raw_components = $wpdb->get_results($wpdb->prepare($sql_c, $build->id));
        
        $components = [];
        foreach($raw_components as $rc) {
            $components[] = [
                'category' => $rc->category,
                'part_name' => $rc->part_name,
                'part_id' => $rc->part_id,
                'allocated' => !empty($rc->unit_id),
                'unit_id' => $rc->unit_id,
                'unit_serial' => $rc->unit_serial
            ];
        }

        $builds_data[] = [
            'id' => $build->id,
            'display_id' => $disp_id,
            'status' => $build->status,
            'components' => $components
        ];
    }
    
    // 4. Response
    $data = [
        'id' => $requested_id, 
        'main_display_id' => $wc_id ? $wc_id : $requested_id, 
        'title' => $main_title,
        'client' => $order->client_name,
        'builds' => $builds_data
    ];

    wp_send_json_success($data);
}


// AJAX: Get Available Units for a Part
add_action( 'wp_ajax_savvy_get_available_units', 'savvy_ajax_get_available_units' );
function savvy_ajax_get_available_units() {
    check_ajax_referer( 'savvy_inventory_nonce', 'nonce' );
    global $wpdb;
    
    $cat_id = absint($_POST['part_id']);
    $units = $wpdb->get_results($wpdb->prepare(
        "SELECT id, serial FROM {$wpdb->prefix}savvy_units WHERE catalogue_id = %d AND status = 'In_Stock'", 
        $cat_id
    ));
    
    wp_send_json_success($units);
}

// AJAX: Allocate Unit (SQL)
add_action( 'wp_ajax_savvy_allocate_unit', 'savvy_ajax_allocate_unit' );
function savvy_ajax_allocate_unit() {
    check_ajax_referer( 'savvy_inventory_nonce', 'nonce' );
    global $wpdb;
    
    $order_id = absint($_POST['order_id']);
    $unit_id = absint($_POST['unit_id']);
    $cat_name = sanitize_text_field($_POST['category']); // 'CPU' etc
    
    $t_comps = $wpdb->prefix . 'savvy_order_components';
    $t_units = $wpdb->prefix . 'savvy_units';

    // 1. Get Component Row
    $comp = $wpdb->get_row($wpdb->prepare("SELECT * FROM $t_comps WHERE order_id = %d AND category = %s", $order_id, $cat_name));
    if(!$comp) wp_send_json_error('Component requirement not found');
    
    // 2. Unallocate Existing (if any)
    if($comp->allocated_unit_id) {
        $wpdb->update($t_units, 
            ['status' => 'In_Stock', 'order_id' => NULL],
            ['id' => $comp->allocated_unit_id]
        );
    }
    
    // 3. Allocate New
    // Verify stock
    $unit = $wpdb->get_row($wpdb->prepare("SELECT status FROM $t_units WHERE id = %d", $unit_id));
    if(!$unit || $unit->status !== 'In_Stock') wp_send_json_error('Unit unavailable');
    
    // Update Component
    $wpdb->update($t_comps, 
        ['allocated_unit_id' => $unit_id],
        ['id' => $comp->id]
    );
    
    // Update Unit
    $wpdb->update($t_units,
        ['status' => 'Allocated', 'order_id' => $order_id],
        ['id' => $unit_id]
    );
    
    wp_send_json_success();
}

/**
 * HELPER: Simple Audit Logger using WordPress Comments
 */
function savvy_log_history($post_id, $message) {
    $user = wp_get_current_user();
    $user_name = $user->exists() ? $user->user_login : 'System';
    
    $data = array(
        'comment_post_ID' => $post_id,
        'comment_author' => $user_name,
        'comment_content' => $message,
        'comment_type' => 'savvy_log',
        'comment_date' => current_time('mysql'),
        'comment_approved' => 1,
    );
    wp_insert_comment($data);
}

// AJAX: Get Unit Details for Pop-up
add_action( 'wp_ajax_savvy_get_unit_details', 'savvy_ajax_get_unit_details' );
function savvy_ajax_get_unit_details() {
    check_ajax_referer( 'savvy_inventory_nonce', 'nonce' );
    $unit_id = absint($_POST['unit_id']);
    $unit = get_post($unit_id);
    if(!$unit) wp_send_json_error('Unit not found');

    $meta = get_post_meta($unit_id);
    $parent_id = $meta['savvy_unit_parent'][0] ?? 0;
    
    // Parent Data
    $brand = ''; $model = ''; $upc = '';
    if($parent_id) {
        $brand = get_post_meta($parent_id, 'savvy_brand', true);
        $model = get_post_meta($parent_id, 'savvy_model', true);
        $upc = get_post_meta($parent_id, 'savvy_upc', true);
    }

    $data = [
        'id' => $unit_id,
        'serial' => $meta['savvy_serial'][0] ?? '-',
        'cost' => $meta['savvy_cost'][0] ?? '0.00',
        'date' => $meta['savvy_date_received'][0] ?? '-',
        'condition' => $meta['savvy_condition'][0] ?? 'New',
        'brand' => $brand,
        'model' => $model, // Title of parent usually better?
        'title' => get_the_title($parent_id),
        'upc' => $upc
    ];

    // Fetch History
    $comments = get_comments([
        'post_id' => $unit_id,
        'type' => 'savvy_log',
        'orderby' => 'date',
        'order' => 'DESC',
        'number' => 10
    ]);

    $history = [];
    foreach($comments as $c) {
        $history[] = [
            'date' => date('Y-m-d H:i', strtotime($c->comment_date)),
            'user' => $c->comment_author,
            'msg' => $c->comment_content
        ];
    }
    $data['history'] = $history;

    wp_send_json_success($data);
}
