<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 1. ADMIN COLUMNS FOR PARTS CATALOGUE (savvy_part)
 */
function savvy_ops_part_columns($columns) {
    // Insert new columns after Title
    $new_cols = array();
    foreach($columns as $key => $title) {
        $new_cols[$key] = $title;
        if ($key === 'title') {
            $new_cols['part_category'] = 'Category';
            $new_cols['part_brand'] = 'Brand';
            $new_cols['part_model'] = 'Model';
            $new_cols['part_stock'] = 'Stock Hand';
        }
    }
    return $new_cols;
}
add_filter('manage_savvy_part_posts_columns', 'savvy_ops_part_columns');

function savvy_ops_part_custom_column($column, $post_id) {
    switch ($column) {
        case 'part_category':
            echo esc_html(get_post_meta($post_id, 'savvy_category', true));
            break;
        case 'part_brand':
            echo esc_html(get_post_meta($post_id, 'savvy_brand', true));
            break;
        case 'part_model':
            echo esc_html(get_post_meta($post_id, 'savvy_model', true));
            break;
        case 'part_stock':
            // Calculate strictly from Units count
            $units = new WP_Query([
                'post_type' => 'savvy_unit',
                'meta_key' => 'savvy_unit_parent',
                'meta_value' => $post_id,
                'fields' => 'ids',
                'post_status' => 'publish' // Active units only?
            ]);
            $count = $units->found_posts;
            
            // Update the cache field
            update_post_meta($post_id, 'stock_on_hand', $count);
            
            echo '<strong>' . $count . '</strong>';
            break;
    }
}
add_action('manage_savvy_part_posts_custom_column', 'savvy_ops_part_custom_column', 10, 2);


/**
 * 2. ADMIN COLUMNS FOR STOCK UNITS (savvy_unit)
 */
function savvy_ops_unit_columns($columns) {
    $columns['unit_serial'] = 'Serial Number';
    $columns['unit_parent'] = 'Part Model';
    $columns['unit_cost'] = 'Cost';
    $columns['unit_date'] = 'Date Received';
    return $columns;
}
add_filter('manage_savvy_unit_posts_columns', 'savvy_ops_unit_columns');

function savvy_ops_unit_custom_column($column, $post_id) {
    switch ($column) {
        case 'unit_serial':
            echo get_post_meta($post_id, 'savvy_serial', true);
            break;
        case 'unit_parent':
            $parent_id = get_post_meta($post_id, 'savvy_unit_parent', true);
            echo $parent_id ? '<a href="'.get_edit_post_link($parent_id).'">'.get_the_title($parent_id).'</a>' : '-';
            break;
        case 'unit_cost':
            echo '$' . get_post_meta($post_id, 'savvy_cost', true);
            break;
        case 'unit_date':
            echo get_post_meta($post_id, 'savvy_date_received', true);
            break;
    }
}
add_action('manage_savvy_unit_posts_custom_column', 'savvy_ops_unit_custom_column', 10, 2);


/**
 * 3. META BOXES FOR STOCK UNITS
 */
function savvy_ops_unit_meta_boxes() {
    add_meta_box('savvy_unit_details', 'Unit Details', 'savvy_ops_render_unit_box', 'savvy_unit', 'normal', 'high');
}
add_action('add_meta_boxes', 'savvy_ops_unit_meta_boxes');

function savvy_ops_render_unit_box($post) {
    $meta = get_post_meta($post->ID);
    
    // Get all Parts for the dropdown
    $parts = get_posts(['post_type'=>'savvy_part', 'numberposts'=>-1, 'orderby'=>'title', 'order'=>'ASC']);
    ?>
    <p>
        <label><strong>Linked Part (Catalogue)</strong></label><br>
        <select name="savvy_unit_parent" class="widefat">
            <option value="">- Select Part -</option>
            <?php foreach($parts as $p): ?>
                <option value="<?php echo $p->ID; ?>" <?php selected($meta['savvy_unit_parent'][0]??'', $p->ID); ?>>
                    <?php echo esc_html($p->post_title); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </p>
    <p>
        <label>Serial Number</label>
        <input type="text" name="savvy_serial" value="<?php echo esc_attr($meta['savvy_serial'][0]??''); ?>" class="widefat">
    </p>
    <div style="display:flex; gap:10px;">
        <div style="flex:1;">
            <label>Date Received</label>
            <input type="date" name="savvy_date_received" value="<?php echo esc_attr($meta['savvy_date_received'][0]??''); ?>" class="widefat">
        </div>
        <div style="flex:1;">
             <label>Purchase Price ($)</label>
             <input type="number" step="0.01" name="savvy_cost" value="<?php echo esc_attr($meta['savvy_cost'][0]??''); ?>" class="widefat">
        </div>
    </div>
    <?php
}

function savvy_ops_save_unit_meta($post_id) {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    
    $fields = ['savvy_unit_parent', 'savvy_serial', 'savvy_date_received', 'savvy_cost'];
    foreach($fields as $f) {
        if(isset($_POST[$f])) update_post_meta($post_id, $f, sanitize_text_field($_POST[$f]));
    }
}
// 4. AJAX: Get Unit Details (Modal)
add_action( 'wp_ajax_savvy_get_unit_details', 'savvy_ajax_get_unit_details' );
function savvy_ajax_get_unit_details() {
    check_ajax_referer( 'savvy_inventory_nonce', 'nonce' );
    global $wpdb;
    
    $uid = absint($_POST['uid']);
    $t_units = $wpdb->prefix . 'savvy_units';
    $t_cat = $wpdb->prefix . 'savvy_catalogue';
    $t_orders = $wpdb->prefix . 'savvy_orders';
    
    // Fetch Unit + Part Info
    $sql = "SELECT u.*, c.title as part_title, c.sku, o.wc_order_id, o.title as order_title 
            FROM $t_units u 
            JOIN $t_cat c ON u.catalogue_id = c.id
            LEFT JOIN $t_orders o ON u.order_id = o.id
            WHERE u.id = %d";
            
    $unit = $wpdb->get_row($wpdb->prepare($sql, $uid));
    
    if(!$unit) wp_send_json_error('Unit not found');
    
    // Format Data
    $data = [
        'id' => $unit->id,
        'serial' => $unit->serial,
        'cost' => $unit->cost, // Ensure this matches JS expectation
        'date_received' => date('Y-m-d', strtotime($unit->date_received)),
        'status' => $unit->status,
        'condition' => $unit->item_condition,
        'part_title' => $unit->part_title,
        'sku' => $unit->sku,
        'allocated_to' => $unit->order_title ? $unit->order_title : '-'
    ];
    
    wp_send_json_success($data);
}
