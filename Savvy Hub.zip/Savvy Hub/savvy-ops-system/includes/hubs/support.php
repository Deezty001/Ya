<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Add Custom Columns to Ticket List
function savvy_ops_ticket_columns($columns) {
    $columns['ticket_priority'] = 'Priority';
    return $columns;
}
add_filter('manage_savvy_ticket_posts_columns', 'savvy_ops_ticket_columns');

function savvy_ops_ticket_custom_column($column, $post_id) {
    switch ($column) {
        case 'ticket_priority':
            $prio = get_post_meta($post_id, '_priority', true);
            echo $prio ? esc_html($prio) : 'Normal';
            break;
    }
}
add_action('manage_savvy_ticket_posts_custom_column', 'savvy_ops_ticket_custom_column', 10, 2);
