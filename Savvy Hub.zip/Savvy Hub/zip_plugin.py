import zipfile
import os

def zip_plugin(source_dir, output_filename):
    with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(source_dir):
            for file in files:
                file_path = os.path.join(root, file)
                # Calculate relative path
                rel_path = os.path.relpath(file_path, os.path.dirname(source_dir))
                # Force forward slashes for zip compatibility
                rel_path = rel_path.replace(os.sep, '/')
                print(f"Adding {rel_path}")
                zipf.write(file_path, rel_path)

if __name__ == "__main__":
    zip_plugin('savvy-ops-system', 'savvy-ops-system-v2.zip')
    print("Created savvy-ops-system-v2.zip successfully.")
